#!/usr/bin/env bash
set -u

set +e
rustup component add miri --toolchain nightly
component_rc=$?
rustup component add rust-src --toolchain nightly
rustsrc_rc=$?
rustup target add x86_64-unknown-linux-gnu i686-unknown-linux-gnu powerpc64-unknown-linux-gnu --toolchain nightly
target_rc=$?
{
    rustc +nightly --version
    cargo +nightly --version
    cargo +nightly miri --version
    rustup target list --toolchain nightly --installed
} >/work/miri-results/tool-versions.stdout 2>/work/miri-results/tool-versions.stderr
printf '%s\n' "$component_rc" > /work/miri-results/component.rc
printf '%s\n' "$rustsrc_rc" > /work/miri-results/rust-src.rc
printf '%s\n' "$target_rc" > /work/miri-results/targets.rc

for target in x86_64-unknown-linux-gnu i686-unknown-linux-gnu powerpc64-unknown-linux-gnu; do
    for test_name in ffi_smoke ffi_cursor ffi_strings ffi_ops_interleave; do
        out="/work/miri-results/${target}-${test_name}.stdout"
        err="/work/miri-results/${target}-${test_name}.stderr"
        start=$(date +%s.%N)
        timeout 600 cargo +nightly miri test --target "$target" --no-default-features --test "$test_name" >"$out" 2>"$err"
        rc=$?
        end=$(date +%s.%N)
        duration=$(awk -v a="$start" -v b="$end" 'BEGIN { print b-a }')
        printf '%s\n' "$rc" > "/work/miri-results/${target}-${test_name}.rc"
        printf '%s\n' "$duration" > "/work/miri-results/${target}-${test_name}.duration"
        printf '%s %s %s %s\n' "$target" "$test_name" "$rc" "$duration" >> /work/miri-results/summary.tsv
    done
done
exit 0
