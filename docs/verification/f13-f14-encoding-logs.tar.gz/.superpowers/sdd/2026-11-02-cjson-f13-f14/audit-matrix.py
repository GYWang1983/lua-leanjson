import tarfile,json,pathlib
w=pathlib.Path('.superpowers/sdd/2026-11-02-cjson-f13-f14');out={};regressions=[]
with tarfile.open('docs/verification/f10-comments-logs.tar.gz') as t:
 for mode in ('lazy','eager','preload'):
  for source in ('memory','file','feed'):
   cell=mode+'-'+source
   name='.superpowers/sdd/2026-11-02-cjson-f10/final-matrix/matrix/'+cell+'/records.jsonl'
   old={r['id']:r for line in t.extractfile(name) if (r:=json.loads(line))}
   new={r['id']:r for line in (w/'matrix'/'matrix'/cell/'records.jsonl').read_text().splitlines() if (r:=json.loads(line))}
   lost=sorted(set(old)-set(new));bad=[k for k in old if old[k]['classification']=='pass' and new[k]['classification']!='pass']
   added=[k for k in new if new[k]['classification']=='pass' and old[k]['classification']!='pass']
   relevant=[k for k,r in new.items() if k=='agentzh.t:TEST22' or k.startswith('test.lua:L') and 363<=int(k[10:])<=396]
   failures={k:new[k]['classification'] for k in relevant if new[k]['classification']!='pass'}
   row=dict(records=len(new),lost=lost,regressions=bad,new_passes=added,f13_f14_count=len(relevant),f13_f14_failures=failures)
   out[cell]=row;regressions.extend(lost+bad+list(failures));print(cell,json.dumps(row))
(w/'matrix-audit.json').write_text(json.dumps(out,indent=2)+'\n')
assert not regressions
