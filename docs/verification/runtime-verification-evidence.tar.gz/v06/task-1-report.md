# V06 + V08 implementation and verification report

Status: V06 and V08 are complete. Original-distro functional + full Memcheck
and frozen rolling full Memcheck commands exited0; both final strict audits
passed every process log. All runner review findings are fixed and verified.
The original distro retains only its three documented Lua52 table-length
pending cases. No known unexplained V06/V08 error category remains.

## Current verified results

| Check | Result | Receipt / evidence |
| --- | --- | --- |
| Fresh Linux release library build | exit 0 | evidence/rebuild-correct.json |
| Focused original failures + signed-zero regressions | 214 pass, 0 fail/error/pending; exit 0 | evidence/focused-final.json |
| Full distro suite, no Valgrind | 817 pass, 0 fail/error, 3 pending; exit 0 | evidence/distro-plain-final.json |
| Direct selected-runtime Busted Memcheck | 18 pass, exit 0 | evidence/direct-entrypoint-focus.json |
| Full rolling make openresty-verify | exit 0; Rust default/scalar/panic, Clippy, Lua 820, Lua lint 90 files, properties, stress/corpus, HTTP 72 | evidence/rolling-openresty.json and .log |
| Real out-of-bounds FFI write negative control | expected exit 1; Invalid write of size 1; 1 error, 0 suppressed | evidence/negative-complete.json; negative-complete-results/run.*/negative-control/memcheck.*.log |
| Runner child/missing-log/reuse controls | 12 pass, exit0; malformed/missing/child/reuse/provenance cases verified | evidence/review-fixes-green.json; review-summary-{red,green}.json; review-provenance-red.json |
| V06 full distro command | plain817 pass /0 fail/error /3 pending; Memcheck817 pass /0 fail/error /3 pending; outerexit0 | evidence/distro-canonical.json |
| V06 final strict per-process audit |21 process logs, zero errors/lost, all complete valid summaries; exit0 | evidence/distro-strict-audit.json and distro-memcheck-audit.json |
| V08 full rolling Memcheck |820 pass /0 fail/error/pending; actualexit0 | evidence/v08-frozen-final.json |
| V08 strict per-process audit |21 logs, zero errors/suppressed/lost, no warning lines; exit0 | evidence/v08-frozen-strict-audit.json; v08-memcheck-audit.json |

The three distro pending cases are explicitly conditional table __len tests.
This binary lacks LUAJIT_ENABLE_LUA52COMPAT, so table # cannot dispatch __len.
Portable leanjson.len coverage runs and passes; no new pending/skip was added.

## Exact functional causes and dispositions

1. External-array embedded NUL: native cjson and native tonumber on this distro
   accept `2\0bad` as 2 and encode ["a","b"]. Rolling rejects it and encodes [].
   The production external-array implementation was correct. The test now probes
   the VM conversion capability and retains exact encode/reader output checks.
2. Negative-zero encode: the distro compiler turns literal -0.0 into positive
   zero before LeanJSON sees it. Native cjson also encodes that literal as 0.
   Both the encoder settings test and an additional numeric-limits expected
   value now construct actual negative zero dynamically as -1/math.huge.
3. Fractional negative-zero decode: a real implementation defect. Native cjson
   uses strtod, preserving signs for -0.0, -0e0, -0x0p0 and negative underflow;
   the distro tonumber discards them. number.decode now reuses its existing
   private-locale strtod_l fallback when a negative non-integer token converts
   to zero. Plain integer -0/-000 still return positive zero like cjson strtoll.
   The scanner and decode_invalid_numbers policy are unchanged; this adds no
   token concatenation or alternative input-validation path.
4–7. Native ipairs: plain table iteration ignores __ipairs and userdata is
   rejected on this VM. This is the documented LuaJIT portability contract,
   already stated in docs/migrating-from-cjson.md. Tests independently probe
   native __ipairs dispatch, assert precise native behavior, and always assert
   empty object traversal plus closed ownership through leanjson.ipairs for
   both table/userdata. No builtin was replaced and no case was skipped.

Reference controls for distro and rolling are preserved in
evidence/restored-identity.log and evidence/rolling-reference.log. New signed
zero tests cover all memory/file/feed x lazy/eager/preload x table/userdata
cells. Focused red: 187 pass / 25 fail / 0 error (the original seven plus the
18 new regression cells); focused final green: 214 pass / 0 fail.

## Memcheck attribution and harness disposition

- The original full distro log contains 52 displayed uninitialized-conditional
  contexts across eight LuaJIT PIDs, including 28 contexts in main PID382.
  Every one has top PC0x111D24. Full extraction is evidence/original-contexts.json;
  every LuaJIT frame is symbolized in evidence/original-symbols.json.
- Exact build-ID debug symbols establish PIE bias0x108000 and PC0x9d24 as
  inlined str_fastcmp (lj_str.c:48) in lj_str_new (lj_str.c:155). The original
  source and disassembly read 4-byte chunks through the last partial word,
  then mask bytes beyond logical string length. These frames are reached by
  package-loader luaL_gsub, number/tostring formatting, ffi.string / FFI parser,
  debug lua_pushstring, and native cjson encode/decode/external-array paths.
- The module-free original gsub/tostring control reproduces the exact PC.
  --track-origins identifies gsub's local stack buffer. Unsuppressed control
  exits 1; all heap blocks are freed. Exact symbols plus --read-inline-info=no
  produce physical lj_str_new frames and let the existing named Cond rule
  match: zero errors, suppressed1, exit0. valgrind.supp is unchanged.
  See module-free-raw.json, module-free-no-inline.json, source-map.json.
- Original marker/metamethod/loading/shutdown/missing-factory child failures
  followed nonzero child exits due to this same runtime warning. Focused
  direct-entrypoint tests now pass under Memcheck; the complete final run
  must confirm every remaining category before closure.
- Descriptor-limit harness defect: shell `ulimit -n64` changes the hard limit,
  which Valgrind rejects, and the old semicolon ignored that failure. A soft
  shell limit succeeds but traced exec resets it (control initial20492).
  The fresh Lua fixture now sets its own soft limit with setrlimit and verifies
  it with getrlimit before loading LeanJSON. A module-free exhaustion control
  proves 61 descriptors available, maximum fd63, then EMFILE; it intentionally
  records Valgrind's invalid-fd64 warning only in that exhaustion control.
  The real deep-spill fixture retains its soft==64 assertion and passes.
- Additional restored-environment launcher category: LuaRocks' Busted wrapper
  invokes gcc -print-multiarch. A module-free GCC control reproduces six
  definite-leak contexts /4353 bytes, exit1; LuaRocks ignores that probe exit.
  The checked-in runner invokes Busted's standard Lua entrypoint directly in
  the selected LuaJIT, avoiding unrelated compiler probes/re-exec. No GCC
  suppression or failure-code relaxation was added. Every traced log must
  contain a zero-error summary, with unique directories preventing stale logs.

## Source and environment identity

Repair branch fix/v06-distro-luajit, base b2c670e81051d62bc1b2af8979a678f14a484848.
No commit, push, merge or unrelated source change was made. Parent owns the
two pre-existing current-report edits in docs/verification.

The original task images and managed worktree were externally deleted during
the task. Final proof is rerun from the current repair checkout; deleted logs
are not counted. Docker BuildKit retained the successful restoration build log
at evidence/image-restore.log. New unique image lua-qjson-v06:restored-20261103
is sha256:0b7b567601c1ec0b88c1ee6c81c7dea32867b60c97a5a230b7e28e436e70020f.

The distro executable and native cjson binaries exactly match the original:

- /usr/bin/luajit SHA256 5a52407336f5f614633c32d14b84c3cb83b0c93ea70ff9b32b7ff98431aa2b3b;
  build ID c532105f1b77eb8e57e777c684b290e7b54c5ede.
- Rolling LuaJIT SHA256 f01956cada29a681852e97ace4e6b3acb43ea9a203cb11438b47cbdc57bb35d3.
- Native cjson SHA256 8825abcf6fca35d18d274d66ff850bd7a6d935e4552fc0bb4e19eff8b3705dab.
- Existing suppression SHA256 bf8b64340b88ff078edc1b8a7af945350a6b64b12e6e6dd9d5ea78130eb852ca.
- Exact debug file SHA256 3bc684d8122cc5a89050b4a21aecba4f7d068b2d5bfcf46901e1080942dd456b.
- Ubuntu source tar SHA256 46589f8a1742d04fc33f309343d9521b32d6d29515a34c6609e2f76932b1b7df.

Installed versions: distro luajit/libluajit2.1.0~beta3+dfsg-6ubuntu0.1,
Valgrind1:3.18.1-1ubuntu2, libc6-dbg2.35-0ubuntu3.15, OpenResty1.29.2.4,
Rust/Cargo1.90.0, Busted2.2.0-1, Luacheck1.2.0-1. Explicit LuaRocks paths
are in every Docker receipt because restoration installed rocks under the
bundled LuaJIT prefix. Containers use isolated target directories; other
services, original tags and shared writable build volumes were not mutated.

## File manifest for independent review

- lua/leanjson/number.lua
- tests/lua/cjson_external_arrays_spec.lua
- tests/lua/cjson_numeric_limits_spec.lua
- tests/lua/cjson_settings_spec.lua
- tests/lua/cjson_source_numeric_bytes_spec.lua
- tests/lua/strict_userdata_spec.lua
- tests/lua/source_shutdown_spec.lua
- tests/lua/fixtures/source_deep_spill.lua
- tests/lua/fixtures/valgrind_invalid_write.lua (new, never ordinary suite)
- scripts/run-busted.lua (new)
- scripts/check-memcheck.awk (new strict per-process parser)
- scripts/verify-luajit.sh (new, executable)
- tests/test_verify_luajit_runner.py (new)
- docs/testing-luajit.md (new reusable guide; one current report remains in docs/verification)

## Fix round 1 and strict audit

Independent review identified two Important runner findings. Both were verified
with real shell-runner negative controls, then fixed in one remediation round:

- P1: malformed/truncated/nonnumeric ERROR SUMMARY lines could coerce to zero.
  Three new controls failed before the fix (review-summary-red.json). The new
  standalone check-memcheck.awk validates all12 fields, complete punctuation,
  numeric counts and zero error/context totals for every individual log.
  Complete parent logs cannot hide malformed, empty or absent child evidence.
- P2: shared-root manifests were overwritten when the output root was reused.
  The new controlled two-run test changes both library and source bytes and
  reproduced loss of the first manifest (review-provenance-red.json). Every
  invocation now owns a unique run.XXXXXX directory with immutable matching
  runtime/library/source manifests and profile subdirectories. Concurrent or
  repeated invocations do not share manifest paths.

Final targeted controls:12/12, exit0 (review-fixes-green.json). Final real invalid
write probe still reports1 error /0 suppressed and returns1
(negative-complete.json). Reusable setup guide is docs/testing-luajit.md.

V06's original actual full command exited0 at2026-11-03T16:39:35Z; the plain
suite ran25.394088s and Memcheck suite601.215635s. Each reported817 pass /0 fail
/error /3 documented pending. The final standalone strict parser was applied
independently to all21 generated process logs: exit0; total unsuppressed
errors0; all definite/indirect/possible lost bytes0; suppressed4,051,437 errors
in54 contexts under the unchanged named LuaJIT rule; largest still-reachable
process826 bytes. Full per-process commands, SHA256 and warning lists are in
evidence/distro-memcheck-audit.json. This audit is separate from the unchanged
instrumentation and does not retroactively alter the command's exit code.

The frozen final source/runner/library snapshot is evidence/source-final,
626 files, all read-only. Manifest source-final-manifest.json SHA256:
4072cba93acfc7f7fd40ac2245093ddeb139095a2e51a1cc73430a32adf10a76.
Its native library matches original SHA2568bf0d9f2... exactly. No source edits
will be made to this snapshot during execution.

## Current completion and remaining boundaries

Scoped fix-round1 review approved P1/P2 with no new Important finding.
V08 frozen final run started2026-11-03T16:45:25Z and finished16:55:02Z:
820 successes /0 failures /0 errors /0 pending,576.324279s, actualexit0.
It used the frozen source/runner/library, not the editable checkout. The final
strict parser audited every one of21 process logs: all complete valid summaries,
zero errors, zero suppressions, zero definite/indirect/possible lost, no warning
lines; largest still-reachable process826 bytes. Receipts:
evidence/v08-frozen-final.json and v08-frozen-strict-audit.json; full per-process
statistics and SHA256 are in evidence/v08-memcheck-audit.json. The final rolling
real invalid-write negative control independently returned1 with1 error /0
suppressed (v08-frozen-negative.json). This is separate V08 acceptance from
V06 distro and the ordinary make openresty-verify gate.

The superseded editable-runner rolling command completed820 tests but exited2
after review-time edits shifted the shell file while Bash was still reading it.
Its rolling-memcheck.json is diagnostic evidence, not acceptance. The frozen
rerun above supplies the required actualexit0 without altering that old receipt.

An older wrapper-based distro attempt was deliberately cancelled with Docker
exit137 after exposing GCC launcher leakage; it is superseded diagnostic
evidence, not a current product test result (distro-memcheck-full.json and
supersede-wrapper-run.json). Setup/mount failures executed zero tests and are
not product failures. Deleted worktree logs are not counted as final proof.

Final self-review found no remaining implementation defect: the numeric fallback
retains full-token validation and integer-zero semantics; carrier tests exercise
portable APIs without changing globals; the FD limit is local to its child VM;
checker failures/malformed or absent child evidence fail closed; invocation
identities do not share output paths. Scoped review approved the same fixes.
All14 implementation paths match the frozen execution snapshot byte-for-byte;
see evidence/implementation-manifest.json. After final execution, all626 frozen
files still match their recorded SHA256; evidence/snapshot-integrity.json.
Nothing remains to implement or verify within V06/V08. This evidence is bounded
to the exact ARM64 binaries, fixtures and existing narrow suppression policy;
it is not a general memory-safety guarantee or a result for unexecuted platforms. No production/Lua test source change occurred
in fix round1; the parent's V07 final-source snapshot remains valid. V05 is
outside this scope; V07 is owned by the separate runtime verifier.

## Additional attribution controls

Native-cjson-only control (LeanJSON forbidden) reproduces53 errors in5 contexts
at lj_str_new, with origins in native strbuf allocation. FFI-only control with
neither library loaded reproduces1 context at the same PC using two defined
logical bytes and uninitialized allocated padding. LeanJSON-only control blocks
native cjson and verifies every memory/file/feed x lazy/eager/preload x carrier
cell: raw269 warnings in1 context at that same string-interning PC, values
correct and all heap blocks freed. Copying exactly the requested ffi.string
bytes into a zero-padded test buffer removes every warning: zero errors, zero
suppressed, exit0. This diagnostic padding is not a production change. Source
inspection also confirms Decoded's logical bytes are initialized and only its
explicit length is exposed to Lua. The original Ubuntu Debian patch series
does not modify lj_str.c; Debian tar SHA256
4aae116d34ae938bee716c28028cc6dab30d23402b56bd54ed4b5454a963f989.
Receipts: native-cjson-raw, ffi-string-raw, leanjson-attribution-raw,
leanjson-padding-control, source-map, debian-source-download.

Final distro audit records no warning lines. Every suppressed event used only
the pre-existing named `LuaJIT optimized string compare Cond lj_str_new` rule,
exact total4,051,437; evidence/distro-suppression-counts.json.

## Delivery state

Fourteen scoped implementation paths remain uncommitted in the repair checkout;
no commit, merge or push was made. The parent's two pre-existing verification
report edits were not changed by this implementer. Code/report evidence is ready
for the parent's consolidated current report and archive. No additional test
rerun is needed on the unchanged implementation.
