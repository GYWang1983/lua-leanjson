# Native macOS ARM64 verification

Run date: 2026-11-03. Checkout: `33d00b522d87cc760f757404186488453ffcb498` on `verify/full-suite-2026-11-03`. This is a separate host-native run; it does not alter the primary Linux evidence.

## Result

All requested native gates passed:

- `cargo test --locked --release`: 444 passed, 0 failed.
- `cargo test --locked --release --no-default-features`: 444 passed, 0 failed.
- `cargo test --locked --features test-panic --release`: 445 passed, 0 failed.
- `cargo clippy --locked --release --all-targets -- -D warnings`: exit 0 with no warnings or errors.
- Installed-package smoke from `/tmp/lua-qjson-native-macos-smoke-20261103`: passed. It exercised memory/file/feed/fork/get/reader/close and OpenResty imports.

Each gate has a separate raw log and receipt. Machine-readable records are in [`receipts.json`](receipts.json).

## Toolchain and provenance

Host: macOS 27.0, Darwin 27.0, ARM64 (`aarch64-apple-darwin`). The host initially had no Rust, Cargo, LuaJIT, Busted, Clippy, or `resty`. Rust was installed only under the task-local `RUSTUP_HOME` and `CARGO_HOME`; all Cargo gates used the isolated [`target/`](target/) directory.

- Rust: `rustc 1.90.0 (1159e78c4 2025-09-14)`, commit `1159e78c4747b02ef996e55082b704c09b970588`; Cargo `1.90.0 (840b83a10 2025-07-30)`; Clippy `0.1.90`.
- LuaJIT: source branch `v2.1`, commit `ea9eb7edb5eac4a9d175d74523db34fac0fa5180`; installed version `2.1.1793383622`. Binary SHA-256: `ecc6bb7e34fbfeea3cbf3d3baa939367d46b701a6cdda2c6576996a9a9f452b6`; dylib SHA-256: `126ee8007a8eefc686f162be4b2efa35fffd6d964ddd967f1b19c952542224ef`.
- LuaRocks: `/opt/homebrew/bin/luarocks` 3.13.0 was used only as the package-manager executable; the package was installed into the task-local [`rocks/`](rocks/) tree with the task-local LuaJIT prefix.
- Native Cargo release dylib from the isolated test target: `target/release/deps/libleanjson.dylib`, SHA-256 `9f21b543dc754936d926298d5e1b2878937b01aeb60b7ea52af305bb0a24ac14`.
- Installed module: `rocks/share/lua/5.1/leanjson.lua`, SHA-256 `d3e0f5aab6c7d544528505330c277eb9004a13a96b4f25289a030993071fd0bf`.
- Installed native module: `rocks/lib/lua/5.1/leanjson.so`, SHA-256 `65a84e3e6150bad2aec13cbaba69279ff7549f190bdbb679df289606be480cdb`.

The package source used for LuaRocks was a `git archive` of the exact checkout HEAD under [`package-source/`](package-source/), with its build target isolated at `package-source/target/`.

## First setup error

The first LuaJIT build command failed before compilation because its Makefile requires `MACOSX_DEPLOYMENT_TARGET`:

`Makefile:322: *** missing: export MACOSX_DEPLOYMENT_TARGET=XX.YY. Stop.`

That failure is retained in [`luajit-provision.log`](luajit-provision.log) and recorded as `luajit-provision-initial`; it is setup-only and not counted as a product/test failure. A single diagnostic retry with `MACOSX_DEPLOYMENT_TARGET=13.0` succeeded, with its own [`luajit-provision-retry.log`](luajit-provision-retry.log).

## Installed-package isolation

The smoke ran from `/tmp/lua-qjson-native-macos-smoke-20261103`, not the checkout, with:

- `LUA_PATH` restricted to the isolated `rocks/share/lua/5.1` paths;
- `LUA_CPATH` restricted to the isolated `rocks/lib/lua/5.1/?.so` path;
- `LD_LIBRARY_PATH` unset;
- `DYLD_LIBRARY_PATH` unset.

The actual module/native paths and hashes are in [`installed-package-smoke.receipt.txt`](installed-package-smoke.receipt.txt) and [`installed-package-smoke.log`](installed-package-smoke.log).

No tracked runtime, test, script, or build files were edited. Parent-owned documentation changes remain outside this native evidence scope.
