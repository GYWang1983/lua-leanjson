local json=require 'leanjson'
local io_source=require 'leanjson.source_io'
local ffi=require 'ffi';ffi.cdef[[int fcntl(int,int,...);]]
local path=os.tmpname();local f=assert(io.open(path,'wb'));f:write('{"v":1}');f:close()
for _,operation in ipairs({'reader','fork'}) do
 local original=io_source.open;local fd
 io_source.open=function(p) local n,e=original(p);fd=n;return n,e end
 local held=json.decode_file(path,{index_depth=0,index_budget_bytes=0});io_source.open=original
 local virtual=setmetatable({}, {__len=function()return 2 end,__index=function(_,i)
  if i==1 then return held end
  json.close(held);coroutine.yield('snapshot-suspended');return false
 end})
 local co=coroutine.create(function()return json[operation](virtual) end)
 local ok,why=coroutine.resume(co);assert(ok,why);assert(why=='snapshot-suspended')
 print(operation,'during-suspension-fd-open',ffi.C.fcntl(fd,1)~=-1)
 co=nil
 collectgarbage('collect');collectgarbage('collect');collectgarbage('collect')
 print(operation,'after-abandon-and-GC-fd-open',ffi.C.fcntl(fd,1)~=-1)
end
os.remove(path)
