### Task 1: implement and validate safe codecs

**Files:** new `lua/leanjson/safe.lua`, `tests/lua/safe_spec.lua`; rockspec install list; upstream worker/control tests; README, F04 checklist and verification report.

**Interfaces:** Safe API table shares stateless helpers/constants from its private `leanjson.new()` codec and exposes its protected encode/decode/source functions plus a safe `new()` factory.

- [ ] Add success/error arity, config isolation, invalid options, file/feed cleanup, and all nine loading/source tests. Run focused Busted; expected RED because `leanjson.safe` is absent.
- [ ] Add the safe adapter and packaging entry; rerun focused tests; expected GREEN with no real cjson fallback.
- [ ] Add real safe facade/source-dispatch controls, observe RED against the old unsupported adapter, update the harness and fault-injected missing-safe controls; expected GREEN.
- [ ] Run `make test lua-lint openresty-test`, all Python harness tests, and the full pinned nine-cell matrix with prepared Czech locale. Verify packaging install includes safe.lua. Report actual remaining differences, not merely successful report generation.
- [ ] Update API/checklist/report, obtain independent read-only review of the F04 delta, fix important findings with regressions. Archive evidence and retain code uncommitted.
