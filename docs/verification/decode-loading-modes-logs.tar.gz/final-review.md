# Final whole-change review — eager decoding and explicit path preloading

Reviewed base `634f82705b0315406d26e29e0adf828852c97272` through
head `41991f0`, including runtime revision
`1bacb136c6be27b91493dd39ab18271b0b471cfd`.
Binding requirements: `docs/design/2026-11-02-decode-loading-modes.md`;
implementation plan: `docs/plans/2026-11-02-decode-loading-modes.md`.

## Strengths and plan alignment

- **The zero-index requirement is implemented independently of optional indexes.**
  `src/source/loading.rs:115` advances shared selector prefixes during the existing
  strict source scan, while `src/source.rs` keeps loading state/events separate
  from its optional-index admission policy. `lua/leanjson/loading.lua:135` retains
  selected nodes and necessary route nodes in their own immutable source cache.
  `lua/leanjson/nodes.lua:33` consults that cache before native source lookup.
  The deep/far and wildcard evidence exercises all three index bounds at zero;
  unselected values remain lazy and full untouched output retains its input bytes.
- **Eager values are constructed directly and have the requested ordinary-table
  behavior.** `lua/leanjson/loading.lua:88` creates ordinary tables/scalars, retains
  empty-array identity, and replaces duplicate decoded keys by their final whole
  value. `lua/leanjson/table.lua:40` releases the memory source before returning an
  eager result; `lua/leanjson/source.lua:146` releases the file owner after taking
  its plain result. No proxy or hidden source lease is attached to ordinary values.
  The no-cjson fixture covers eager construction, repeated Decoder results and
  selected raw numeric output without making cjson a dependency.
- **Selection and source semantics remain compatible.**
  `lua/leanjson/loading.lua:120` removes earlier selected descendants when a later
  duplicate ancestor has no matching descendant. Complete selections retain lexical
  entries and final members separately. `lua/leanjson/nodes.lua:112` therefore
  supports lexical duplicate snapshots and current linked children without
  mutating the source cache. Source-backed nodes retain their original span, so
  reading a selected large integer does not replace its output spelling. Existing
  object patches, array segments and readers continue to use immutable base nodes.
- **Option validation and ABI integration are coherent.**
  `lua/leanjson/loading.lua:10` compiles a dense path array before file/spool
  acquisition; `lua/leanjson/options.lua:31` retains its immutable compiled
  selector. Eager mode still validates supplied paths. The new header, cdefs,
  required-symbol checks, panic-boundary exports and rockspec entry agree, and the
  added layout assertions leave published v1/v2 layouts unchanged. The legacy
  contiguous parser is not redirected through the new loading implementation.
- **The previous cancellation finding is resolved in the final runtime.**
  `lua/leanjson/loading.lua:177` registers scratch source and builder cleanup in
  the initiating scope, clears all frame payload references, detaches the native
  finalizer and releases the source once. Its checks after a yielded read prevent
  late use of the canceled resource. The same cleanup runs on success/error, and
  its fallback token handles abandoned work. The regression cases check immediate
  cleanup while retaining a suspended coroutine, including both repeated finish
  and container get.
- **Decoder and Session behavior are distinguished correctly.**
  `lua/leanjson/source.lua:207` transfers the initial eager result and rebuilds
  subsequent values from immutable source spans. The unchanged
  `lua/leanjson/openresty.lua:128` and `:144` query/return the Session's one completed
  value, so Session edits remain visible. I inspected the adapter's normalization,
  completed-body fallback and socket producer paths; both loading options survive
  the HTTP overrides and the two lifecycle contracts agree with the documentation
  and real HTTP assertions.
- **Memory/performance claims are appropriately limited.**
  `docs/verification/decode-loading-modes.md:8` identifies the final runtime and
  distinguishes the original canonical gate from the narrow Lua ownership fix.
  Its measurement table matches the reviewed final records, and its discussion
  explicitly discloses eager encode/ordinary-reader costs above cjson. Selected
  payload/key counts have logical units and explicitly exclude allocator, table,
  selector and process-memory overhead. No universal memory or CPU parity is implied.

## Issues

### Critical — must fix

None found.

### Important — should fix

None found. The earlier Task 1 I1 is addressed by `1bacb13`; it is not an open or
deferred finding.

### Minor — nice to have

None independently actionable found.

## Review and verification evidence

- Read the supplied `review-634f827..41991f0.diff` package once in bounded portions,
  including all five commits and every changed text file. Recovered only output
  sections truncated by the tool. Read the binding design, plan, progress ledger,
  implementation/fix report and previous scoped reviews.
- Inspected supporting unchanged code only for named integration risks: node
  overlays/array segments, proxy source ownership and linked children,
  `leases.track`/`finish`/`release`/fallback semantics, backend read/callback
  cancellation, reader raw-span/normalization behavior, and OpenResty option and
  Session forwarding. No additional reviewer or subagent was dispatched.
- Inspected supplied execution evidence, rather than rerunning completed suites:
  canonical **435 Lua successes** and **60 HTTP checks** at `db052d4`, Rust matrices,
  property/stress/corpus scopes, fuzz compilation and installed-tree smoke. The
  final Lua-only fix has **60 covering loading/lifecycle/review successes** and
  **67-file Lua lint with zero warnings/errors**. These are historical run
  artifacts at their reported revisions, not fresh whole-suite results from this
  review. No native build, full suite, fuzz campaign or benchmark was rerun.
- Independently checked the current Lua tree fingerprint against
  `acceptance-reviewed/environment.json`:
  `c6f539b2f4971378e62756cfdda779a6d340227f6ef83ed2126e91aa2e827843`.
  The environment intentionally records the pre-commit dirty checkout, and the
  matching current fingerprint validates the final content provenance. Verified
  **all 86 archive manifest hashes**, both archived probe sources against the
  current files, and all **18 final worker logs against their result records**.
  Every final oracle is true, the displayed measurements match, and selected-read
  callback deltas are zero. Native code was not changed by the ownership fix.
- Ran one focused public-API probe for an uncovered integration combination:
  a fully preloaded array beneath a route-only root, array insertion/removal,
  shifted held-child identity, a fork, a reader frozen before mutation, and held
  children surviving closure of their parents. Repeated it with `$` to isolate
  the ancestor metadata dependency. Both cases passed; selected reads after edits
  caused zero source callbacks, output semantics were correct, and the frozen
  reader retained the original bytes.

The probe ran under the pinned image
`sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`, with
the workspace and `leanjson-bounded-target` mounted read-only, invoking
`LD_LIBRARY_PATH=/workspace/target/release LUA_PATH='./lua/?.lua;;'
/usr/local/openresty/luajit/bin/luajit -` and supplying Lua through stdin.
Its only temporary data was the ordinary decoder spool inside the disposable
container. The executed stdin source and actual stdout are retained alongside
this report as `final-review-array-probe.lua` and `final-review-array-probe.log`.
Final output:

```text
PASS $.a array edits, shifted held child, fork/snapshot isolation, child leases; insertion callbacks 21 selected-read callbacks 0
PASS $ array edits, shifted held child, fork/snapshot isolation, child leases; insertion callbacks 0 selected-read callbacks 0
```

The first version of that probe overreached by asserting zero callbacks across
both mutations and reads. Tracing `nodes.changed` through the selected child's
route-only root established that the root's member count can require a source
scan. Separating those phases and selecting `$` confirmed the cause; no runtime
change was needed. This failed probe assumption is not presented as a passing
runtime regression or silently discarded.

## Recommendations

No implementation changes required by this review. Preserve the documented
revision and measurement boundaries in the final user-facing completion report.
There are no parked or deferred code findings.

## Declined to judge

- Full JSONPath, recursive descent, filters, slices, unions and JSON Schema:
  intentionally outside the binding subset; unsupported expressions are rejected.
- A worst-case RSS/CPU bound at or below cjson, or redesign of the ordinary-table
  reader snapshot/encoder: explicitly outside the binding loading-mode contract;
  the reviewed evidence discloses cases that exceed cjson and establishes no parity.
- Zero source I/O for writes through route-only ancestors: the contract guarantees
  ready selected data and I/O-free selected reads, while existing mutation semantics
  may inspect unselected ancestor metadata. The isolated probe verified this
  distinction without finding a correctness or selected-read regression.
- Kong integration, production-provider behavior, deployment/publication or remote
  Git actions: expressly excluded from this plan; local HTTP tests and process
  measurements do not establish those behaviors.

## Assessment

**Ready to merge? Yes.**

The final implementation meets the binding eager/selective loading contracts,
including selected data and routing metadata bypassing all zero-valued automatic
index bounds while preserving lazy access and complete output. Ownership, ABI,
duplicates, overlays and adapters integrate correctly; the final evidence is
traceable and does not overstate full-suite reruns or cjson memory parity.

This review changed only the requested scratch report and, at the controller's
follow-up request, its focused probe source/output artifacts. No runtime source,
repository tests, index, HEAD, branch state or remote state was changed.
