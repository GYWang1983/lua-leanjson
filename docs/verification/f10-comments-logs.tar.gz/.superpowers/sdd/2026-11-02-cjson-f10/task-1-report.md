# Task 1 implementation report

Implemented the complete F10 comment policy in the assigned existing worktree. No commits, branch changes, pushes, subagents, whole-project formatting, upstream expectation changes, adapter normalization changes, or runtime cjson fallback.

## Decisions and behavior

- `decode_allow_comment` defaults false independently for the ordinary module, `new()`, safe module and safe factories. It uses existing atomic boolean/on/off settings validation, including native getter/nil/arity errors.
- Codec policy is snapshotted through normalized source options. Native source v2 gains additive mode bit 4; `SourcePolicy` carries it through existing initial/loading, cached and unindexed/resumed/linked walkers, selected paths and eager incremental rebuilds. C zero mode, source v1 and legacy `parse` remain strict; no shared C structure layout changed and no new FFI export was needed.
- A four-state shared comment scanner retains no comment payload. Native trivia includes line comments through LF/EOF (CR alone does not end them), non-nested block comments, adjacent comments, and comments before/after values/keys/colon/separators. A slash inside an incomplete literal or number does not concatenate lexical fragments.
- The companion native diagnostic tokenizer uses the same scanner, retaining byte positions and original machine-readable error results. Unterminated blocks fail at EOF or the first embedded NUL; the initial two-byte encoding diagnostic still wins where native does.
- Additive span flag 16 marks containers containing actual comments, propagating to ancestors independently of duplicate/string/nonfinite flags. The reader reconstructs affected containers through existing bounded iterators, including empty containers, while unaffected child spans retain original spelling. Leading/trailing comments outside the root span are naturally excluded.
- `keep_origin` records affected containers as incomplete for whole-span reuse; clean child/string origins remain reusable. Depth checks operate through reconstructed container traversal, so comment brackets never enter the raw depth scanner. Existing reader leases/cancellation remain the cleanup path.

## Changed files owned by this task

Runtime: `src/source.rs`, new `src/source/comment.rs`, `src/source/diagnostic.rs`, `src/source_ffi/sparse.rs`, `include/leanjson.h`, `lua/leanjson.lua`, `lua/leanjson/lib.lua`, `lua/leanjson/options.lua`, `lua/leanjson/source_backend.lua`, `lua/leanjson/table.lua`, `lua/leanjson/reader.lua`.

Tests: new `tests/lua/cjson_comments_spec.lua`; `tests/source_cjson_policy.rs`, `tests/source_depth_diagnostics.rs`, `tests/source_sparse.rs` (unknown-bit tests now reject bit 8 rather than newly supported bit 4).

Parent-owned files and artifacts were not changed.

## RED/GREEN evidence

All commands ran in `lua-qjson-dev:task3-repro`, repository mounted at `/workspace`, target volume `leanjson-bounded-target`, registry volume `qjson-cargo-registry` where Rust was invoked, with native LuaJIT `/usr/local/openresty/luajit/bin/luajit` and Lua `LD_LIBRARY_PATH=/workspace/target/release`.

Evidence directory: `.superpowers/sdd/2026-11-02-cjson-f10/task-1-artifacts/`.

- `rust-red.log`: `cargo test --release --test source_cjson_policy comments_ -- --nocapture` — 2 expected failures, mode 4/7 rejected before implementation.
- `lua-red.log`: focused comment suite — 16 expected failures, all caused by missing `decode_allow_comment` before implementation.
- `rust-focused-green.log`: `cargo test --release --test source_cjson_policy --test source_depth_diagnostics --test source_sparse` — 24 passing tests.
- `build-default.log`: coordinated `cargo build --release` success; parent notified before independent oracle runs.
- `lua-focused-green.log`: focused suite — 16 successes, no failures/errors, including final NUL/legacy and bounded-window assertions.
- `lua-full.log`: full `tests/lua` — 583 successes, no failures/errors.
- `lua-lint.log`: `make lua-lint` — 83 files, no warnings/errors.
- `git diff --check` succeeded.

The first focused Lua GREEN attempt found a test-only exact key-order assertion on an eager ordinary table; it was corrected to assert decoded fields and comment-free output because eager table hash order is unspecified. No runtime correction was needed.

Coverage includes ordinary/safe/new isolation; nine lazy/eager/preload x memory/file/feed cells; selected and unselected fields; changes after decoder creation and repeated finish/get; zero indexes; nested clean raw spelling; modified/forked/cross-codec output; duplicate normalization; keep_origin; string/key comment-like text; all split points for valid/malformed comments and touching invalid tokens; CR/CRLF; block NUL and initial encoding precedence; output depth; and reader cancellation during length/next. Large comments are exercised with bounded 127-byte backend reads, 7-byte output chunks, disabled scalar materialization and no loading payload for comment bytes.

## Boundaries

Existing strict raw control-byte and embedded-NUL acceptance boundaries remain; in particular native may accept a completed root followed by a line comment ending at an embedded NUL, while LeanJSON still rejects embedded NUL under the pre-existing F17 policy. No general canonical-output guarantee was added: unaffected valid/raw numeric spellings remain reusable. Instrumented reads and scanner state establish bounded comment processing, not a whole-process RSS bound.

Parent owns full Rust default/scalar/panic, Clippy, HTTP/upstream matrix/controls, installed-only checks, independent review, integration, and final overall report. No failures in the implementer's completed verification remain.
