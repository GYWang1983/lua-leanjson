local kind = assert(arg[1])
if kind == "native-cjson" then
    package.preload.leanjson = function() error("LeanJSON forbidden in native control") end
    local cjson = require("cjson")
    for _ = 1, 10 do
        local value = cjson.decode('{"ab":"cd","nested":["ef","gh","ij"]}')
        assert(value.ab == "cd" and value.nested[2] == "gh")
        assert(cjson.encode("cd") == '"cd"')
        assert(cjson.decode(cjson.encode(value)).ab == "cd")
    end
    assert(not package.loaded.leanjson)
elseif kind == "ffi-string" then
    local ffi = require("ffi")
    ffi.cdef[[void *malloc(size_t size); void free(void *pointer);]]
    local raw = assert(ffi.C.malloc(4))
    local bytes = ffi.cast("uint8_t *", raw)
    bytes[0], bytes[1] = 97, 98
    -- The two padding bytes are inside the allocation but outside the explicit
    -- ffi.string length. LuaJIT's optimized interning compares them then masks.
    assert(ffi.string(bytes, 2) == "ab")
    ffi.C.free(raw)
    assert(not package.loaded.leanjson and not package.loaded.cjson)
elseif kind == "leanjson" or kind == "leanjson-padded" then
    local native_attempted = false
    assert(not package.loaded.cjson)
    package.preload.cjson = function()
        native_attempted = true
        error("native cjson forbidden in LeanJSON control")
    end
    if kind == "leanjson-padded" then
        local ffi = require("ffi")
        local original = ffi.string
        local padded_type = ffi.typeof("uint8_t[?]")
        ffi.string = function(pointer, length)
            if length == nil then return original(pointer) end
            if length == 0 then return "" end
            local padded = ffi.new(padded_type, length + 4)
            ffi.copy(padded, pointer, length)
            return original(padded, length)
        end
    end
    local json = require("leanjson")
    local raw = '{"ab":"cd","ef":["gh"],"n":-0.0,"x":0}'
    for _, source in ipairs({ "memory", "file", "feed" }) do
      for _, loading in ipairs({ "lazy", "eager", "preload" }) do
        for _, carrier in ipairs({ "table", "userdata" }) do
            local opts = { lazyload = loading ~= "eager", proxy_mode = carrier,
                preload_paths = loading == "preload" and { "$.ab" } or nil }
            local body
            if source == "memory" then body = json.decode(raw, opts)
            elseif source == "file" then
                local name = os.tmpname()
                local f = assert(io.open(name, "wb")); assert(f:write(raw)); f:close()
                body = json.decode_file(name, opts); os.remove(name)
            else
                local input = json.new_decoder(opts)
                for i = 1, #raw do assert(input:feed(raw:sub(i, i))) end
                body = assert(input:finish()); input:close()
            end
            assert(body.ab == "cd" and 1/body.n == -math.huge)
            local items = body.ef
            assert(items[1] == "gh")
            json.close(items)
            body.x = 2
            assert(json.encode(body):find('"x":2', 1, true))
            json.close(body)
        end
      end
    end
    -- Failed Lua 5.1 require leaves a non-table loading sentinel behind.
    assert(native_attempted and type(package.loaded.cjson) ~= "table")
else error("unknown control") end
print(kind .. " attribution control passed")
