"""Archive this plan's evidence, then verify every file from the archive."""
import hashlib
from pathlib import Path
import tarfile

scratch = Path(__file__).resolve().parent
root = scratch.parents[2]
archive = root / "docs/verification/upstream-cjson-compatibility-logs.tar.gz"
files = sorted(p for p in scratch.rglob("*") if p.is_file() and p.name != "SHA256SUMS")
manifest = scratch / "SHA256SUMS"
manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + str(p.relative_to(root)) + "\n" for p in files))
with tarfile.open(archive, "w:gz", compresslevel=6) as output:
    for path in files + [manifest]:
        output.add(path, arcname=str(path.relative_to(root)), recursive=False)
with tarfile.open(archive) as saved:
    members = saved.getnames()
    assert len(members) == len(set(members)) == len(files) + 1
    for line in saved.extractfile(str(manifest.relative_to(root))).read().decode().splitlines():
        digest, name = line.split("  ", 1)
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
        assert hashlib.sha256(saved.extractfile(name).read()).hexdigest() == digest, name
print(f"Verified {len(files)} evidence files, {archive.stat().st_size} bytes")
print(f"Archive SHA256 {hashlib.sha256(archive.read_bytes()).hexdigest()}")
