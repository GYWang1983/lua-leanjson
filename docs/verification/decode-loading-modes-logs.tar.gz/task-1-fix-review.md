**I1 — Repeated eager rebuild retains partial values and native resources after explicit close while suspended** — **ADDRESSED**.

- `lua/leanjson/loading.lua:177–193` registers the scratch native source and builder in the initiating scope. Cleanup clears the builder root, all frame payload references, stack and frame arrays, and scratch source field; it nulls the captured source, detaches its GC finalizer and releases it immediately.
- `lua/leanjson/leases.lua:58–79` confirms explicit holder release executes registered cleanup synchronously and removes the cleanup callback before calling it. The subsequent `leases.finish` at `lua/leanjson/loading.lua:212` is therefore idempotent after cancellation and also releases resources after normal return or a caught error.
- `lua/leanjson/loading.lua:200–204` checks the scope and source after the yielding read and before native feed or builder access. The unchanged read/notification checks in `lua/leanjson/source.lua:75–103` also reject late resumed callbacks. No canceled scratch pointer can reach the following native operations.
- `tests/lua/decode_loading_spec.lua:319–371` covers both repeated `finish()` and container `get()`, suspends after multiple populated reads, verifies immediate source/payload/record cleanup while retaining the suspended worker, collects the weak partial-array observer before resuming, and verifies the closed error on late resume. `tests/lua/decode_loading_spec.lua:374–430` verifies cleanup on successful completion and injected source errors while preserving successful values.

### New Breakage in the Fix Diff

None found.

### Out-of-Scope Observations

None.

### Checks

- Read the supplied `review-cd3e503..1bacb13.diff` once and checked only its runtime/test changes plus supporting builder, lease and read/callback ownership semantics. No Git commands, builds, runtime mutations or test reruns.
- Confirmed the appended fix report names the covering loading/lifecycle/review suites and exact commands. Inspected `task-1-review-fix-green.log`: **60 successes / 0 failures / 0 errors / 0 pending**. Inspected `task-1-review-fix-lint.log`: **0 warnings / 0 errors in 67 files**. These are supplied run artifacts, not independently rerun results; the new cases match the reported I1 coverage.

### Verdict

**Fix round: All findings addressed, no new Critical/Important breakage.**
