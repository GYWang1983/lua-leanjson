# SDD ledger — plan: docs/plans/2026-11-02-upstream-cjson-matrix.md

Base b928a20505165fc3c0f3399b68500cd02050b42f. Worktree /Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata, branch test/upstream-cjson-matrix. User explicitly requests subagent adaptation of full upstream lua-cjson functional suites and lazy/eager/preload by memory/file/feed matrix.

Existing isolated worktree reused, clean baseline at b928a20; last-turn merge verification on that exact tree passed 428 Rust,439 Lua,60 HTTP tests (log /tmp/leanjson-main-b928a20-merge-validation.log). No runtime edits or intervening code changes. No CodeGraph index. No relevant memory hits.

| Tasks | Shared file/interface | Preflight result |
| --- | --- | --- |
| 1 / 1 | Upstream inventory, adapter, target dispatch, baseline, classification | Coherent: adapters preserve expected assertions and enumerate unsupported behavior; strict parity exit is separate from healthy report generation. |
| 2 / 2 | Independent inventory/provenance audit and documentation/archive | Root audits actual evidence without editing implementation; all incomplete/conditional/baseline outcomes remain visible. |
| 1 / 2 | Machine-readable matrix inventory/results and run evidence | Root consumes task output, verifies completeness and provenance; exact artifact layout chosen by implementer and reported before audit. No concurrent native builds. |

Ruling: Use the existing pinned OpenResty lua-cjson source and tests at617164a as the reproducible reference, retaining all original assertions — repository already supplies this baseline and user asks for upstream coverage — newer upstream revisions require a deliberate later update.
Ruling: This task builds and executes compatibility validation, recording runtime incompatibilities rather than changing product semantics or faking API support — user asked to adapt tests and verify behavior — a failed compatibility case remains a product gap until separately fixed; report execution success cannot be called full compatibility.

Task1 pending; Task2 pending. Root owns docs/evidence; one Sol6.1max implementer will own test infrastructure. No push/merge/publication in this new task.

Task1 dispatched to /root/cjson_matrix_implementation (gpt-6.1-sol max), BASE f653902. Artifact contract: task-1-artifacts/{inventory.json,provenance.json,commands.jsonl,build.log,baseline/,matrix/<mode>-<source>/,selective/<source>/,negative-controls/,project-test.log,summary.json}. Root does not run concurrent heavy native jobs.

Task2 independent pre-audit: root-inventory.json enumerates131 test.lua rows (128 assertions,3 helpers),24 agentzh blocks,9 JSON cycle fixtures =>164 total records per cell. Hashes of suites/helpers/fixtures recorded. Root separately generated Unicode scalar fixture with Python; matches upstream expected MD5cff03b039d850f370a7362f3313e5268 and length4382592, SHA256e0a7693f7362e88827c15e772e55b3490bd983f90711df7f3ef36c2b1ef6847e. Caller must expose locale unavailability and Lua5.3-only branch as conditional/non-applicable rather than passes.

Root early implementation audit reconciled generated inventory with independent line IDs/hashes; identified cleanup host/docker dispatch and omitted supplemental strict status, both fixed before initial full run. Also requested real existing object-field sparse selection instead of absent-only path; covered by new red/green control. Initial complete primary baseline158pass/2setup/4env; all9cells15pass/21difference/124unsupported/4env. Supplemental Lua config table serialization fixed with red/green control; preserved failed attempt and retried supplemental only. Task1 full make test439Lua plus Rust passed on harness-only changes.

Root extended environment verification: original image has localedef but lacks cs_CZ source/data. Generated cs_CZ inside disposable container using downloaded Ubuntu locales2.35-0ubuntu3.15 package, source package SHA and command logs retained under locale/. Initial probe incorrectly expected LuaJIT string.format to honor locale; actual os.setlocale succeeds and libc localeconv confirms comma while LuaJIT format remains invariant. Corrected independent probe preserves this distinction. Requested final run with explicit locale-dir provenance to eliminate3 avoidable env exclusions. Lua5.3 conditional remains inapplicable to LuaJIT.

Root final precommit audit requests (in progress): classify missing cjson.safe constant/module access explicitly; propagate failed reset setup to configuration getters. No product runtime mutation requested. Root audit script ready; final task and whole-change reviews pending.

Task1 implementation complete cd5e329; formal task review dispatched to /root/cjson_matrix_task_review (Astra high), package f653902..cd5e329. Early classification/metadata findings fixed with regressions; final baseline160pass/3setup/1env, all9cells15pass/14difference/134unsupported/1env. Seven controls pass, project make test428Rust/439Lua pass. Direct strict CLI exit1 is expected incompatibility, not harness failure.

Task2 independent audit completed: root-audit-results.json reconciles1476 primary records and provenance. root-supplemental-audit.json verifies all240 supplemental records;36 equal successful decoded values/source,35 combinedpasses. The extra2^53 roundtrip failure also occurs in nativecjson default14digit output; report distinguishes this extra invariant from target-only precision16 API incompatibility. Original unmodified reference test.lua plus9fixtures137/137passed. README and permanent report drafted; archive and task/finalreviews pending. Runtime and vendor trees unchanged.

Task2 initial review cd5e329..0014611 approved by /root/cjson_matrix_evidence_review (Sol high). Minor deferred to final archive refresh: archive must include completed independent review reports promised by docs. Independent reviewer verified2860archivedhashes and raw totals. Cannotverify unchanged Task1 runtime is covered by Task1 explicit gate; finalreview still pending. Task1 reviewer found Important false incompatibility classification of supplemental2^53 lossless invariant despite equal native behavior; no requirement supports folding stronger invariant into cjson compatibility. Await full finding list before unified fix dispatch.

Task1 review complete:1Important false supplemental incompatibility,1Minor stale summary/error coexistence. Task1 minor(deferred): repeated output directory may retain conflicting old status files; finalreview to triage. Cannotverify runtime/vendor resolved by empty git diff; archive by Task2 hashverification. Fix round1 starting from0014611, originalimplementer will fix classification and synchronizedreport with focusedregression and refreshedmatrix only. No new productchanges.

Task1 fix round1 commits0014611..d2c3c29(c028011 runtimeharnessfix+d2c3c29report). Eightcontrols pass with realprecision loss red/green; refreshed fullmatrix strict1 healthytrue; supplemental36pass/44difference, separate losslessdiagnostics37complete/1incomplete/42notrun. Root primary/supplemental audits rerunpass. Scoped rereview /root/cjson_roundtrip_rereview Solhigh dispatched onfixpackage; pending. Prior final retainedbefore-roundtrip-fix.

Task1 fix round1/5:1addressed,0openImportant; scopedrereviewclean. Task1 complete(commitsf653902..d2c3c29, reviewclean;Minorstalestatusdeferred). Task2 complete(docs0014611, synchronizedc028011;reviewapproved;minorarchive-reviewreportsresolved bycurrentrefresh). Finalwholebranchreviewpending; no parkedfindings. Both originalRulingsremain; no newscopechanges.
