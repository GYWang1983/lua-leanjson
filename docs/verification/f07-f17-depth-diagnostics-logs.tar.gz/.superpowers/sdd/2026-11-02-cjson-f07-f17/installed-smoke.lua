local prefix = ...
package.path = prefix..'/share/lua/5.1/?.lua;'
package.cpath = prefix..'/lib/lua/5.1/?.so;'
package.loaded.cjson=nil
package.preload.cjson=function() error('native cjson denied',0) end
local json=require 'leanjson'
local safe=require 'leanjson.safe'
local c=json.new();c.decode_max_depth(6000);c.encode_max_depth(6000)
local raw=string.rep('[',5000)..'0'..string.rep(']',5000)
for _,opts in ipairs({{index_depth=0,index_budget_bytes=0},{lazyload=false},{preload_paths={'$'},index_budget_bytes=0}}) do
 local value=c.decode(raw,opts);assert(c.encode(value)==raw);c.close(value)
end
local d=c.new_decoder({chunk_size=7})
assert(d:feed('{"a" '));local ok,err=d:feed('"bad\\q"}')
assert(ok==nil and err=='Expected colon but found invalid escape code at character 10');d:close()
local value,syntax=safe.decode('{"a":')
assert(value==nil and syntax=='Expected value but found T_END at character 6')
local r=c.reader(c.decode('[[[0]]]')); c.encode_max_depth(1)
assert(r:length()==7);r:close()
local s=c.reader({c.empty_array});assert(s:length()==4);s:close()
local function failure(fn,...)
 local good,message=pcall(fn,...);assert(not good);return message
end
assert(failure(c.encode,{[c.null]=1})=='Cannot serialise userdata: table key must be a number or string')
assert(failure(c.encode,c.decode('[[0]]'))=='Cannot serialise, excessive nesting (2)')
local f=assert(io.open('/proc/self/maps','r'));local maps=f:read('*a');f:close()
assert(maps:find(prefix..'/lib/lua/5.1/leanjson.so',1,true),'installed native library not mapped')
assert(not maps:find('/workspace/target/release/libleanjson.so',1,true),'source native fallback')
print('installed-only F07/F17 smoke passed; cjson denied; installed mapping verified')
