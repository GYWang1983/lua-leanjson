# Extended coverage audit

Read-only audit of the completed extended receipts and raw logs for HEAD
`33d00b522d87cc760f757404186488453ffcb498` on
`verify/full-suite-2026-11-03`. No test, build, fuzz, Docker, or benchmark
command was run by this audit. The extended receipt set contains 33 records;
all referenced absolute stdout/stderr paths were present.

## Bounded fuzz and corpus replay

The first bounded-fuzz record is intentionally retained as a setup result:
exit 1, zero targets executed, and 297 seed files copied before Cargo failed
to write `/workspace/fuzz/Cargo.lock` on the read-only checkout. Those files
are seed inputs, not crash artifacts.

The writable-source rerun completed all six requested Linux arm64 targets
with `-max_total_time=30` and produced no artifact files (6,016 output corpus
files were retained):

| target | libFuzzer runs | result |
| --- | ---: | --- |
| `fuzz_parse_eager` | 1,779,887 | pass |
| `fuzz_parse_lazy` | 32,172 | pass |
| `fuzz_ffi_ops` | 4,515,515 | pass |
| `fuzz_depth` | 66,803 | pass |
| `fuzz_numbers` | 2,255,702 | pass |
| `fuzz_source_windows` (`max_len=16384`) | 165,557 | pass |

All six independent `-runs=0` replays exited 0. Raw `Done` counts and seed
inputs were: `fuzz_parse_eager` 297/296, `fuzz_parse_lazy` 14/13,
`fuzz_ffi_ops` 2/0, `fuzz_depth` 2/0, `fuzz_numbers` 11/10, and
`fuzz_source_windows` 297/296. The zero-seed depth and ffi-ops replays are
only libFuzzer's two initialization runs each; they are successful empty-corpus
checks, not substantive seeded coverage.

## Miri

The initial Miri container attempt stopped at exit 130 while the first
`ffi_smoke` call waited on an interactive `rust-src` installation prompt. It
completed zero tests and is a setup/interactivity artifact, not a product
failure. The explicit-install rerun produced 12 independent scalar calls
(`--no-default-features`) across x86_64, i686, and powerpc64, each of
`ffi_smoke`, `ffi_cursor`, `ffi_strings`, and `ffi_ops_interleave`:

| target | assertions | failed | ignored |
| --- | ---: | ---: | ---: |
| x86_64 | 19 | 0 | 0 |
| i686 | 19 | 0 | 0 |
| powerpc64 | 19 | 0 | 0 |
| **total** | **57** | **0** | **0** |

All 12 raw logs have `test result: ok`; all per-test return-code files are
zero.

## Strict ASan

The aarch64 Linux fallback completed all three requested calls with strict
`-Z sanitizer=address`: `ffi_smoke` 6, `ffi_strings` 3, and
`ffi_ops_interleave` 2 assertions, for 11 passed and zero failed/ignored.
No advisory masking or `continue-on-error` was used.

The three x86_64 calls each exited 101 before test execution. Their raw
stderr contains `error: linking with \`cc\` failed` followed by
`cc: error: unrecognized command-line option '-m64'`; each stdout has no
`running N tests` or `test result` line and its receipt is passed=0,
failed=0. These are arm64-container cross-linker/profile failures, not
product-test failures, and x86_64 ASan runtime coverage remains open.

## Native macOS ARM64

The separate `native-macos/receipts.json` and raw logs are for exact HEAD on
macOS 27.0 arm64. Independent release matrices reconciled to the raw logs as
follows:

- `cargo test --locked --release`: 33 result lines, 444 passed, 0 failed,
  0 ignored.
- `cargo test --locked --release --no-default-features`: 33 result lines,
  444 passed, 0 failed, 0 ignored.
- `cargo test --locked --features test-panic --release`: 33 result lines,
  445 passed, 0 failed, 0 ignored.
- `cargo clippy --locked --release --all-targets -- -D warnings`: exit 0,
  zero warnings and zero errors.
- The isolated installed-package smoke ran outside the checkout with both
  dynamic-library path variables unset, restricted Lua paths, and passed the
  memory/file/feed/fork/get/reader/close and OpenResty-import checks.

The first LuaJIT provision record failed before compilation because
`MACOSX_DEPLOYMENT_TARGET` was unset; the explicit `13.0` retry passed. The
failure is setup-only. An earlier extended receipt named
`native-macos-rust-default-cancelled` is also explicitly cancelled before
completion; it is not a conflicting Rust result because the separate native
matrix above is the completed run.

The extended receipt set also now contains a separate `linux-cargo-audit`
pass (1,403 advisories loaded and 117 dependencies scanned). Runtime-profile
receipts outside these completed records are intentionally not treated as
missing product evidence here.

