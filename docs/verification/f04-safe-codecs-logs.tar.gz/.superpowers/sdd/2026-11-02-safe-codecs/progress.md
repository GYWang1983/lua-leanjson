# SDD ledger — plan: docs/plans/2026-11-02-safe-codecs.md

Spec: docs/design/cjson-compatibility-fixes.md F04.
Pre-flight: no shared interfaces between tasks (one integrated task).
Existing linked worktree verified; F03 modifications preserved with preexisting-file hashes in .superpowers/f04-safe/preexisting-files.json.
Native reference probe confirms arity/config failures throw, decode nil/type/conversion failures return a two-value pair, false/null successes return one, and safe instances start at independent defaults.
Task 1: runtime RED 17 missing-module failures -> GREEN 17 safe tests. Harness RED nine unsupported-safe failures -> GREEN nine real safe mode/source paths.
Task 1: make test/lua-lint/openresty-test GREEN (428 Rust/473 Lua/60 HTTP). Python suite 11 pass. Local LuaRocks installation and installed-only native smoke pass. Nine-cell matrix healthy, no previous pass regressed.
Task 1: complete; make test lua-lint openresty-test -> 428 Rust/473 Lua/60 HTTP, zero lint warnings/errors; Python harness 11 pass; installed-only smoke pass. Commands/logs retained under .superpowers/f04-safe.
Final independent review: F04 ready; no blocking findings; focused 17 safe tests independently rerun read-only. Planned archive delivery closes the sole minor observation.
Scope retained: F01/F02/F05/F17 remain separate; native VM OOM classification and universal protection of later operations are not claimed. No commits, pushes, merges or publication.
