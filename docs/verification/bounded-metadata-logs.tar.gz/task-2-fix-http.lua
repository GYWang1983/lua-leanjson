local cjson, http = require("cjson"), require("resty.http")
local method = assert(arg[1])
local origin = "http://127.0.0.1:" .. os.getenv("LEANJSON_TEST_PORT")
local function request(path, body)
    local response = assert(http.new():request_uri(origin .. path,
        { method = body and "POST" or "GET", body = body, keepalive = false }))
    assert(response.status == 200, response.body)
    return cjson.decode(response.body)
end
local function modules(expected)
    local state = request("/module-state")
    assert(state.lean == expected and state.lib == expected and state.adapter == expected, cjson.encode(state))
end
modules(false)
local raw = cjson.encode({ model = "original", items = { { id = 1 } }, prompt = string.rep("x", 131072) })
local settings = method == "leanjson" and { { 0, 0, 0 }, { 1, 1, 64 } } or { { 3, 3, 1048576 } }
for _, cold in ipairs({ 0, 1 }) do
    for _, setting in ipairs(settings) do
        local depth, limit, budget = unpack(setting)
        local route = string.format("/benchmark?method=%s&branches=0&cold=%d&index_depth=%d&index_array_limit=%d&index_budget_bytes=%d",
            method, cold, depth, limit, budget)
        local result = request(route, raw)
        assert(result.sink.bytes == result.output.length)
        if method == "leanjson" then
            local stats = result.index_stats
            assert(stats.index_depth == depth and stats.index_array_limit == limit and stats.budget_bytes == budget, cjson.encode(stats))
            assert(stats.index_bytes <= budget)
        end
        print(cjson.encode({ method = method, cold = cold, mode = result.input.mode, index_stats = result.index_stats }))
    end
end
modules(method == "leanjson")
print("HTTP module/options assertions passed: " .. method)
