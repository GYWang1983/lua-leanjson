# F10 independent task and integration review

Verdict: **PASS — no actionable correctness, spec-compliance, or quality findings.** No P0/P1/P2/P3 issue was found. This is the one independent review of the sole runtime task and the supplied whole-branch review package. It does not replace the parent's remaining verification and integration gates.

## Reviewed scope

- Read `task-1-brief.md`, `task-1-report.md`, the entire `review-package.diff` (tracked and new files), `docs/design/plans/2026-11-02-cjson-f10.md` Global Constraints/Review Focus, and F10 plus its F07/F08/F09/F11/F12/F17 boundaries in `docs/design/cjson-compatibility-fixes.md`.
- Independently read pinned `vendor/lua-cjson/lua_cjson.c` configuration and tokenizer, especially lines 388–395, 1290–1398 and the initial encoding check; checked upstream `tests/test.lua` comment cases 337–360.
- Traced the surrounding source validator, companion diagnostics, cached/resumed/linked walkers, loading events and rebuild, duplicate spill representation, Lua option snapshots, reader traversal, origin reuse, and safe codec factory. The worktree has no `.codegraph/`; direct source inspection was used.
- Reviewed HEAD: `af4f9dfa3149276b6acda3f514f13e49b60a7203`; review package SHA-256: `fc31bed5aa85c558c7806bd115cac1f01af6e0b785c766b95f0beecdd5a96739`.
- No runtime/test/documentation edits, commits, branch changes, subagents, or Rust builds. Only this requested review artifact was written.

## Spec and implementation assessment

1. **Policy and ABI:** `lua/leanjson/table.lua:175`, `lua/leanjson/options.lua:48`, `lua/leanjson/source_backend.lua:40`, and `src/source_ffi/sparse.rs:68` consistently implement an independent default-false boolean/on/off setting, copy it at source creation, and translate it to additive v2 mode bit 4. The same source policy is copied into all walker constructors (`src/source.rs:124`, `src/source.rs:136`; `src/source_ffi/sparse.rs:228`, `:250`). Eager rebuild constructs from the saved backend options (`lua/leanjson/loading.lua:170`). Shared C layouts and existing panic boundaries are unchanged; C zero mode, v1 options and legacy parse remain strict.
2. **Incremental lexical behavior and diagnostics:** the shared four-state scanner in `src/source/comment.rs:3` retains no comment body. LF terminates line comments; CR alone does not. Block comments are non-nested. String/key parsers own their bytes, so quoted markers cannot become trivia. `src/source.rs:464` ends a number at a slash only when comment policy is enabled, and it validates the preceding number before returning to structural parsing. Incomplete literals keep their existing failure path. `src/source/diagnostic.rs:103` uses the same comment scanner while preserving native diagnostic precedence, locations, and the existing separate machine-readable error result. EOF and first embedded NUL in a block remain failures; the initial two-byte encoding diagnostic still wins where native requires it.
3. **Flags and output:** an actual opening comment sets bit 16 on its containing frame (`src/source.rs:413`), and `complete()` propagates all non-clean flag bits to ancestors (`src/source.rs:281`). Cached spans, loading events and spill serialization carry the full flags. Comments outside the root span cannot enter raw output. `lua/leanjson/reader.lua:24` forces affected containers through existing bounded member iterators, including empty containers; eligible clean children retain original spelling. This does not add a materialization pass or a second document representation.
4. **Origin, depth and cancellation:** `lua/leanjson/table.lua:67` makes a comment-bearing origin incomplete, which blocks whole-span origin reuse at the existing `origin_fully_matches` check (`:402`). Clean long child origins and string records remain usable. Affected containers receive normal recursive traversal depth checks instead of the raw byte depth scanner, so comment brackets cannot inflate or conceal depth. Existing iterator leases and reader cancellation remain the cleanup mechanism; no cleanup path was bypassed.
5. **Coverage and quality:** the focused Rust/Lua regressions exercise settings, strict legacy modes, all feed boundaries, lexical adjacency, native diagnostics, all nine loading/input combinations, eager reentry, selected and late fields, raw output, duplicates, keep_origin, depth, bounded reads/loading payload, and cancellation. The implementation reuses existing modules and policy/flag channels, introduces only the small shared scanner helper, and does not change upstream expectations, adapter normalization, error enums or runtime cjson parsing/encoding.

## Independent targeted runtime checks

Ran one read-only Docker invocation against the already built shared library, without any build or full-gate repetition:

`docker run --rm -i -v /Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace:ro -v leanjson-bounded-target:/workspace/target:ro -w /workspace -e LD_LIBRARY_PATH=/workspace/target/release lua-qjson-dev:task3-repro /usr/local/openresty/luajit/bin/luajit -`

Five combined-path checks passed (all reader output used 2-byte chunks, checked its reported length, rejected remaining actual comment markers, and decoded under a strict default codec):

- Cached array prefix with `index_array_limit=1`, `chunk_size=1`, then a resumed walk starting immediately before a comment after a completed number. Fixture: `[1/*a*/,{/*b*/"v":2},/*c*/[3/*d*/],{"v":4/*e*/}]`. Checked late direct reads, `ipairs`, exact comment-free output, `materialize(keep_origin=true)` clearing indexes, and subsequent normalized output.
- Linked duplicate replay with zero indexes. Fixture: `{/*root*/"x":{/*old*/"v":1},"mid":[1/*a*/,2],"x":{/*last*/"v":2}}`. Checked both lexical occurrences, last-occurrence lookup, mutation through the attached final child, retained earlier snapshot, and comment-free normalized output.
- The same duplicate/replay check with selective preload `$.x`.
- The same duplicate/replay check with full preload `$`.
- Large origin candidates: an array with a root comment, a clean child whose original whitespace and 80-byte string permit complete origin reuse, a dirty 80-byte-string child, and a comment-only empty array. Checked clean child spelling preservation, omission of every actual comment after `materialize(keep_origin=true)`, encoding the source again after index clearing, and accepted/rejected moved-container depth limits.

Output:

```text
PASS cached array prefix resumes at comment adjacent to completed number
PASS duplicate linked/preload replay 1
PASS duplicate linked/preload replay 2
PASS duplicate linked/preload replay 3
PASS large complete origin candidates keep clean child spelling and omit dirty child comments
TARGETED_REVIEW_CHECKS=5
```

## Limits and integration boundary

- No full Rust default/scalar/panic, full Lua, Clippy/Lua lint, HTTP, installed-only, upstream matrix or broad native-oracle sweep was repeated. Those remain the parent's verification evidence, not reviewer-executed results. The parent's reported 578-fixture/1470-split probe results were supplied as context and were not treated as independent reviewer execution.
- Source inspection plus focused instrumentation establish bounded comment state and existing bounded I/O paths; this review does not establish a whole-process RSS ceiling. Explicit memory-source input, incremental input spools, caller-selected values and requested output remain their existing storage categories.
- The binding plan intentionally preserves stricter existing raw-control/NUL, strict-number and optional UTF-8 acceptance policies. In particular, a completed root followed by a line comment with embedded NUL can be accepted by native while LeanJSON rejects it. That is a retained F17 boundary, not a newly claimed compatibility pass.
- The parent owns the final F10 status/report updates and all final validation/integration. No additional runtime revision or rereview is requested by this review; a subsequently changed runtime diff would need scoped follow-up review.
