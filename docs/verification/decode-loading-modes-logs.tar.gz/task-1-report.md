# Task 1 runtime, ABI and regression report

Status: implementation and verification complete; scoped commit recorded below.
Worktree: `/Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata`
Branch: `feat/decode-loading-modes`; task base: `bc529be`.
No subagents, dependency additions, remote Git actions or broad rustfmt.

## Delivered behavior

- `lazyload` defaults to true and validates as a boolean, independently of strict
  `lazy` validation. Eager memory/file/feed builds ordinary Lua tables/scalars
  directly from scan events. Null/false, scalar roots, final whole decoded
  duplicate values and empty array identity work without optional cjson.
- `preload_paths` validates a dense string array before file/spool creation and
  compiles an immutable native trie with shared prefixes. `$`, quoted/escaped
  keys, dot names, zero-based unsigned indexes and immediate wildcards work;
  malformed/unsupported path forms reject explicitly. Caller array mutation
  cannot change an in-progress decoder.
- The existing strict scanner emits BEGIN/DATA/END construction events only for
  selection routes and selected subtrees. Memory/file/feed drain every bounded
  feed; native validation covers ignored branches without a full metadata tree
  or per-path rescans. Eager sources skip optional indexes even with default opts.
- Immutable selected nodes retain source identity and raw spans, support lookup,
  scalar reads, iteration, normalization, sparse mutation, forks and linked vs
  lexical children. Deep/far selections work with every automatic index bound 0.
  Later duplicate ancestors remove obsolete selected descendants even when their
  replacement has no matching descendant. Untouched bigint tokens/output persist.
- First eager incremental finish transfers its ordinary value and clears the
  builder root. Later finish/get rebuild immutable source spans through bounded
  events, returning independent ordinary values without retaining a second full
  Lua DOM. Container get rebuilds only its target span. Those later calls may read
  the spool/run callbacks. Decoder close still owns the spool lifetime explicitly.
- Eager file results own no descriptor. Close/failure drops partial builders;
  the final file lease clears selected caches. Held children/forks retain their
  own leases and cached data until their last close. Tests cover yielded close,
  late resumed builds, I/O failure, and a kept-alive closed decoder's weak cache.
- OpenResty options forward through `opts.decode` for completed memory/file,
  socket input and chunked fallback. Existing Session semantics remain unchanged:
  it owns one completed value and repeated Session get/finish observe edits to
  that value. This differs from immutable completed Decoder queries and is
  explicitly documented and tested for both eager and selective sessions.
- Added native selector compile/release, loading configure and event drain
  exports. Every export has a panic boundary. Existing v1/v2 struct layouts stay
  unchanged; header/cdef/loader checks and Rust/installed Lua layout assertions
  cover parity. LuaRocks installs `leanjson/loading.lua`.

## Diagnostics

`preloaded_nodes` counts retained complete selected scalar/container nodes;
`preload_path_nodes` counts retained route-only nodes. `preloaded_payload_bytes`
uses logical units: decoded UTF-8 string bytes, 8 per Lua number, 1 per boolean,
0 per null. `preloaded_key_bytes` sums decoded retained cache-key occurrences.
These counts are separate from native `index_bytes` and are not allocator bytes,
total native memory or RSS. Byte counts exclude table/string headers, capacities
and possible string interning. Late ancestor replacement prunes the source cache;
route-only frames keep no unused ordering/lexical arrays. API docs give units.

## Red and targeted verification

All Docker runs bind this worktree to `/workspace`, with volumes
`leanjson-bounded-target:/workspace/target` and
`qjson-cargo-registry:/usr/local/cargo/registry`, working directory `/workspace`.
The pinned image is
`sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`
(`lua-qjson-dev:task3-repro`, Rust 1.90/OpenResty 1.29.2.4).

Focused red command inside the image:

```sh
LD_LIBRARY_PATH=/workspace/target/release busted \
  --lua=/usr/local/openresty/luajit/bin/luajit \
  tests/lua/decode_loading_spec.lua tests/lua/source_options_spec.lua \
  --lpath='./lua/?.lua'
```

`task-1-red.log`: 13 existing policy tests passed; 2 new expected failures:
eager `rawget(value, "a")` returned nil because it was still a proxy; repeated
deep/far selected reads raised callback count from 89 to 1124 after scanning.

Targeted green commands/results:

```sh
cargo test --locked --release --test source_sparse --test source_ffi
cargo test --locked --release --test source_loading
cargo clippy --locked --release --all-targets -- -D warnings
cargo build --locked --release
LD_LIBRARY_PATH=/workspace/target/release busted \
  --lua=/usr/local/openresty/luajit/bin/luajit \
  tests/lua/decode_loading_spec.lua tests/lua/source_options_spec.lua \
  tests/lua/source_lifecycle_spec.lua --lpath='./lua/?.lua'
```

Existing focused Rust source/ABI tests: 15 passed. New Rust loading/ABI tests:
4 passed. Final focused Lua loading/options/lifecycle run: 55 passed, no failures
or errors. Focused and complete Lua lint both passed. The complete gate below
includes all newly added tests and the optional-cjson-absence subprocess.

## Canonical gate

Exact host invocation:

```sh
docker run --rm \
  -v '/Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace' \
  -v leanjson-bounded-target:/workspace/target \
  -v qjson-cargo-registry:/usr/local/cargo/registry -w /workspace \
  sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47 \
  sh -c 'make openresty-verify > .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-canonical.log 2>&1; status=$?; tail -n 100 .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-canonical.log; exit "$status"'
```

Result: exit 0. `task-1-canonical.log` records default, scalar-only and test-panic
Rust suites, clippy, default release rebuild, full Lua suite (435 successes),
67-file Lua lint (0 warnings/errors), encode properties (2000 cases), mutation
properties (1000 cases x 100 steps), source stress (500 valid + 500 mutated),
source JSONTestSuite (95 valid,188 invalid,35 implementation-defined; file plus
17/65536-byte feeds), and all 60 real HTTP acceptance checks. Ten HTTP checks
were added for loading modes/scalar roots/options; no baseline failures observed.

## Fuzz compilation and installed-tree smoke

Same pinned Docker mount/image, command:

```sh
CARGO_TARGET_DIR=/workspace/target/fuzz-loading-check \
  cargo check --locked --offline --manifest-path fuzz/Cargo.toml --bins
```

Result: exit 0; all six fuzz bins compile. Log: `task-1-fuzz-compile.log`.
This is compile verification, not a new timed libFuzzer campaign.

Installed-tree command (same Docker environment):

```sh
set -e
task_tree=$(mktemp -d /tmp/leanjson-loading-install.XXXXXX)
trap 'rm -rf "$task_tree"' EXIT
CARGO_NET_OFFLINE=true luarocks --lua-dir=/usr/local/openresty/luajit \
  --tree="$task_tree" make rockspec/lua-leanjson-scm-1.rockspec --deps-mode=none
cd /tmp
LD_LIBRARY_PATH= LUA_PATH="$task_tree/share/lua/5.1/?.lua;;" \
  LUA_CPATH="$task_tree/lib/lua/5.1/?.so" \
  /usr/local/openresty/luajit/bin/luajit \
  /workspace/.superpowers/sdd/2026-11-02-decode-loading-modes/task-1-installed-smoke.lua
```

Result: exit 0. The installed loading module, old/new ABI sizes/offsets, eager
memory/file/feed values, independent repeated eager results, selected reads and
exact untouched bigint bytes passed from `/tmp` without workspace Lua/native
lookup. Temporary install tree removed. Log: `task-1-install.log`.

## Storage/work observations and limitations

- The all-zero-index test scans a one-byte file and repeats deep/far selected
  reads without any extra source callbacks. Complete selected-subtree iteration
  also makes no source reads; lexical/current container identity is tested.
- A deterministic regression compares 1 vs 10000 ignored rows plus a 100 vs
  1000000-byte ignored scalar: both retain exactly one selected node, one route
  node, 3 payload bytes, 2 key bytes and zero native optional indexed nodes/bytes.
  This tests retained selected metadata, not total process memory.
- Supervisor independent 18-cell acceptance/measurement passed semantic, no-I/O
  and exact-byte oracles. Runtime was frozen during both measurement runs; no
  runtime edits followed the final measurement. Supervisor owns those artifacts
  and final interpretation. Eager decode transient allocations were reduced by
  reusing nesting frames, allocating scalar part arrays only across boundaries,
  and recording shape hints only for arrays.
- Eager decoding/ordinary encoding is not allocator or CPU parity with cjson.
  The existing ordinary-table encoder allocates intermediate output fragments;
  `reader(ordinary_value)` intentionally snapshots ordinary tables into immutable
  nodes. Both can cost more memory than cjson and are not redesigned here. The
  independent selective file/feed results retain the memory benefit, with normal
  lazy access and full output. No universal RSS bound is asserted.
- Repeated eager Decoder queries intentionally trade source work for independent
  results without a duplicate hidden DOM. This is documented, and yielding/error
  lifetime tests cover repeated builds.

## Self-review and ownership

Reviewed selector parsing/shared-prefix matching, bounded event draining, duplicate
replacement/pruning, source identity/raw spans, overlay/lexical iteration,
null/false, eager table shape, source/selector/event ABI ownership, panic barriers,
callback cancellation, final cache release, module installation and docs units.
`git diff --check` passed. No whole-plan or unrelated source changes were made.
Root-owned README, design clarification, independent probe and measurement files
remain outside this commit. Explicit staged manifest/commit details follow.

Commit: `db052d4` (`feat: add eager decoding and scan-time path preloading`).
Only these 24 owned paths were explicitly staged:

```text
docs/file-source-api.md
docs/source-proxy-api.md
include/leanjson.h
lua/leanjson/lib.lua
lua/leanjson/loading.lua
lua/leanjson/nodes.lua
lua/leanjson/options.lua
lua/leanjson/proxy.lua
lua/leanjson/source.lua
lua/leanjson/source_backend.lua
lua/leanjson/source_memory.lua
lua/leanjson/table.lua
rockspec/lua-leanjson-scm-1.rockspec
src/source.rs
src/source/loading.rs
src/source_ffi.rs
src/source_ffi/loading.rs
tests/lua/decode_loading_spec.lua
tests/lua/fixtures/loading_without_cjson.lua
tests/lua/loader_spec.lua
tests/openresty/acceptance.lua
tests/openresty/loading-handler.lua
tests/openresty/nginx.conf.in
tests/source_loading.rs
```

`git diff --cached --check` passed before commit. Root-owned changes remained
unstaged and were preserved. The report and logs are scratch artifacts rather
than files in the implementation commit. No push or remote change was made.

## Review fix round 1: I1 scratch rebuild cancellation

Review base: `cd3e5030ecb7c780e7ba59e3ab54217a19c72330` (supervisor documentation
and independent probes were interleaved after the original implementation).
Read the complete `task-1-review.md` including its retained-coroutine reproduction.
Verified the cause against `M.rebuild`, source read/callback ownership and
`leases.track`/`finish`/`release`: only the original backend read lease was scoped;
the rebuild's separate native source and partial ordinary tree were local values
reachable from the suspended coroutine until it resumed or was collected.

Added four regression cases (finish/get x cancellation/normal-error cleanup):

- Both cancellation cases rebuild a 201-element array in 64-byte windows and
  suspend on the fourth rebuild source callback, after at least 20 values have
  already been constructed. They preserve the suspended worker and observe its
  builder without taking ownership of the partial array.
- Before resuming, explicit close must null the scratch source, clear builder
  root/stack/frames, remove active cleanup records and close the original spool.
  GC must collect a weak partial-array observer while the worker remains held
  and suspended. Late resume returns the closed error and cannot double-release
  or use the released scratch source. The original first eager result remains
  intact and usable.
- Success and injected fourth-read source errors verify the same source/payload
  cleanup for both repeated finish and container get. Successful ordinary results
  retain all 201 values; error paths release their partial payload.

The focused red run on the unchanged runtime recorded 26 successes and 4 expected
failures. Both cancellation failures said `close retained the scratch native
source`; normal/error ownership checks also observed a non-nil stale scratch
source field. Log: `task-1-review-fix-red.log`.

Fix: register the scratch native source and builder in one initiating-scope
cleanup record before building. Its idempotent cleanup clears frame payloads,
root/stack/frame references and scratch source fields, nulls the local source,
detaches the native GC finalizer and releases the native source. The same record
finishes on success/error, and a fallback finalizer handles abandoned workers.
Post-read scope/source checks prevent any late native access after cancellation.
This changes only `lua/leanjson/loading.lua` and its loading regressions; native
code, ABI layouts, decode selection and ordinary output semantics are unchanged.

Exact red command (pinned Docker image/mounts as above):

```sh
docker run --rm \
  -v '/Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace' \
  -v leanjson-bounded-target:/workspace/target \
  -v qjson-cargo-registry:/usr/local/cargo/registry -w /workspace \
  sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47 \
  sh -c 'LD_LIBRARY_PATH=/workspace/target/release busted --lua=/usr/local/openresty/luajit/bin/luajit tests/lua/decode_loading_spec.lua --lpath="./lua/?.lua" > .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-review-fix-red.log 2>&1; status=$?; cat .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-review-fix-red.log; exit "$status"'
```

Exact covering green command:

```sh
docker run --rm \
  -v '/Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace' \
  -v leanjson-bounded-target:/workspace/target \
  -v qjson-cargo-registry:/usr/local/cargo/registry -w /workspace \
  sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47 \
  sh -c 'LD_LIBRARY_PATH=/workspace/target/release busted --lua=/usr/local/openresty/luajit/bin/luajit tests/lua/decode_loading_spec.lua tests/lua/source_lifecycle_spec.lua tests/lua/source_review_spec.lua --lpath="./lua/?.lua" > .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-review-fix-green.log 2>&1; status=$?; cat .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-review-fix-green.log; exit "$status"'
```

Result: exit 0; **60 successes / 0 failures / 0 errors / 0 pending**.
Log: `task-1-review-fix-green.log`.

Exact lint command:

```sh
docker run --rm \
  -v '/Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace' \
  -v leanjson-bounded-target:/workspace/target -w /workspace \
  sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47 \
  sh -c 'luacheck lua tests/lua tests/openresty examples/openresty > .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-review-fix-lint.log 2>&1; status=$?; tail -n 8 .superpowers/sdd/2026-11-02-decode-loading-modes/task-1-review-fix-lint.log; exit "$status"'
```

Result: exit 0; **0 warnings / 0 errors in 67 files**. `git diff --check` passed.
The supervisor refreshed all 18 independent acceptance cells in
`acceptance-reviewed`, reporting stable before/after runtime fingerprints and all
oracles passing. No runtime edits followed that refresh. Per supervisor direction,
the earlier canonical Rust/HTTP/fuzz/install evidence was retained and this narrow
Lua ownership fix received covering lifecycle/review tests plus full Lua lint;
no native build or repeated heavy canonical gate was needed.

Self-review checked immediate cleanup while paused, all success/error exits,
fallback lifetime, idempotent release and post-yield guards. No remaining I1 gap
identified. Scoped fix commit: `1bacb136c6be27b91493dd39ab18271b0b471cfd` (`fix: release eager rebuild resources on
cancellation`); only `lua/leanjson/loading.lua` and
`tests/lua/decode_loading_spec.lua` were explicitly staged. No subagents or remote
Git changes.
