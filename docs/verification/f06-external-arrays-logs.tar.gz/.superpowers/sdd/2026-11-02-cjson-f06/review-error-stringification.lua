-- Focused review probe: error formatting must not bypass temporary pin cleanup.
package.path = './lua/?.lua;' .. package.path
local json = require('leanjson')
local io_source = require('leanjson.source_io')
local proxy = require('leanjson.proxy')
local ffi = require('ffi')
ffi.cdef[[int fcntl(int, int, ...);]]
local path = os.tmpname()
local file = assert(io.open(path, 'wb'))
assert(file:write('{"v":1}')); assert(file:close())

for _, operation in ipairs({'reader', 'fork'}) do
    for _, problem_kind in ipairs({'ordinary', 'throwing-tostring'}) do
        collectgarbage('collect'); collectgarbage('collect')
        collectgarbage('stop')
        local fd, backend, child
        local original_open = io_source.open
        io_source.open = function(p)
            local descriptor, err = original_open(p)
            fd = descriptor
            return descriptor, err
        end
        local problem = {}
        if problem_kind == 'throwing-tostring' then
            setmetatable(problem, {__tostring = function() error('error-stringification-failed', 0) end})
        end
        local value = setmetatable({}, {
            __len = function() return 2 end,
            __index = function(_, index)
                if index == 1 then
                    child = json.decode_file(path, {index_depth = 0, index_budget_bytes = 0})
                    backend = proxy.node(child).backend
                    return child
                end
                json.close(child)
                error(problem, 0)
            end,
        })
        local ok, result = pcall(json[operation], value)
        io_source.open = original_open
        local reported
        if ok and operation == 'reader' then
            local chunk, err = result:next()
            assert(chunk == nil)
            reported = err
            result:close()
        else
            reported = rawequal(result, problem) and '<original-error-object>' or result
        end
        print(operation, problem_kind, 'returned', ok, 'error', reported,
            'fd-open-before-gc', ffi.C.fcntl(fd, 1) ~= -1, 'leases-before-gc', backend.state.leases)
        result, child, value = nil, nil, nil
        collectgarbage('restart'); collectgarbage('collect'); collectgarbage('collect')
        print(operation, problem_kind, 'fd-open-after-gc', ffi.C.fcntl(fd, 1) ~= -1,
            'leases-after-gc', backend.state.leases)
    end
end
os.remove(path)
