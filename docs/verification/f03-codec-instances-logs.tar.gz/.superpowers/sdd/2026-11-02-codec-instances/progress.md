# SDD ledger — plan: docs/plans/2026-11-02-codec-instances.md

Spec: docs/design/cjson-compatibility-fixes.md F03 plus explicit user clarification, codec configuration isolation with existing loading modes.
Pre-flight: no shared interfaces between tasks (one integrated task).
Task 1: RED: tests/lua/codec_instance_spec.lua, 15 failures because leanjson.new is nil; log .superpowers/f03-new/red.log. Baseline make test: 428 Rust / 439 Lua pass.
Task 1: GREEN: 428 Rust / 456 Lua / 60 native HTTP acceptance checks; lua-lint clean. Nine upstream cells each 164 records; all original passes preserved. New instance dispatch regression control RED (9 bypasses) -> GREEN (9 real paths). Failed-reset fault injection updated because new() is now available; controls healthy.
Review scope: uncommitted working-tree diff, per plan. .superpowers/f03-new/review.diff omits indentation-only changes; new files must be read separately. No product commit or remote operation requested.
Task 1: complete (commits 3142f00..3142f00, tests: docker run --rm -v /Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace -v leanjson-bounded-target:/workspace/target -v qjson-cargo-registry:/usr/local/cargo/registry -w /workspace lua-qjson-dev:task3-repro make test lua-lint openresty-test → 1..60)
Final review: independent f03_final_review; no outstanding implementation findings. Relative test-output override normalized and ten-test Python suite confirmed. Scope retained: F01/F02 setters and F04 safe APIs are separate requested fixes, not F03 claims.
Final: instrumentation correction: reference safe module was labeled instance; added failing scope assertion, fixed native_safe exclusion, reran Python suite and matrix. Runtime unchanged after acceptance gate.
Final verification: 428 Rust +456 Lua +60 HTTP; zero Lua lint warnings/errors; 10 Python controls pass; final nine-cell matrix unchanged and healthy; original pass records preserved. No commit/push/merge.
