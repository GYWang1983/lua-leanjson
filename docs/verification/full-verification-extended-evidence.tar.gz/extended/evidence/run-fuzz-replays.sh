#!/usr/bin/env bash
set -u

REPO=${1:?repo}
BASE=${2:?base}
SRC=${3:?source}
EVID=${4:?evidence}
IMAGE=${5:?image}
IMAGE_ID=$(docker image inspect "$IMAGE" --format '{{.Id}}')

mkdir -p "$BASE/linux-replay/logs" "$BASE/linux-replay/target" "$BASE/linux-replay/source-corpus"
if [[ -z "$(find "$BASE/linux-replay/source-corpus" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
    cp -R "$SRC/fuzz/corpus/fuzz_parse_eager/." "$BASE/linux-replay/source-corpus/"
fi

for target in fuzz_parse_eager fuzz_depth fuzz_ffi_ops fuzz_parse_lazy fuzz_numbers fuzz_source_windows; do
    out="$BASE/linux-replay/logs/$target.stdout"
    err="$BASE/linux-replay/logs/$target.stderr"
    start=$(python3 -c 'import time; print(time.time())')
    if [[ "$target" == fuzz_source_windows ]]; then
        cmd="cargo +nightly fuzz run fuzz_source_windows /work/source-corpus -- -runs=0 -max_len=16384"
    else
        cmd="cargo +nightly fuzz run $target -- -runs=0"
    fi
    set +e
    docker run --rm --platform linux/arm64 \
        -v "$SRC:/workspace" -v "$BASE/linux-replay:/work" -w /workspace \
        -e CARGO_TARGET_DIR=/work/target \
        "$IMAGE" bash -lc "set -o pipefail; $cmd" >"$out" 2>"$err"
    rc=$?
    set -u
    end=$(python3 -c 'import time; print(time.time())')
    duration=$(python3 -c "print(float('$end')-float('$start'))")
    files=$(rg -o '[0-9]+ files found' "$out" "$err" 2>/dev/null \
        | sed -E 's/.*:([0-9]+) files found/\1/' \
        | awk '{n += $1} END {print n + 0}')
    done_line=$(rg -o 'Done [0-9]+ runs' "$out" "$err" 2>/dev/null | tail -1 || true)
    python3 "$EVID/record_receipt.py" \
        --path "$EVID/receipts.json" \
        --id "linux-fuzz-replay-$target" \
        --command "docker run --rm --platform linux/arm64 -v $SRC:/workspace -v $BASE/linux-replay:/work -e CARGO_TARGET_DIR=/work/target $IMAGE bash -lc '$cmd'" \
        --exit "$rc" --duration "$duration" \
        --count "seed_files=$files; $done_line" \
        --tools "{\"image\":\"$IMAGE\",\"image_id\":\"$IMAGE_ID\",\"nightly\":\"1.101.0-nightly (31d3246e0 2026-10-27)\",\"cargo_fuzz\":\"0.13.2\"}" \
        --source-hash "33d00b522d87cc760f757404186488453ffcb498" \
        --stdout "$out" --stderr "$err" \
        --status "$([[ "$rc" -eq 0 ]] && echo pass || echo fail)" \
        --notes "Independent replay; later targets continue after earlier failures; source_windows uses the copied fuzz_parse_eager corpus and max_len=16384."
    printf '%s exit=%s duration=%ss files=%s %s\n' "$target" "$rc" "$duration" "$files" "$done_line"
done
