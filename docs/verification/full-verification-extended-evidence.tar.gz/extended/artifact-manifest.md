# Extended verification artifact manifest

All paths below are relative to
`/Users/wanggy/Projects/lua-qjson/.superpowers/sdd/2026-11-03-full-verification/extended`
unless absolute paths are shown.

## Compact evidence copied for archival

- `receipts.json`: all 34 raw command receipts.
- `preflight.md`: pre-GO host/instruction inventory.
- `extended-report.md`: coverage boundaries and results.
- `evidence/receipts.snapshot.json`: receipt copy used for evidence hashing.
- `evidence/artifact-hashes.txt`: hashes of key evidence files.
- `evidence/record_receipt.py`, `evidence/run-fuzz-replays.sh`,
  `evidence/run-miri-inside.sh`, `evidence/run-asan-inside.sh`: exact helper
  scripts used for independent result capture.
- `evidence/fuzz/`: tool inventory, the read-only setup failure, bounded six
  target raw logs, six replay logs, and generated `fuzz-Cargo.lock`.
- `evidence/miri/`: initial rust-src prompt, rerun container logs, all 12
  target/test stdout/stderr files, rc/duration files, and `summary.tsv`.
- `evidence/asan/`: strict container logs, all six profile/test stdout/stderr
  files, rc/duration files, and `summary.tsv`.
- `evidence/audit/`: cargo-audit stdout/stderr and advisory DB provenance.
- `evidence/native/`: installed smoke output, cancelled duplicate native test
  output, the preflight copy, and `luajit-provenance.md`.

## Retained external artifacts (not copied; exclude large build data)

- `/tmp/lua-leanjson-extended-20261103/linux-fuzz/output/leanjson-fuzz.*`:
  first read-only attempt's 297 copied seed files and its setup log.
- `/tmp/lua-leanjson-extended-20261103/linux-fuzz-rerun/output/leanjson-fuzz.ieb6M2`:
  six-target run output and generated corpus (~27 MiB); no crash files.
- `/tmp/lua-leanjson-extended-20261103/linux-replay/`: per-target replay
  work/output and copied source-window corpus.
- `/tmp/lua-leanjson-extended-20261103/linux-miri-rerun/`: Miri target tree
  and all raw result files (compact copies are in `evidence/miri/`).
- `/tmp/lua-leanjson-extended-20261103/linux-asan/`: ASan target trees and
  raw result files (compact copies are in `evidence/asan/`).
- `/tmp/lua-leanjson-extended-20261103/linux-audit/cargo/advisory-db/`:
  RustSec checkout at the recorded commit (audit stdout is copied).

## Explicitly excluded from archive

Task-local Rust/LuaJIT toolchains, Cargo registry caches, Cargo target trees,
the writable source copy, and all native build outputs are excluded. They are
not needed to interpret the receipts and may be regenerated from the exact
commands and pinned image/tool provenance.
