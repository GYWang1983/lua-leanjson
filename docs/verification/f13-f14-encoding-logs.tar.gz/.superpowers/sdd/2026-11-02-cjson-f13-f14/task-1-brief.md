### Task 1: Implement F13/F14 with regression coverage

Files: `lua/leanjson/table.lua`, `lua/leanjson/reader.lua`, `lua/leanjson.lua`; minimal helpers in `lua/leanjson/` only when necessary; new focused Lua regression file; README and API documentation.

- [ ] Read native configuration, array/object emission, unsupported-type behavior and upstream test.lua:L363-L395 / agentzh.t:TEST22. Write a reproducible independent oracle probe; capture expected behavior including all-skipped indentation and argument edge cases.
- [ ] Add failing tests for the public APIs and actual encode behavior before production edits; capture RED in this task workspace.
- [ ] Implement isolated settings and iterative plain-table/reader encoding, native error semantics and output punctuation. Configure public exports and safe wrappers by existing conventions.
- [ ] Exercise ordinary/safe/new settings, root/member/array/nested unsupported values (function/thread/userdata and cdata contracts), invalid-key/error preservation, clean/dirty raw proxy, fork/materialize keep_origin, comments/duplicates, cross-codec and reader snapshots.
- [ ] Cover lazy/eager/preload x memory/file/feed; reader length and chunk sizes 1/7; deep structures and large file/feed strings with bounded read/zero materialize instrumentation and no-GC lease cleanup.
- [ ] Run focused tests to GREEN, full Lua suite and Lua lint. Self-review. Write task report with commands, counts, RED/GREEN, changed paths, contract decisions and limitations. Do not commit.


## Global Constraints

- Implement native defaults, getter/setter values and argument errors with independent module/new/safe settings and failure atomicity. Numeric/non-whitespace/NUL indentation behavior is determined by the pinned oracle, not guessed; keep its accepted non-whitespace indentation.
- Both ordinary-table and proxy/reader output honor the calling codec. Indentation applies consistently to clean raw containers, dirty nodes, keep_origin and nested proxy/table combinations; raw scalar spellings may stay original as documented. Empty versus all-skipped containers follow native formatting.
- Skip applies only to unsupported value types; nil/null, supported numeric cdata, sparse-array policy, invalid object keys, invalid numbers, cycles and depth errors preserve existing behavior. Do not extend F06 external arrays or F18 mutation semantics.
- No full materialization or runtime cjson fallback. Bounded source reads and output chunks, accurate reader:length(), cancellation and release without forced GC. Use explicit stacks, including deep indentation generation; no output-sized indentation temporary in reader.
- Do not alter upstream expectations/adapters to make cases pass. Keep remaining failures and previous RSS boundary visible. No whole-project formatting or unrelated refactors.
- Work only in existing linked worktree. Implementer/reviewer must not commit, switch branches, push, or spawn subagents. Parent commits to local main only after gates; push is not requested.

## Review Focus

- All-skipped arrays/objects, holes, mixed unsupported types and invalid keys with unsupported values.
- Raw container and keep_origin bypass of indent; non-whitespace/embedded NUL indent and numeric coercion.
- Reader snapshots across settings changes/cross-codec calls, length consistency and one-byte chunk boundaries.
- Deep nesting, huge scalar strings and file/feed cleanup under error or cancellation.
- Sparse/invalid-number/cycle errors must not be silently swallowed by skip; no mutation of input during encoding.

