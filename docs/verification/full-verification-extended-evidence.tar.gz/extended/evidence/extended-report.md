# Extended verification report

Recorded at HEAD `33d00b522d87cc760f757404186488453ffcb498` on branch
`verify/full-suite-2026-11-03`. All commands below ran after explicit GO and
were isolated from the primary Cargo target. The machine-readable source of
truth is `receipts.json`; compact raw logs and helper scripts are copied under
`evidence/`.

## Executive result

- Bounded libFuzzer: six targets completed on Linux arm64 with 30 seconds per
  target and no crash artifact. A first read-only-checkout attempt is retained
  as `setup_error` only; it failed before fuzz execution when Cargo tried to
  rewrite `fuzz/Cargo.lock`.
- Corpus replay: all six independent `-runs=0` replays exited 0, including
  `fuzz_numbers` and `fuzz_source_windows` with `-max_len=16384`. The depth and
  ffi-ops corpora were empty; their two harness runs each are recorded as
  empty-corpus checks, not substantive seeded coverage.
- Miri: 12/12 scalar FFI target/test pairs passed for x86_64, i686, and
  powerpc64 targets. The first attempt's interactive `rust-src` prompt is
  retained as a setup error; the rerun installed `miri`, `rust-src`, and all
  three targets explicitly.
- ASan: the strict aarch64 Linux fallback passed all three requested FFI
  tests. All three strict x86_64 attempts were executed but could not link on
  the arm64 container (`cc: unrecognized command-line option '-m64'`); these
  are cross-runtime coverage blockers, not product-test failures, and do not
  substitute for the CI x86_64 profile.
- Cargo audit: the literal canonical `cargo audit` command passed with
  cargo-audit 0.22.2; 1,403 RustSec advisories were loaded and 117 Cargo.lock
  dependencies scanned.
- Native macOS installed LuaRocks smoke: passed once from a directory outside
  the checkout using an observed LuaJIT 2.1.0-beta3 arm64 binary and an
  isolated tree. The binary was built from the Ubuntu/Debian `+dfsg` beta3
  source archive; its URL, archive hash, executable hash, and the absence of a
  verified upstream Git tag/commit equivalence are recorded in
  `evidence/native/luajit-provenance.md`. This is not claimed as exact
  upstream-CI identity. Native Rust matrices, Valgrind, and OpenResty profiles
  are parent-owned in separate scratch and are intentionally not duplicated
  here.

## Tool and source provenance

- Docker image: `lua-qjson-dev:fuzz`, immutable image ID
  `sha256:c4c8f06d4c8552c7d91a01da676966d4975d801efc1fb7a55dbb0887a37951c5`.
  The container platform was Linux arm64 under OrbStack.
- Rust stable in the image: `rustc 1.90.0 (1159e78c4 2025-09-14)`.
- Rust nightly: `1.101.0-nightly (31d3246e0 2026-10-27)`.
- cargo-fuzz: `0.13.2`.
- cargo-audit: `0.22.2`.
- Auxiliary macOS LuaJIT smoke source: Ubuntu archive URL
  `https://archive.ubuntu.com/ubuntu/pool/universe/l/luajit/luajit_2.1.0~beta3+dfsg.orig.tar.gz`,
  SHA-256 `46589f8a1742d04fc33f309343d9521b32d6d29515a34c6609e2f76932b1b7df`;
  observed executable SHA-256 `e3321c6c6e9a6bbbc4d67567b9abe84e2c911088c5925cafcc2a0147662f2474`.
  No upstream Git tag/commit equivalence was verified.
- Advisory DB: RustSec `6c5fedf8ff03c485ed674d8f941e0180f3f72d70`, commit
  timestamp `2026-11-03T10:44:19+01:00`; the audit network run was recorded
  at `2026-11-03T10:45:09Z`.
- Linux source was a writable `git archive HEAD` copy at
  `/tmp/lua-leanjson-extended-20261103/src/linux-head`; root manifest hashes
  are Cargo.toml `e43dce6c…`, Cargo.lock `a1cbeb80…`, fuzz/Cargo.toml
  `3614800b…`, and the generated fuzz lockfile is copied as
  `evidence/fuzz/fuzz-Cargo.lock.generated` (hash `03f55e12…`). The tracked
  checkout and tracked lockfiles were not modified.

## Exact bounded-fuzz results

The writable rerun used `scripts/verify-bounded-fuzz.sh`,
`LEANJSON_FUZZ_SECONDS=30`, a task-owned `/work/target`, and retained output
under the task-owned `/work/output`. The six observed libFuzzer run counts
were:

| Target | Run count | Result |
| --- | ---: | --- |
| `fuzz_parse_eager` | 1,779,887 | pass |
| `fuzz_parse_lazy` | 32,172 | pass |
| `fuzz_ffi_ops` | 4,515,515 | pass |
| `fuzz_depth` | 66,803 | pass |
| `fuzz_numbers` | 2,255,702 | pass |
| `fuzz_source_windows` (`max_len=16384`) | 165,557 | pass |

No crash files were produced. The generated corpus directory is about 27 MiB
and remains outside the compact evidence copy; its exact path and receipt are
listed in `artifact-manifest.md`.

Replay receipts preserve the exact per-target commands and logs. Seeded
replays completed as parse-eager 297, parse-lazy 14, numbers 11, and
source-windows 297 runs. Depth and ffi-ops each completed two harness runs
with zero seed files.

## Miri and ASan boundaries

Miri commands used `--no-default-features` and each of
`ffi_smoke`, `ffi_cursor`, `ffi_strings`, and `ffi_ops_interleave` for every
target. Every pair exited 0; per-test assertion counts and durations are in
`receipts.json` and `evidence/miri/summary.tsv`.

ASan used `RUSTFLAGS='-Z sanitizer=address'` without `continue-on-error` or
any advisory mask. The aarch64 fallback passed 6, 3, and 2 assertions for
`ffi_smoke`, `ffi_strings`, and `ffi_ops_interleave`. The x86_64 commands
failed before test execution while linking because the arm64 container's `cc`
does not accept `-m64`; no x86 test assertion was run. A real x86_64 Linux
sanitizer runtime remains uncovered. Miri's scalar cross-target success does
not close that ASan gap, and no AVX2-native x86 runtime was claimed.

## Native smoke and delegated gates

The installed-package smoke ran from
`/tmp/lua-leanjson-extended-20261103/installed-smoke`, with inherited
`LD_LIBRARY_PATH` and `DYLD_LIBRARY_PATH` unset and Lua paths restricted to
the task-local rock tree. It passed all memory/file/feed/fork/get/reader/close
and OpenResty import assertions.

The native Rust release/scalar/test-panic/Clippy matrix, full LuaJIT Valgrind
memcheck, and OpenResty 1.21.4.4, 1.27.1.2, and 1.29.2.4 profiles were handed
to the parent runner's separate scratch. This subtask contains no receipt
claim for those delegated runs. No performance benchmark was run.

## Evidence and exclusions

`evidence/` contains 126 compact files (about 3.1 MiB): receipts snapshot,
raw stdout/stderr, per-test metadata, generated fuzz lockfile, advisory
provenance, and the exact helper scripts. The manifest identifies all files
and the external paths needed to recover retained corpora. Cargo target trees,
Rust toolchains, Cargo registries, the writable source copy, and generated
fuzz corpus are deliberately excluded from the compact evidence directory.

No tracked source, test, workflow, or lockfile edits were made by this
subtask. No commit, push, workflow trigger, issue, or external message was
performed.
