# SDD ledger — plan: docs/plans/2026-11-02-decode-loading-modes.md

Base main634f82705b0315406d26e29e0adf828852c97272. Worktree /Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata, newbranchfeat/decode-loading-modes. User explicitly requested2features and confirmed unselected values remain lazy/full output. Latest explicit constraint: preload_paths ignores index_depth/index_array_limit/index_budget_bytes, includingzero.

| Tasks | Shared file/interface | Preflight result |
| --- | --- | --- |
| 1 / 1 | Native scanner/ABI, Lua source/options/builders/cache and adapters | One implementer owns coupled eager/selective modes; public v1/v2 layouts preserved. Tests pin full validation, duplicates/overlays and lifetime. |
| 2 / 2 | Acceptance probes, README/report | Root owns independent public-API comparisons and exact evidence. Historical artifacts unchanged. |
| 1 / 2 | New options and source_stats | Explicit selection outside automatic budget; separate truthful selected counters. Freeze runtime before measurements. |

Ruling: Execute the requested two-feature change after the user's semantic clarification, retaining prior Sol6.1max coding/supervisor-review arrangement and using the existing isolated worktree on a new feature branch — implementation is explicitly authorized — a scope mismatch can be revised locally without touching main.
Ruling: Use preload_paths with a documented JSONPath subset rather than adding a JSON Schema API; lazyload=false always fully materializes and validates any supplied selectors — the user allowed path arrays or schema and wants complete retained JSON — more JSONPath operators or schema require a later extension; eager mode necessarily pays full-value memory.

Task1 pending. Task2 pending. Independent task and wholebranchreviews pending. Prior main runtime fully verified in prior turn, no intervening codechanges; fresh targeted baseline will confirm source/runtime alignment. Native image lua-qjson-dev:task3-repro IDsha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47; targetvolumeleanjson-bounded-target; registryqjson-cargo-registry. No push/merge authorized for this new change.

Task 1 dispatched to /root/decode_loading_runtime (gpt-6.1-sol max), BASE bc529be; owns coupled runtime/tests/API docs. Root preparing independent loading probes and README while agent codes; no concurrent native builds/measurements.
Ruling: Preserve existing OpenResty Session get/finish behavior (one completed mutable value) in both socket and fallback modes; independent repeated snapshot semantics apply to new_decoder's Decoder only — Session already exposes self.value in both modes, and changing it would alter existing behavior or retain a second DOM/source — callers seeking immutable repeated queries must use Decoder or an explicit fork; Session edits remain visible to later Session queries. Spec clarified before final adapter changes.

Task 1 implementer DONE at db052d45a841e03370b774080cac1e437dece543. Canonical435Lua/60HTTP, Rust modes, lint/properties/corpus, offlinefuzzcompile and isolated installed smoke passed. Task reviewer /root/decode_loading_task_review (gpt-6-astra high) reviewing package bc529be..db052d4.
Task 2 independent18cell acceptance passed; runtime fingerprints rechecked after commit and canonical/install gates unchanged. Root probes/docs ready for task review.
Task1 review: I1 Important (scratch eager rebuild source/partial values survive decoder close while coroutine remains suspended); confirmed from code and reviewer focused reproduction. Fix round1 dispatched to original implementer, FIX_BASE cd3e503 (root Task2 docs interleaved after reviewed db052d4). Task2 committed cd3e503; acceptance review /root/decode_loading_acceptance_review (gpt-6.1-sol high) pending, runtime change will require fingerprint/evidence refresh.
Task1 cannot-verify items: root inspected unchanged OpenResty Session get/finish implementation before spec clarification; real HTTP tests verify both socket/fallback edit visibility. Independent performance evidence is under Task2 review, not treated as Task1 runtime proof.

Task 1: fix round 1/5 (1 addressed, 0 open — I1 scratch rebuild cancellation cleanup; commits cd3e503..1bacb13). Scoped re-review /root/decode_loading_fix_review (gpt-6.1-sol high) clean; all60covering tests passed.
Task 1: complete (commits bc529be..1bacb13, review clean; root docs interleaved in cd3e503).
Task 2: complete (commits db052d4..cd3e503 plus final evidence refresh, review clean). Acceptance review approved; dependent lifecycle boundary resolved by Task1fix/re-review. Fresh acceptance-reviewed18/18 plus final hash prove final runtime. No parked or deferred findings. Whole-branch review pending.
