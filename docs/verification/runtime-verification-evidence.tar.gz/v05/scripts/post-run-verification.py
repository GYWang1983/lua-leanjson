#!/usr/bin/env python3
import datetime,hashlib,json,pathlib,re,shutil,subprocess,sys
ROOT=pathlib.Path('/root/leanjson-v05-20261103-native-171329z');E=ROOT/'evidence'
raw=json.loads((E/'acceptance-summary.json').read_text())
for src,dest in [('acceptance-summary.json','driver-acceptance-summary.json'),('binary-provenance.json','driver-binary-provenance.json')]:
 if not (E/dest).exists():shutil.copy2(E/src,E/dest)
# Cargo 1.101's actual Running path uses release/build/.../out, not the older release/deps layout.
# Derive every binary from the executed-command receipt; preserve the driver's original glob result.
executed=[]
for r in raw['core_asan_tests']+raw['scanner_support']:
 matches=re.findall(r'Running [^\n]*\(([^)\n]+)\)',(E/r['stderr']).read_text(errors='replace'))
 assert len(matches)==1,(r['name'],matches)
 executed.append((r['name'],pathlib.Path(matches[0])))
executed.append(('negative-control',pathlib.Path(json.loads((E/'negative-control-run.json').read_text())['argv'][0])))
proof=[]
for label,path in executed:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();argv=['nm','-a',str(path)]
 nm=subprocess.run(argv,capture_output=True,text=True,timeout=90);stem='instrumentation-'+label
 (E/(stem+'.stdout')).write_text(nm.stdout);(E/(stem+'.stderr')).write_text(nm.stderr)
 symbols=[line for line in nm.stdout.splitlines() if '__asan_' in line]
 (E/(stem+'.symbols.txt')).write_text('\n'.join(symbols)+'\n')
 receipt={'argv':argv,'actual_exit_code':nm.returncode,'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_of_binary_path':'actual Cargo Running line or actual negative-control argv'}
 (E/(stem+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 proof.append({'label':label,'binary':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'nm_actual_exit_code':nm.returncode,'asan_init_present':any('__asan_init' in line for line in symbols),'asan_report_store_present':any('__asan_report_store' in line for line in symbols),'asan_symbol_count':len(symbols),'symbols_receipt':stem+'.symbols.txt'})
(E/'binary-provenance.json').write_text(json.dumps(proof,indent=2)+'\n')
by_path={p['binary']:p for p in proof}
def check_binary(path,label):
 p=pathlib.Path(path); relative=str(p.relative_to(ROOT)); match=by_path.get(relative)
 digest=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
 symbols=(E/match['symbols_receipt']).read_text() if match else ''
 header=subprocess.run(['readelf','-h',str(p)],capture_output=True,text=True)
 (E/(label+'.elf.stdout')).write_text(header.stdout);(E/(label+'.elf.stderr')).write_text(header.stderr)
 return {'label':label,'executed_binary':relative,'exists':p.is_file(),'sha256':digest,'matches_recorded_sha256':bool(match and digest==match['sha256']),'recorded_symbols_receipt':match['symbols_receipt'] if match else None,'asan_init_present':'__asan_init' in symbols,'asan_report_store_present':'__asan_report_store' in symbols,'elf_header_exit_code':header.returncode,'elf64_x86_64':'ELF64' in header.stdout and 'Advanced Micro Devices X86-64' in header.stdout}
checks=[]
for r in raw['core_asan_tests']+raw['scanner_support']:
 text=(E/r['stderr']).read_text(errors='replace');matches=re.findall(r'Running [^\n]*\(([^)\n]+)\)',text)
 assert len(matches)==1,(r['name'],matches)
 check=check_binary(matches[0],r['name']);checks.append(check)
 for function in ['leanjson_parse','leanjson_get_str']:
  name=r['name']+'.'+function+'.disassembly'
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  d=subprocess.run(['objdump','-d','--disassemble='+function,matches[0]],capture_output=True,text=True)
  (E/(name+'.stdout')).write_text(d.stdout);(E/(name+'.stderr')).write_text(d.stderr)
  receipt={'argv':['objdump','-d','--disassemble='+function,matches[0]],'actual_exit_code':d.returncode,'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'function_present':('<'+function+'>:') in d.stdout,'asan_reference_present':'__asan_' in d.stdout}
  (E/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
  check.setdefault('disassembly',[]).append(receipt)
neg=json.loads((E/'negative-control-run.json').read_text());checks.append(check_binary(neg['argv'][0],'negative-control'))
required_labels={'asan-ffi_smoke','asan-ffi_strings','asan-ffi_ops_interleave','negative-control'}
labels={p['label'] for p in checks}
core_proof=required_labels.issubset(labels) and all(p['exists'] and p['matches_recorded_sha256'] and p['asan_init_present'] and p['asan_report_store_present'] and p['elf_header_exit_code']==0 and p['elf64_x86_64'] for p in checks if p['label'] in required_labels)
ffi_disassembly=all(any(d['actual_exit_code']==0 and d['function_present'] and d['asan_reference_present'] for d in p.get('disassembly',[])) for p in checks if p['label'].startswith('asan-ffi_'))
feature=(E/'cpu-feature-probe-run.stdout').read_text().strip();scanner=raw['scanner_support'][0];scantext=(E/scanner['stdout']).read_text();names=['scalar_avx2_bit_identical','scalar_avx2_handles_continued_backslash_run_before_quote']
scanner_accept=scanner['exit_code']==0 and feature=='avx2=true pclmulqdq=true' and all(re.search(r'test '+n+r' \.\.\. ok',scantext) for n in names) and bool(re.search(r'test result: ok\. 3 passed; 0 failed; 0 ignored;',scantext))
scanner_source=(ROOT/'source/tests/scanner_crosscheck.rs').read_text();configured_2000_cases='ProptestConfig::with_cases(2000)' in scanner_source
lock={}
for block in (ROOT/'source/Cargo.lock').read_text().split('[[package]]')[1:]:
 fields=dict(re.findall(r'^(name|version|source|checksum) = "([^"]+)"',block,re.M))
 if fields.get('source','').startswith('registry+'):
  lock[fields['name']+'-'+fields['version']+'.crate']=fields['checksum']
crate_checks=[]
for archive in sorted((ROOT/'cargo/registry/cache').glob('*/*.crate')):
 digest=hashlib.sha256(archive.read_bytes()).hexdigest()
 crate_checks.append({'archive':archive.name,'sha256':digest,'lock_checksum':lock.get(archive.name),'matches_lock':digest==lock.get(archive.name)})
crate_receipt={'checked_count':len(crate_checks),'all_present_archives_match_lock':bool(crate_checks) and all(c['matches_lock'] for c in crate_checks),'archives':crate_checks,'note':'Target-specific packages not downloaded by this native build are not counted.'}
(E/'crate-archive-checksums.json').write_text(json.dumps(crate_receipt,indent=2)+'\n')
out={'host_label':'x86-validation-host','finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'core_binary_proof_complete':core_proof,'ffi_function_sanitizer_checks_verified':ffi_disassembly,'crate_archives_match_lock':crate_receipt['all_present_archives_match_lock'],'core_asan_accepted':raw['core_passed'] and raw['negative_control']['accepted'] and raw['source_pre_post_unchanged'] and core_proof and ffi_disassembly and crate_receipt['all_present_archives_match_lock'],'scanner_support_accepted':scanner_accept and configured_2000_cases,'scanner_actual_total_tests':3,'scanner_substantive_tests':names,'scanner_placeholder_tests':['skip_neon'],'scanner_proptest_configured_cases':2000 if configured_2000_cases else None,'binary_checks':checks}
(E/'post-run-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
sys.exit(0 if out['core_asan_accepted'] and out['scanner_support_accepted'] else 1)
