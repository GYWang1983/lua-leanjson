import pathlib,subprocess,json
root=pathlib.Path.cwd();out=root/'.superpowers/sdd/2026-11-02-cjson-f13-f14'
docker=['docker','run','--rm','-v',str(root)+':/workspace','-v','leanjson-bounded-target:/workspace/target','-v','qjson-cargo-registry:/usr/local/cargo/registry','-w','/workspace','lua-qjson-dev:task3-repro','sh','-lc']
steps=[
 ('parent-oracle-compare',docker+["LD_LIBRARY_PATH=/workspace/target/release LUA_PATH='./lua/?.lua;;' /usr/local/openresty/luajit/bin/luajit .superpowers/sdd/2026-11-02-cjson-f13-f14/parent-oracle.lua compare"]),
 ('http',docker+['LD_LIBRARY_PATH=/workspace/target/release scripts/verify-openresty.sh']),
 ('matrix',['python3','scripts/verify-cjson-compat.py','--docker','--strict','--image','lua-qjson-dev:task3-repro','--output',str(out/'matrix'),'--locale-dir',str(out/'locale')]),
 ('loading',['python3','scripts/verify-loading.py','--image','lua-qjson-dev:task3-repro','--target-volume','leanjson-bounded-target','--output-dir',str(out/'loading')]),
 ('memory',['python3','scripts/verify-memory.py','--image','lua-qjson-dev:task3-repro','--target-volume','leanjson-bounded-target','--output-dir',str(out/'memory')]),
 ('installed',docker+["luarocks make rockspec/lua-leanjson-scm-1.rockspec --tree=/workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/rocktree --deps-mode=none && LD_LIBRARY_PATH=/workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/rocktree/lib/lua/5.1 /usr/local/openresty/luajit/bin/luajit .superpowers/sdd/2026-11-02-cjson-f13-f14/installed-smoke.lua /workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/rocktree"]),
]
results=[]
for name,cmd in steps:
    with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
    row=dict(gate=name,exit=r.returncode);results.append(row)
    (out/'runtime-gates.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if r.returncode and name not in ('matrix','memory'):break
raise SystemExit(any(r['exit'] for r in results if r['gate'] not in ('matrix','memory')))
