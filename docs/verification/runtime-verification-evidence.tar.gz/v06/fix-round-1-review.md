# V06/V08 scoped fix round 1 review

**Quality verdict: Approved for the scoped fixes.** No new important fix-induced issue found. This approval permits the frozen-source V08 rerun; it does not mark V08 complete.

| Original finding | Disposition | Evidence |
| --- | --- | --- |
| P1: incomplete Memcheck summaries pass | **ADDRESSED** | `scripts/check-memcheck.awk:5-25`, invoked at `scripts/verify-luajit.sh:68`; red/green malformed-summary controls |
| P2: retained results lose their provenance on output-root reuse | **ADDRESSED** | `scripts/verify-luajit.sh:18-36`, `:40`; changed-library/source provenance regression |

## P1 assessment

The standalone AWK checker requires the complete 12-field Memcheck summary structure, a numeric process prefix, the expected field labels and syntactically numeric counts. It supports the comma-grouped counts used by real Memcheck logs, requires zero unsuppressed errors and contexts, rejects any malformed summary encountered, and fails if no summary exists. A heading alone, a truncated zero-error summary and a nonnumeric count can no longer be converted implicitly to a passing zero.

The runner still audits every captured process log when the direct command exits 0 and preserves a nonzero checker exit. The existing missing-log, empty/incomplete-child, positive-child-error and checker-exit controls remain in the final passing set. No suppression or error-exit-code change appears in this fix.

Inspected evidence:

- `evidence/review-summary-red.json` and `.log`: exit 1, specifically the three new malformed-summary tests failing because the old runner returned 0.
- `evidence/review-summary-green.json` and `.log`: exit 0, all 11 controls passing after the parser fix.
- `evidence/review-fixes-green.json` and `.log`: exit 0, all 12 final controls passing.
- `evidence/negative-complete.json`: real distro-runtime negative control exits 1. Its referenced `negative-complete-results/run.yIsnDj/negative-control/memcheck.22.log` contains `Invalid write of size 1` and the complete summary `1 errors from 1 contexts (suppressed: 0 from 0)`. This is a demonstrated invalid-write failure, not a setup failure.

## P2 assessment

An atomic `mktemp -d` creates a distinct `run.XXXXXX` directory before either manifest is written. Runtime/library identity and source hashes are stored inside it, with its plain/Memcheck/negative-control profile results beneath the same directory. Subsequent or concurrent invocations using the same output root select different directories, so they do not overwrite retained identities. The new AWK validator is included in the source manifest. The guide describes this layout accurately.

The new regression changes both the temporary library and a source file between two successful invocations. It verifies that the original manifest bytes remain unchanged and that both old and new source/library digests remain available. This asserts the preservation behavior rather than only the existence of two directories.

Inspected evidence:

- `evidence/review-provenance-red.json` and `.log`: exit 1, specifically the old runtime-manifest contents being replaced.
- `evidence/review-fixes-green.json` and `.log`: exit 0, all 12 controls passing, including library/source provenance retention and stale-child-log isolation.

## Boundaries and remaining completion gate

Only the four-file scoped fix package and the named covering evidence were reviewed. No repository files were changed, no subagents were used, and no heavy suites or redundant focused tests were rerun.

The parent reports V06 distro completion at 817 pass / 3 documented pending and a strict audit of 21 process logs at exit 0. Those full receipts were not independently re-audited in this scoped fix review.

V08 remains **pending**: the earlier rolling suite's 820 passing tests do not override its final wrapper syntax exit 2. Run the approved final source snapshot without modifying its runner/validator during execution. Completion requires a direct exit 0, the complete rolling suite result, the final source/runtime/library identities and a successful strict audit of every captured process log. Retain the latest-state report boundary until that evidence exists.
