from pathlib import Path
import subprocess,os,shutil,json
w=Path('.superpowers/sdd/2026-11-02-cjson-f06').resolve()
shared=Path('.superpowers/sdd/2026-11-02-upstream-cjson-matrix/task-1-artifacts/status-reuse-controls')
before=set(shared.iterdir()) if shared.exists() else set()
env=os.environ.copy();env['CJSON_COMPAT_TEST_OUTPUT']=str(w/'harness-controls')
with (w/'harness-controls.log').open('w') as f:r=subprocess.run(['python3','-m','unittest','discover','-s','tests/upstream-cjson','-p','test_*.py','-v'],env=env,stdout=f,stderr=subprocess.STDOUT)
new=sorted(set(shared.iterdir())-before) if shared.exists() else []
(w/'harness-status-controls').mkdir()
for p in new:shutil.move(str(p),str(w/'harness-status-controls'/p.name))
(w/'harness-controls.json').write_text(json.dumps({'exit':r.returncode,'new_owned_dirs_moved':[p.name for p in new],'existing_sibling_dirs_preserved':len(before)},indent=2)+'\n')
print('controls exit',r.returncode,'owned dirs archived',len(new),'prior siblings preserved',len(before))
raise SystemExit(r.returncode)
