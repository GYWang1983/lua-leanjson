"""Independently reconcile compatibility classification and numeric evidence."""
import collections
import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
artifacts = scratch / "task-1-artifacts/final"
result = {}
for source in ("memory", "file", "feed"):
    rows = [json.loads(line) for line in (artifacts / f"selective/{source}/records.jsonl").read_text().splitlines()]
    assert len(rows) == 80 and len({r["id"] for r in rows}) == 80
    assert collections.Counter(r["classification"] for r in rows) == {"pass": 36, "behavioral_difference": 44}
    assert sum(r.get("matches_reference_result") is True and r["success"] for r in rows) == 36
    numeric = next(r for r in rows if r["id"] == "agentzh.t:TEST20#decode1")
    assert numeric["classification"] == "pass" and numeric["matches_reference_result"]
    assert numeric["encoded_roundtrip_complete"] is False
    assert bytes.fromhex(numeric["encoded_output"]["hex"]).decode() == "9.007199254741e+15"
    result[source] = {"records": 80, "successful_equal_decode_values": 36,
                      "compatibility_pass": 36, "compatibility_difference": 44,
                      "numeric_decode_equal": True, "extra_roundtrip_fails": True}
baseline = [json.loads(line) for line in (artifacts / "baseline/records.jsonl").read_text().splitlines()]
native = next(r for r in baseline if r["id"] == "agentzh.t:TEST20")
assert bytes.fromhex(native["stdout"]["hex"]).decode().splitlines()[0] == "9.007199254741e+15"
result["native_default_precision_same_loss"] = True
(scratch / "root-supplemental-audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
