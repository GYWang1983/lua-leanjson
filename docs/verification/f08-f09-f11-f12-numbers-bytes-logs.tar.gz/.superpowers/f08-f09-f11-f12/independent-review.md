# Independent review and root repair
Reviewer /root/numeric_bytes_review, gpt-6-astra max, read-only. No edits or child agents.

Two Important findings, no Critical:
1. LuaJIT tonumber rejects native-accepted huge decimal/hex exponents, causing eager/preload and late access/encode to fail after source validation accepted them. Root RED: review-red-lua.log. Root fix: private POSIX C numeric locale and strtod_l fallback only when tonumber cannot convert; no process locale mutation. Signed integer saturation and NaN payload mapping remain native-compatible.
2. Reader nonfinite checks concatenated arbitrarily long numeric tokens. Reviewer measured 1/4 MiB NaN payloads: concatenations1,048,581/4,194,309 and GC-stopped Lua allocation~7,020/27,956KiB. Root RED: review-red-lua.log and review-red-rust.log. Root fix: plain decimal integer spans stay finite (signed64 saturation), flags8 now guarantees nonfinite conversion. The scalar path reads a bounded leading chunk to identify sign/NaN, closes its operation, and skips complete-token concatenation. Regression tests cover modified objects with1MiB NaN/integer bodies, bounded128byte output and capped intermediate concatenations.

Minor signed-integer-zero mismatch was found independently by root and reviewer and fixed before the final repair pass (zero-red/zero-green). Native integer -0 becomes positive0; floating -0.0 retains negative zero. No deferred minors.

Reviewer ran20,000 random decimal/hex comparisons (only signed zero differed),43 new public tests, independent boundary/lifecycle probes, and inspected gate logs. No other defect reproduced in bytes/Unicode, policy replay, origin reuse, stream cancellation or key-collision dependencies. Pending fixes were not re-reviewed; root validates via reproducing regressions and full gates, per execution workflow.

Explicit scope boundaries: F17 exact error text; strict RFC opt-in grammar intentionally rejects cjson's undocumented strict trailing-dot/signed-leading-dot acceptance; finite source token spellings remain preserved; native macOS runtime was not available (pinned Linux ARM64 OpenResty is the execution environment). No archive-existence finding, because archiving follows final validation.
