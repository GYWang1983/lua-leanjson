#!/usr/bin/env bash
set -u

mkdir -p /work/asan-results
set +e
rustup target add x86_64-unknown-linux-gnu --toolchain nightly
target_rc=$?
printf '%s\n' "$target_rc" > /work/asan-results/target.rc
rustc +nightly --version > /work/asan-results/tool-versions.stdout 2> /work/asan-results/tool-versions.stderr
cargo +nightly --version >> /work/asan-results/tool-versions.stdout 2>> /work/asan-results/tool-versions.stderr

for profile in x86_64-unknown-linux-gnu aarch64-unknown-linux-gnu; do
    for test_name in ffi_smoke ffi_strings ffi_ops_interleave; do
        out="/work/asan-results/${profile}-${test_name}.stdout"
        err="/work/asan-results/${profile}-${test_name}.stderr"
        start=$(date +%s.%N)
        timeout 600 env RUSTFLAGS='-Z sanitizer=address' \
            CARGO_TARGET_DIR="/work/target-${profile}" \
            cargo +nightly test --release --target "$profile" --test "$test_name" >"$out" 2>"$err"
        rc=$?
        end=$(date +%s.%N)
        duration=$(awk -v a="$start" -v b="$end" 'BEGIN { print b-a }')
        printf '%s\n' "$rc" > "/work/asan-results/${profile}-${test_name}.rc"
        printf '%s\n' "$duration" > "/work/asan-results/${profile}-${test_name}.duration"
        printf '%s %s %s %s\n' "$profile" "$test_name" "$rc" "$duration" >> /work/asan-results/summary.tsv
    done
done
exit 0
