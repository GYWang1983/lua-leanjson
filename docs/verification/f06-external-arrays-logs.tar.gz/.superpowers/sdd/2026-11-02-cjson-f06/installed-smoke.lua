local prefix=arg[1]
package.path=prefix..'/share/lua/5.1/?.lua;'
package.cpath=prefix..'/lib/lua/5.1/?.so;'
package.preload.cjson=function() error('native cjson denied',0) end
local json=require 'leanjson'
local safe=require 'leanjson.safe'
for _,c in ipairs({json.new(),safe.new()}) do
 local calls=0
 local p=setmetatable({}, {__len=function() calls=calls+1;return 3 end,__index={'foo','bar','baz'}})
 assert(c.encode(p)=='["foo","bar","baz"]');assert(calls==1)
 local r=c.reader(p,{chunk_size=1});assert(calls==2)
 getmetatable(p).__len=function() error('reader must be frozen',0) end
 assert(r:length()==19);local parts={}
 while true do local chunk,err=r:next();assert(not err,err);if chunk==nil then break end;assert(#chunk<=1);parts[#parts+1]=chunk end
 assert(table.concat(parts)=='["foo","bar","baz"]');assert(calls==2)
 local value=c.decode('{"x":[1,2]}',{index_depth=0,index_budget_bytes=0})
 local external=setmetatable({}, {__len=function() return 1 end,__index=function() return value.x end})
 local output=c.reader(external,{chunk_size=7});c.close(value)
 assert(output:length()==7);local out={}
 while true do local chunk,err=output:next();assert(not err,err);if not chunk then break end;out[#out+1]=chunk end
 assert(table.concat(out)=='[[1,2]]')
 c.encode_indent(' ');c.encode_skip_unsupported_value_types(true)
 local skip=setmetatable({}, {__len=function() return 3 end,__index={1,function() end,2}})
 assert(c.encode(skip)=='[\n 1,\n 2\n]')
end
local maps=assert(io.open('/proc/self/maps'));local text=maps:read('*a');maps:close()
assert(text:find(prefix..'/lib/lua/5.1/leanjson.so',1,true));assert(not text:find('/workspace/target/release/libleanjson.so',1,true))
print('installed-only F06 smoke passed; source/native-cjson fallbacks denied; installed native map verified')
