package.path = "./lua/?.lua;" .. package.path
local json = require("leanjson")
local proxy = require("leanjson.proxy")
local io_source = require("leanjson.source_io")
local cjson = require("cjson")
local filename = os.tmpname()
do
    local output = assert(io.open(filename, "wb"))
    assert(output:write('{"model":"original"'))
    for i = 1, 32768 do assert(output:write(',"k' .. i .. '":{"id":' .. i .. '}')) end
    assert(output:write('}')); assert(output:close())
end
local body = json.decode_file(filename, { index_budget_bytes = 0 })
collectgarbage("collect"); collectgarbage("collect")
local before = collectgarbage("count")
local original, reads = io_source.read, 0
io_source.read = function(...) reads = reads + 1; return original(...) end
local began, count, sum = os.clock(), 0, 0
for key, child in json.pairs(body) do
    if key ~= "model" then
        count = count + 1
        assert(key == "k" .. count)
        sum = sum + child.id
    end
end
local seconds = os.clock() - began
io_source.read = original
assert(count == 32768 and sum == 536887296)
assert(reads < 32768 * 3 + 100, "quadratic parent scans")
collectgarbage("collect"); collectgarbage("collect")
local retained_kib = collectgarbage("count") - before
local meta
for i = 1, 16 do
    local name, value = debug.getupvalue(proxy.node, i)
    if name == "META" then meta = value; break end
end
local children, active = 0, 0
if meta then
    for _ in pairs(meta[body].cell.children) do children = children + 1 end
    for _ in pairs(meta[body].scope.active) do active = active + 1 end
end
local stats = json.source_stats(body)
assert(stats.index_bytes == 0 and stats.spill_file_bytes == 0)
assert(children <= 1 and active == 0)
print(cjson.encode({ count = count, sum = sum, source_read_calls = reads, cpu_s = seconds,
    lua_retained_kib_after_gc = retained_kib, live_root_child_cells = children,
    root_active_operations = active, index_bytes = stats.index_bytes, spill_file_bytes = stats.spill_file_bytes }))
json.close(body)
assert(os.remove(filename))
