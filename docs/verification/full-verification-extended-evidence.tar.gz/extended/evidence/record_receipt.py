#!/usr/bin/env python3
"""Append one machine-readable extended-verification receipt."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", required=True)
    parser.add_argument("--id", required=True)
    parser.add_argument("--command", required=True)
    parser.add_argument("--exit", dest="exit_code", required=True, type=int)
    parser.add_argument("--duration", required=True, type=float)
    parser.add_argument("--count", required=True)
    parser.add_argument("--tools", default="{}")
    parser.add_argument("--source-hash", default=None)
    parser.add_argument("--status", default=None)
    parser.add_argument("--stdout", default=None)
    parser.add_argument("--stderr", default=None)
    parser.add_argument("--notes", default=None)
    args = parser.parse_args()

    path = Path(args.path)
    data = json.loads(path.read_text())
    record = {
        "id": args.id,
        "recorded_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "command": args.command,
        "exit": args.exit_code,
        "duration_seconds": round(args.duration, 3),
        "count": args.count,
        "tools": json.loads(args.tools),
        "source_hash": args.source_hash,
        "status": args.status or ("pass" if args.exit_code == 0 else "fail"),
    }
    if args.stdout:
        record["stdout"] = args.stdout
    if args.stderr:
        record["stderr"] = args.stderr
    if args.notes:
        record["notes"] = args.notes
    data.setdefault("receipts", []).append(record)
    path.write_text(json.dumps(data, indent=2, sort_keys=False) + "\n")


if __name__ == "__main__":
    main()
