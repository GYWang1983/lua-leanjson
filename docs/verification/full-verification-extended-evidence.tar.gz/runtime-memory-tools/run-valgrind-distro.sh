#!/usr/bin/env bash
set -u

export DEBIAN_FRONTEND=noninteractive
apt_opts=(
  -o Acquire::ForceIPv4=true
  -o Acquire::http::Timeout=20
  -o Acquire::Retries=1
  -o Acquire::Languages=none
  -o Acquire::PDiffs=false
  -o Acquire::CompressionTypes::Order::=gz
)

apt-get "${apt_opts[@]}" update
apt-get install -y "${apt_opts[@]}" \
  ca-certificates build-essential lua5.1 liblua5.1-0-dev luarocks luajit valgrind

echo "luajit_path=$(command -v luajit)"
luajit -v 2>&1
echo "valgrind_path=$(command -v valgrind)"
valgrind --version
echo "luarocks_path=$(command -v luarocks)"
luarocks --version

/usr/bin/luarocks install busted
/usr/bin/luarocks install lua-cjson
echo "busted_path=$(command -v busted)"
busted --version

export LUA_INIT='if jit then jit.off() end'
echo "LUA_INIT=$LUA_INIT"
echo "LUAJIT_BIN=$(command -v luajit)"
echo "LD_LIBRARY_PATH=/workspace/target/release"
echo "VALGRIND_SUPPRESSIONS=/workspace/valgrind.supp"

set +e
LD_LIBRARY_PATH="/workspace/target/release" \
  valgrind \
    --trace-children=yes \
    --error-exitcode=1 \
    --leak-check=full \
    --show-leak-kinds=definite,indirect,possible \
    --errors-for-leak-kinds=definite,indirect,possible \
    --num-callers=24 \
    --suppressions=/workspace/valgrind.supp \
    busted --lua="$(command -v luajit)" tests/lua \
      --lpath='./lua/?.lua'
test_rc=$?
echo "valgrind_busted_exit_code=$test_rc"
exit "$test_rc"
