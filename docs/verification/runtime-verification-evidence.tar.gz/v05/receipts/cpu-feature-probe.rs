fn main() { println!("avx2={} pclmulqdq={}", std::is_x86_feature_detected!("avx2"), std::is_x86_feature_detected!("pclmulqdq")); }
