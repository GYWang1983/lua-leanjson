# Task 1 implementation report

Status: final grouped review fixes implemented and committed in `5729eb2bcacf015f54dcbc039cb3192ac13a4e91`. Supervisor owns refreshed resource/memory/HTTP acceptance and scoped review confirmation; the final-wave section below supersedes earlier candidate verification status.

Initial bounded-runtime candidate: `1f21ab56f87327afa968f35536238b19f06182d3` (`fix: reclaim shared spill workspace regions`), following `e10ce530a896d0dbea10648a1341cb24c895b220` (`feat: bound source indexes and stream sparse views`). Runtime baseline was `69261582`, approved plan `58b0094`. The first implementation commit contains only 30 explicitly listed runtime, ABI, packaging, focused-test and current-API-document paths; the follow-up contains eight explicitly staged owned paths. Supervisor README, benchmark files, final report, design/plan and unrelated paths were not staged. No push or subagent delegation was performed. The round-1 section below supersedes the candidate revision and verification status.

## Runtime and ABI

- Memory/file/feed high-level APIs now share the sparse source path. Validation reuses the original incremental grammar, enforces complete eager validation and the independent nesting limit, and retains no full native tree underneath Lua.
- Defaults: `index_depth=3`, `index_array_limit=3`, `index_budget_bytes=1048576`, all nonnegative uint32 integers. Zero disables corresponding optional preindexing. Lua rejects nonnumbers, NaN/infinities, fractions, negatives and values above 4294967295 before FFI conversion. Root depth is 0; `a.b.c` is the default frontier. Options propagate through the existing shared OpenResty normalization path.
- Native cache capacity accounting includes node/member vector capacities, excluding the mandatory root record. Optional indexes are allocated as needed within this single per-source budget. Later scans do not retain an additional sibling tree. Cached array-prefix lookups avoid input reads; complete cached objects use decoded-key fingerprints followed by exact decoded-key comparison. Lexical traversal uses cached spans and resumes streaming after the retained prefix. Far/random misses remain scans; there is no unbounded later-access cache.
- Additive `leanjson_source_v2_*` ABI provides explicit sparse options, span roots/handles, stats, clear-indexes, resumable lexical/normalized iteration, targeted lookup and scalar begin. Feed/finish/abort/retain/release and scalar operation pumping reuse unchanged v1 functions. Existing v1 layouts/functions and contiguous parse remain intact. All new exports use unwind barriers. Header and Lua cdef/required-symbol loader agree; Lua rejects older native libraries lacking v2 symbols.
- Immutable spans remain valid after cache removal. Sparse object patches and array range pieces are separate from rebuildable indexes; held children, moved array elements, forks, readers, last-wins whole-value replacement, null/false, delete/re-add order, ownership and stale-yield cancellation retain their semantics.
- Reader count/output stream members and raw proven-clean subtrees without publishing eager Lua member tables. Unknown duplicate status is never treated as clean. Explicit materialization streams into its full result and then discards optional source indexes, including mixed-source results; memory `keep_origin` remains supported.
- Exact duplicate normalization keeps at most eight short keys / 4096 decoded-key bytes per object in its small map, then spills to an on-disk hash table. Fingerprint equality always falls through to full byte comparison, including a forced-collision unit regression. First-key slot and final whole value are retained. Nested detection and parent reader maps share one owned/unlinked active-workspace backing file per source. Virtual byte regions grow with an 8 KiB relocation buffer. Released regions are coalesced and reused; trailing free bytes are truncated. Allocations zero their new/reused region so old hash slots cannot contaminate a new map. Free-region metadata follows current allocation fragmentation rather than historical traversals. Last active-map release closes that file.
- `leanjson.source_stats(proxy)` reports `budget_bytes`, `index_bytes`, `indexed_nodes`, `indexed_depth`, `index_depth`, `index_array_limit`. Additive `leanjson_source_v2_get_workspace_stats` and its separate C struct expose `spill_file_bytes`, `spill_live_regions`, `spill_free_regions`, also returned by Lua. The existing stats struct layout is unchanged. Those three values describe active temporary disk storage, and all are zero when no spilled map is active. These diagnostics do not pretend to measure Lua allocator bytes, live-view identity maps, input/output, patches, traversal/string/duplicate memory, total native heap or RSS. The earlier proposed `lua_index_bytes=0` field was removed.

## Red/green evidence and fixes

1. Initial focused baseline: 1 success / 3 expected failures / 0 errors. Invalid options were accepted, and reads/normalized count/writes populated/copied all sibling Lua tables.
2. Cache-use regression was red: default file array[1] performed a source read. After native cache lookup integration it performs zero source reads; farther access still scans correctly.
3. Broad Lua regression runs exposed and fixed canonical path-child identity after fresh span lookups, releasing last source dependencies from fully synthetic overlays, and preserving non-owning collected mixed-source ancestors. Yield injection tests now hook targeted lookup/length as well as streamed children/scalars.
4. A shutdown SIGSEGV was isolated to double ownership of native iterator release: direct `ffi.gc(pointer, native_release)` plus a cleanup-token fallback could both release during unordered `lua_close` finalization. Scratch `debug-crash/shutdown.lua` reproduced 3/3 SIGSEGV; GDB backtrace remains in `debug-crash/core-backtrace.txt`. The raw 8.7 MiB core and idle disposable debug container were removed after diagnosis at the supervisor's request; reproducer and logs are preserved. One idempotent operation cleanup owner replaced dual finalizers; scalar operations received the same fix. File/feed source leases now share a per-lease once flag between explicit and GC cleanup without capturing their own token. Minimal reproducer then exited 0 in 5/5 runs; mutation property 5 x 200-case runs passed.
5. Child-first, 48-level wide/duplicate objects failed normalized length under `ulimit -n 64` with source I/O error. Shared spill backing fixed the descriptor growth. Automated subprocess regression now passes memory/file/feed length+drain under that limit. Shutdown subprocess checks cover unfinished iterators, suspended scalar operations, retained readers, normal GC and explicit close/abort, and verify owned spool cleanup.
6. Holding one spilled reader while normalizing the same source repeatedly exposed append-only historical region growth. A native held-map regression was red (`284416 > 244224` bytes against the warm-up bound). Reusable/coalesced regions and tail truncation make it green through 24 traversals; dropping the final map proves file length, live regions and free-region metadata are all zero. A Lua regression holds an old reader through 24 independent normalized `length()` + drain operations, checks exact final output and a bounded disk high-water, and finishes with zero active workspace. Focused final command below passed two duplicate-workspace units, seven direct v2 ABI tests and eleven Lua bounded/shutdown tests.

## Commands and results

All commands ran from the isolated worktree. Pinned image: `lua-qjson-dev:task3-repro` (`sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`); `/workspace` mount, `leanjson-bounded-target:/workspace/target`, registry `qjson-cargo-registry:/usr/local/cargo/registry`.

Main gate command:

```sh
docker run --rm \
  -v /Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace \
  -v leanjson-bounded-target:/workspace/target \
  -v qjson-cargo-registry:/usr/local/cargo/registry \
  -w /workspace lua-qjson-dev:task3-repro \
  bash -o pipefail -c 'make openresty-verify >.superpowers/sdd/2026-11-02-bounded-metadata/fullgate-reclamation.log 2>&1; result=$?; tail -40 .superpowers/sdd/2026-11-02-bounded-metadata/fullgate-reclamation.log; exit $result'
```

Final result: **exit 0**. Default, scalar-only and test-panic Rust suites; clippy all targets with `-D warnings`; all **403 Lua tests**; luacheck **0 warnings / 0 errors** in 62 files; 2000 encode property cases; 1000 mutation cases x100 steps; source stress 500 valid +500 mutated cases; source JSONTestSuite 95 valid /188 invalid /35 implementation-defined (11 accepted /24 rejected), file and 17/65536-byte feeds; native HTTP **50/50**. Log: `fullgate-reclamation.log`. Earlier `fullgate.log` passed native checks and 402 Lua tests but stopped at two test-fixture unused-assignment lint warnings; those were fixed without suppression, and `fullgate-retry.log` records the complete previous 402-test pass.

Focused commands during development included `cargo test --locked --offline --release --test source_sparse --test source_stream --test source_ffi`, `cargo clippy --locked --offline --release --all-targets -- -D warnings`, and Busted subsets for bounded metadata, source options/proxy/lifecycle, mutation yields, reader, file/feed and shutdown. New native tests cover 0/1/3 metadata settings, tiny/zero budgets, the frontier, exact lengths, cache hits, escaped final duplicates, wide zero-cache normalization, owned-source release, cache removal with held spans/iterators, ephemeral partial input windows, per-iterator sticky errors, abort propagation, invalid v2 options/status, unchanged v1 layouts and a retained scalar operation through cache clear/owner release.

Final reclamation-focused command, **exit 0**, inside the same mounted image:

```sh
cargo test --locked --offline --release source::duplicates::tests --lib
cargo test --locked --offline --release --test source_sparse
cargo build --locked --offline --release
LD_LIBRARY_PATH=/workspace/target/release busted --lua=/usr/local/openresty/luajit/bin/luajit tests/lua/bounded_metadata_spec.lua tests/lua/source_shutdown_spec.lua --lpath="./lua/?.lua"
```

Locked fuzz compilation, **exit 0** (`fuzz-compile-reclamation.log`; previous receipt `fuzz-compile.log`):

```sh
cargo check --manifest-path fuzz/Cargo.toml --locked --offline --all-targets
```

This compiled all existing fuzz targets, including source/window replay; no new timed fuzz campaign or sanitizer run is claimed.

Isolated package smoke, **exit 0** (`installed-smoke-reclamation.log`; previous receipt `installed-smoke.log`): fresh install in a disposable container, then run outside the checkout with paths restricted to the installed tree:

```sh
luarocks make rockspec/lua-leanjson-scm-1.rockspec --tree /tmp/leanjson-bounded-rock
cd /tmp
env -u LD_LIBRARY_PATH -u DYLD_LIBRARY_PATH \
  LUA_PATH="/tmp/leanjson-bounded-rock/share/lua/5.1/?.lua;/tmp/leanjson-bounded-rock/share/lua/5.1/?/init.lua" \
  LUA_CPATH="/tmp/leanjson-bounded-rock/lib/lua/5.1/?.so" \
  /usr/local/openresty/luajit/bin/luajit /workspace/.github/scripts/installed-package-smoke.lua
```

Memory/file/feed/fork/get/reader/close and OpenResty module imports passed.

Supervisor independently reports Valgrind 3.18.1 lifecycle runs in unfinished/collect/closed modes and deep-spill fixture on the earlier shared-spill candidate: **exit 0, 0 errors, 0 suppressions, 0 bytes in use at exit**. References: `valgrind-unfinished.log`, `valgrind-collect.log`, `valgrind-closed.log` and supervisor deep-spill log in the same scratch task directory. Supervisor plans to rerun these against `1f21ab5`; those final reruns are not claimed here. These were supervisor-run, not silently substituted for a full ASan campaign.

Supervisor reports 63/63 native comparison pairs (33 no-fork, nine two-fork, twelve zero-budget, nine tiny-budget) and paired HTTP semantic/duplicate/capacity/fingerprint checks passing on the earlier shared-spill candidate. Final reruns against the reclamation commit are supervisor-owned and pending when this report was written; do not treat this report as universal RSS proof or the final memory report. Wide-object CPU and disk-I/O costs are substantial and must remain visible in the final comparison.

## Limits / review concerns

- The byte budget bounds rebuildable index capacity, not process memory, active operation workspace, user-held values, mutation payloads, output strings or disk usage. Current decoded keys and explicitly materialized scalar strings may be large. Weak live-view/holder identity state is not allocator-measured by diagnostics.
- Wide normalization trades CPU and temporary disk I/O for retained-memory savings. On-disk open addressing is linear for the acceptance workload; exact comparisons preserve correctness under collisions. No CPU dominance over cjson is claimed.
- Shared spill storage depends on active map sizes and allocation fragmentation, not the index-byte budget. Region reclamation removes the demonstrated accumulation from historical traversals; simultaneously held wide readers can still require substantial temporary disk. There is no promised universal disk/RSS ceiling for arbitrary caller-held operations.
- Memory input still owns the entire input Lua string. File input must remain immutable. Explicit full output/materialization remain full allocations. Existing encoder and Lua exact-offset boundaries remain independent of the metadata options.
- No Kong integration, publication, unrelated dependency work, push or remote branch changes were performed. Native memory-gate conclusions belong to the supervisor's finite paired measurements and do not establish a universal bound for every allocator, workload, active reader set or caller-retained value.

## Task 1 review fix round 1

Commit: `d4ea91c5dc28c8f8c6af922b50772956fede8f0a` (`fix: preserve canonical children during sparse iteration`). Review baseline: `1f21ab56f87327afa968f35536238b19f06182d3`; finalized findings: `task-1-review.md`. Fourteen explicitly staged runtime/ABI/API-doc/test paths only; supervisor README and verification report edits were preserved. No push or delegation.

Both findings are fixed:

1. Unique/current final object-container occurrences from `leanjson.pairs` now use the same canonical child cell as direct reads, including escaped-equivalent duplicate keys. Earlier duplicate occurrences remain lexical snapshots. Iterator snapshots whose logical member changed after construction also remain separate. Existing sparse edits are resolved against the iterator's known original base, avoiding a source lookup for each unchanged key.
2. `leanjson.ipairs` on an object returns an empty numeric iterator, preserving the prior behavior for numeric-looking string keys, ordinary Lua tables, array dispatch, closure checks and mutation-version checks.

The naive per-child targeted lookup would rescan wide objects quadratically, so the fix adds native iterator mode 2 and `leanjson_source_v2_iter_next_current`. Mode 2 scans the object once into the existing bounded/spilled exact-key map, then replays lexical occurrences and compares each span with the final decoded-key value in that map. Hash hits still compare full decoded key bytes. Existing mode 0/1 behavior, node/member/stats struct layouts and v1 ABI remain unchanged. The new export has an unwind boundary and matching header/cdef/required-symbol checks. Lua consumers use the annotation only for object iteration; reader normalization remains on its existing path. A source object `pairs` operation may now require a pre-scan and temporary disk even before its first yielded member; this is documented, and no CPU superiority is claimed.

Named new regressions:

- `shares unique object children between direct reads and pairs` (zero/default budgets; identity and bidirectional linked writes).
- `links the final escaped duplicate while earlier occurrences stay snapshots` (zero/default budgets, mutation of an earlier occurrence before the final one is yielded, canonical final identity and exact normalized output).
- `keeps a pre-mutation iterator snapshot separate from the current object child`.
- `keeps object proxies empty and delegates plain tables to numeric iteration`.
- `streams wide object child links in bounded source passes` (1024 container members, zero budget, 256-byte file windows; reads at most four input-length passes, no retained native indexes).
- Native `annotated_lexical_iteration_marks_exact_final_occurrences_in_two_partial_window_passes`: 128 spilled keys plus escaped/late duplicates; one-byte ephemeral windows; exact lexical order/final flags; exactly twice the input length supplied; cache clear and original owner release; invalid current-output pointer rejected.
- Existing shutdown subprocess fixture now also holds an unfinished spilled annotated iterator through VM shutdown, normal GC and explicit close.

Red/green:

```sh
LD_LIBRARY_PATH=/workspace/target/release busted --lua=/usr/local/openresty/luajit/bin/luajit tests/lua/source_proxy_spec.lua tests/lua/lazy_table_spec.lua tests/lua/bounded_metadata_spec.lua --lpath="./lua/?.lua"
```

Before runtime changes: `104 successes / 5 failures / 0 errors` in `fix-round-1-red.log`: the four new behavioral/bounded tests failed as expected, and the existing discarded-array-view 512 KiB assertion also failed. After the isolated `ipairs` change: `78 successes / 0 failures / 0 errors` in `fix-round-1-ipairs.log`. The first combined native/Lua check passed all eight native tests and the new regressions, but hit the same existing heap assertion (`fix-round-1-focused.log`). Its threshold was not changed; the assertion now reports actual retained KiB and pass number. The existing test passed alone (`--filter=traversed`), then the combined subset passed in five independent fresh processes (`110 successes / 0 failures / 0 errors` each, `fix-round-1-repeat.log`) and in the complete gate below. These observations do not claim a proven allocator explanation for the early subset failure.

Focused native command, exit 0:

```sh
cargo test --locked --offline --release --test source_sparse
```

Eight tests pass, including the new annotated-iteration ABI test. A standalone natural-GC file scan was run sequentially with no competing build/benchmark:

```sh
cargo build --locked --offline --release
LD_LIBRARY_PATH=/workspace/target/release /usr/local/openresty/luajit/bin/luajit .superpowers/sdd/2026-11-02-bounded-metadata/fix-round-1-wide-scan.lua
```

Exit 0, receipt `fix-round-1-wide-scan.log`: **32768** visited containers, sum **536887296**, **65559** source read calls (including scalar reads), **0.687618 CPU seconds**. After two collections: **48.640625 KiB** retained Lua delta, **0 live root child cells**, **0 active root operations**, **0 native index bytes**, **0 spill file bytes**. This is a focused linearity/retention check, not a cjson RSS comparison.

Final canonical command uses the same pinned image, worktree/target/registry mounts and `make openresty-verify` command as above, writing `fullgate-fix-round-1.log`. **Exit 0**: default/scalar/test-panic Rust suites and strict clippy; **408 Lua tests**, no failures/errors; strict luacheck **0 warnings /0 errors** in 62 files; **2000** encode property cases; **1000 x100** mutation steps; **500 valid +500 mutated** source stress; JSONTestSuite **95/188/35** classifications; native HTTP **50/50**. Existing lifecycle, duplicate lexical iteration, ordered encoding, mutation-yield, bounded metadata and reader tests are included.

The additive ABI warranted rerunning locked fuzz compilation and isolated package smoke with the exact commands above: both **exit 0**. Logs: `fuzz-compile-fix-round-1.log`, `installed-smoke-fix-round-1.log`. No timed fuzz campaign or sanitizer run is claimed.

Runtime is frozen at this commit for independent review and supervisor-owned refreshed measurements. Earlier 63-pair/HTTP/Valgrind records remain historical evidence for `1f21ab5`; the supervisor is also correcting cjson-only module imports and HTTP decoder-option forwarding before producing final acceptance records. This report makes no final corrected-baseline RSS claim.


## Final grouped review fix wave

Commit: **5729eb2bcacf015f54dcbc039cb3192ac13a4e91** (fix: harden spill hashing and benchmark provenance). Base: e7b3218bfce7dfbc83e59d4ca47988b413bcf5bb. All three findings from final-review.md are addressed together. Explicit commit manifest: src/source/duplicates.rs, scripts/verify-memory.py, tests/test_verify_memory.py, docs/verification/bounded-metadata-checks.txt, docs/verification/bounded-metadata-final-checks.txt. No README, refreshed measurements, raw logs, JSONL, native ABI/options, Lua runtime files, dependencies, push or delegation changed.

### Collision amplification

Each spilled DiskMap now creates its own standard-library RandomState and hashes the complete decoded key through BuildHasher::hash_one. This replaces the public fixed FNV hash itself; it does not salt a prior FNV result. Insertion and is_current use the same map state, and growth redistributes the already keyed fingerprints under that unchanged state. Fingerprint hits still require complete decoded-key comparison. Output records retain their existing first-position/final-whole-value semantics. Shared backing storage, bounded relocation, reclamation, unlinked-file lifetime and cache budgets are unchanged. Only a constant hash-builder state is added per active spilled map; test read counters are cfg(test) and absent from production.

Two deterministic regression tests generate exactly the review's 1024 ASCII keys with legacy FNV1a64(key) &2047 ==0 (first k990, last k2034177). The tests inject BuildHasherDefault<DefaultHasher> through the same generic map operations to make file-read work counts reproducible; production construction always selects RandomState. They count actual read_exact operations, including relocation, rather than asserting wall-clock timing. Bounds are 65536 insertion/rehash reads and 32768 current/stale lookup reads for this fixture.

Focused RED command inside the same pinned/mounted dev image:

~~~sh
cargo test --locked --offline --release --lib legacy_fnv_bucket_keys -- --nocapture
~~~

Exit **101**, final-wave-native-red.log:

~~~text
1024 legacy bucket keys: insertion/rehash 920807 file reads
1024 legacy bucket keys: current/stale lookup 1053696 file reads
test result: FAILED. 0 passed; 2 failed
~~~

Focused GREEN command:

~~~sh
cargo test --locked --offline --release --lib source::duplicates::tests -- --nocapture
~~~

Exit **0**, final-wave-native-green.log:

~~~text
1024 legacy bucket keys: insertion/rehash 7085 file reads
1024 legacy bucket keys: current/stale lookup 7138 file reads
test result: ok. 4 passed; 0 failed
~~~

Covering names: legacy_fnv_bucket_keys_have_linear_insertion_and_rehash_work; legacy_fnv_bucket_keys_have_linear_current_lookup_work; fingerprint_collision_still_compares_full_decoded_keys; held_workspace_does_not_accumulate_historical_traversal_regions. The forced full-fingerprint collision test now explicitly grows the table, replaces the duplicate, and verifies both current/stale lookup before checking exact retained values/order. The storage reclamation regression remains unchanged and green. These counters are logical file-read operations, not claimed kernel-syscall measurements. Keyed hashing removes the cheap public FNV bucket construction; it does not establish universal worst-case CPU/RSS bounds.

### Immutable image execution and packaged Lua provenance

The memory runner now resolves the requested Docker reference before constructing any container commands. Revision inspection, native fingerprinting, installed-Lua export, fixture generation and every measured process use that resolved ID. The requested reference is still recorded separately for readability.

For runtime images, tar exports the installed Lua tree by ID; Python reads regular .lua entries without extracting paths and hashes relative path/NUL/content/NUL in the same Path ordering used for mounted sources. Tar order, timestamps and permissions are excluded. Both native and Lua hashes are checked before/after the run, so packaged Lua is no longer null or silently omitted.

New host-side provenance tests exercise the real runner orchestration with fake Docker I/O, not fake memory claims:

~~~sh
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s tests -p test_verify_memory.py -v
~~~

Before runner changes: **exit1, 3 tests with4 subtest failures** (final-wave-runner-red.log): mutable-tag revision/execution in both mounted/runtime-image modes, a null packaged Lua hash, and an undetected Lua-only change. After changes: **exit0, Ran3 tests, OK** (final-wave-runner-green.log). Names:

- test_mutable_tag_is_resolved_once_and_every_container_executes_its_id
- test_packaged_lua_digest_hashes_names_and_contents_not_archive_metadata
- test_packaged_lua_change_is_rejected_even_when_native_hash_stays_identical

A metadata-only compatibility probe also ran tar by the prior exact image ID sha256:94b90eff3bc0323118abd43052b0b1a5db44122e3c75ee11e9d366f8e0a773fa, reading its installed Lua files with the same algorithm. Exit0 (final-wave-installed-lua-probe.log):

~~~text
Installed Lua metadata-only probe: 14 files, sha256=9472b8880f4d4949010ec210bf8962008539819a3b18d29d805efbcfd5390db3, matches mounted tree
~~~

This validates installed-tree hashing compatibility; it is not a resource/acceptance run of the newly hardened native runtime.

### Receipt whitespace

Trimmed trailing spaces/tabs only: **16 lines** in bounded-metadata-checks.txt and **17 lines** in bounded-metadata-final-checks.txt. Programmatic comparison against base verified every line differs only by trailing spaces/tabs, with unchanged **218/251** line counts. Original raw logs, their recorded hashes and every JSONL artifact remain untouched. Whole-branch check:

~~~sh
git diff --check 69261582ca7c0684c5453d7f270c091078c091b5
~~~

Exit0, no output, including the final commit.

### Final integrated checks

Exact canonical command:

~~~sh
docker run --rm \
  -v /Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata:/workspace \
  -v leanjson-bounded-target:/workspace/target \
  -v qjson-cargo-registry:/usr/local/cargo/registry \
  -w /workspace lua-qjson-dev:task3-repro \
  bash -o pipefail -c 'make openresty-verify >.superpowers/sdd/2026-11-02-bounded-metadata/final-wave-fullgate.log 2>&1; result=$?; tail -40 .superpowers/sdd/2026-11-02-bounded-metadata/final-wave-fullgate.log; exit $result'
~~~

**Exit0**. Default/scalar/test-panic native suites, strict clippy, **408 Lua successes /0 failures /0 errors**, luacheck **0 warnings /0 errors in62 files**, **2000** encode property cases, **1000 x100** mutation cases/steps, source stress **500 valid +500 mutated**, JSONTestSuite **95 valid /188 invalid /35 implementation-defined (11accept/24reject)** on file and17/65536-byte feeds, native HTTP **50/50**. Existing normalized reader, source mode/options, index capacity, decoded duplicates, canonical children, snapshot/fork, cancellation, shutdown and deep-spill coverage are included.

Inside the same mounted image, locked offline fuzz compilation:

~~~sh
cargo check --manifest-path fuzz/Cargo.toml --locked --offline --all-targets
~~~

**Exit0**, final-wave-fuzz.log; all targets compiled. No timed fuzz campaign or sanitizer run is claimed.

Fresh installed-package smoke in another disposable container:

~~~sh
luarocks make rockspec/lua-leanjson-scm-1.rockspec --tree /tmp/leanjson-bounded-rock
cd /tmp
env -u LD_LIBRARY_PATH -u DYLD_LIBRARY_PATH \
  LUA_PATH="/tmp/leanjson-bounded-rock/share/lua/5.1/?.lua;/tmp/leanjson-bounded-rock/share/lua/5.1/?/init.lua" \
  LUA_CPATH="/tmp/leanjson-bounded-rock/lib/lua/5.1/?.so" \
  /usr/local/openresty/luajit/bin/luajit /workspace/.github/scripts/installed-package-smoke.lua
~~~

**Exit0**, final-wave-installed.log: Installed LeanJSON memory/file/feed/fork/get/reader/close and OpenResty imports passed.

Self-review checked all three final-review findings, the production hash constructor and rehash/current paths, exact collision handling, test-only counter exclusion, ID propagation through every Docker command, packaged path/content hashing and unchanged receipt data. Worktree clean after commit. Runtime/harness are frozen and CPU idle for supervisor-owned four Valgrind probes, 63 strict pure-cjson comparisons, paired HTTP, exact committed image checks and the scoped final review. The earlier acceptance artifacts establish their recorded revisions; no refreshed resource/memory result for 5729eb2 is claimed here.
