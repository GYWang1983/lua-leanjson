local ffi = require("ffi")
local cjson = require("cjson")
local function out(name, value) print(name, tostring(value)) end
out("runtime", jit.version)
out("native-cjson", cjson._VERSION)
out("literal-negative-zero-reciprocal", 1 / -0.0)
out("computed-negative-zero-reciprocal", 1 / (-1 / math.huge))
out("native-encode-literal-negative-zero", cjson.encode(-0.0))
out("native-encode-computed-negative-zero", cjson.encode(-1 / math.huge))
for _, raw in ipairs({"-0", "-000", "-0.0", "-0e0", "-0x0p0", "-1e-9999"}) do
    out("tonumber-reciprocal-" .. raw, 1 / tonumber(raw))
    local ok, value = pcall(cjson.decode, raw)
    out("native-decode-reciprocal-" .. raw, ok and 1 / value or value)
end
for _, raw in ipairs({"2\0bad", "2\0", "2x", "2"}) do
    out("tonumber-" .. string.format("%q", raw), tonumber(raw))
    local ok, result = pcall(cjson.encode, setmetatable({}, {
        __len = function() return raw end, __index = {"a", "b"},
    }))
    out("native-external-" .. string.format("%q", raw), ok and result or "ERROR: " .. result)
end
local calls = 0
local mt = {__ipairs = function() calls = calls + 1; return function() end end,
    __len = function() return 99 end}
local t = setmetatable({}, mt)
out("native-table-length", #t)
for _ in ipairs(t) do error("unexpected element") end
out("native-table-ipairs-metamethod-calls", calls)
local ud = newproxy(true)
getmetatable(ud).__ipairs = mt.__ipairs
local ok, err = pcall(function() for _ in ipairs(ud) do error("unexpected element") end end)
out("native-userdata-ipairs", ok and "empty" or err)
out("native-userdata-ipairs-metamethod-calls", calls)
ffi.cdef[[double strtod(const char *, char **);]]
out("strtod-negative-zero-reciprocal", 1 / ffi.C.strtod("-0.0", nil))
