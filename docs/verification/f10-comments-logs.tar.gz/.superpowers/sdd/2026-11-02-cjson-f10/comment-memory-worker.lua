local method,source,input,output,oracle=arg[1],arg[2],arg[3],arg[4],arg[5]
local json
if method=='leanjson' then
 package.preload.cjson=function() error('native cjson denied for target',0) end
 json=require('leanjson').new();json.decode_allow_comment(true)
end
local native=assert(package.loadlib(oracle,'luaopen_cjson'))()
local metrics=require 'metrics'
if not json then json=native.new();json.decode_allow_comment(true) end
local phases={}
local function sample(name) local s=metrics.sample();s.stage=name;phases[#phases+1]=s end
sample('baseline')
local f=assert(io.open(input,'rb'));local size=assert(f:seek('end'));assert(f:seek('set',0))
local value,raw
if method=='cjson' or source=='memory' then raw=f:read('*a');value=json.decode(raw)
elseif source=='file' then value=json.decode_file(input,{chunk_size=4096,index_budget_bytes=0})
else
 local d=json.new_decoder({chunk_size=4096,index_budget_bytes=0})
 while true do local b=f:read(4096);if not b then break end;assert(d:feed(b)) end
 value=assert(d:finish());d:close()
end
f:close();sample('decoded');assert(value.model=='original');assert(value.items[1].id==1)
value.model='rewritten';local sink=assert(io.open(output,'wb'));local length,max_chunk=0,0
if method=='cjson' then local s=json.encode(value);length=#s;sink:write(s)
else
 local r=json.reader(value,{chunk_size=4096,normalize_duplicates=true});length=assert(r:length())
 while true do local b,e=r:next();assert(not e,e);if not b then break end;sink:write(b);max_chunk=math.max(max_chunk,#b) end
 r:close();assert(max_chunk<=4096);json.close(value)
end
sink:close();sample('output')
local peak=0;for _,s in ipairs(phases) do peak=math.max(peak,s.hwm_kib) end
print(native.encode({method=method,source=source,input_bytes=size,output_bytes=length,max_chunk=max_chunk,peak_rss_kib=peak,phases=phases}))
