# SDD ledger — plan: docs/design/plans/2026-11-02-cjson-f10.md

Base af4f9df; branch fix/cjson-comments. Existing isolated worktree verified clean before task. User explicitly authorizes implementation and commit to local main; no push.

| Task / shared interface | Conflict scan | Resolution |
| --- | --- | --- |
| Task1 parser/diagnostic/output | All need consistent comment policy and source flags | One implementer owns coupled runtime/test changes. |
| Task1 source v2 / legacy | New mode bit versus strict zero mode and legacy layouts | Additive flag/mode only; preserve legacy behavior. |
| Task1 / Task2 | Native input permissiveness versus original source output | Strip actual comments through bounded iterators, no cjson fallback or full materialization. |
| Task1 own tests / runtime | Need initial/resumed source policy, raw output and origin proof | Explicit nine-cell/zero-index/keep_origin/split coverage in task brief. |
| Task2 own gates | Prior memory final32/33 RSS boundary | Keep outcomes honest, no threshold changes/cherry-picking. |

Ruling: reuse current isolated worktree with task branch; no new checkout — preserves known build/cache state — cost if wrong: no extra worktree isolation beyond the existing one.
Ruling: encode emits comment-free output, including unchanged raw containers and keep_origin — native decode/encode semantics and upstream forwarding need valid JSON; unaffected child spellings remain preserved — cost if wrong: users seeking lossless comment preservation would need a separate future output option.

Task1 pending. Task2 pending.

Task1 complete: defaultfalse isolated policy, mode4/spanflag16, shared bounded comment state, diagnostics, all late policy paths, affected-container reconstruction + origin protection. RED16Lua/2Rust, GREEN583Lua; independent review PASS/no findings, five targeted combined-path probes.
Parent fullRust444/444/445, Clippy/Lua lint83clean, HTTP60, finalfocusedRustpolicy12pass. Full nine-cell matrix lazy/preload138pass4diff18unsupported; eager141pass1diff18unsupported. All11F10rows pass, all priorpassing preserved; strictmatrixexit1 retained. Pythoncontrols11 andloading18 pass. Parent578-fixture oracle zero message/value differences on347native rejects, five prior strictpolicy acceptance differences, zero outputerrors;1470splitchecks zero differences plus18strictNUL observations.
Resourceboundary: standardmemory32/33, wide-scalars/memory16320KiB vs16248KiB (+72KiB,1.004431), previous task sameboundary+68KiB. No rerun replaced failure. Additional16MiB comment input: targetfile12788KiB/feed12748KiB vsnative44224/44192KiB; targetmemory45092KiB vsnative44188KiB. Allsemantic/chunkoracles pass. UniversalRSSgoal unproven; disclose actualresults.
Installed-only LuaRocks smoke passes with source/nativecjson fallback denied. Matrix51runtime/header hashes match; built/installednative8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b match. Parent owns docs/report/archive/scoped commit. No runtime changes since review.
Task2 verification complete with resource boundaries. Scoped staging/archive/localmainintegration pending; no push.
