from pathlib import Path
import json,shutil
b=Path('.superpowers/sdd/2026-11-02-bounded-metadata')
names=['matrix-reclaimed-default','matrix-reclaimed-forks','matrix-reclaimed-zero','matrix-reclaimed-tiny']
allrows=[]
for name in names:
 rows=[json.loads(s) for s in (b/name/'results.jsonl').read_text().splitlines()]
 allrows+=rows
 for i in range(1,len(rows),2):
  c,l=rows[i:i+2]
  assert c['method']=='cjson' and l['method']=='leanjson'
  assert c['oracle_passed'] and l['oracle_passed']
  assert l['worker_hwm_kib']<=c['worker_hwm_kib']
Path('docs/verification/bounded-metadata-after.jsonl').write_text(''.join((b/n/'results.jsonl').read_text() for n in names))
shutil.copyfile(b/'http-benchmark-reclaimed.jsonl','docs/verification/bounded-metadata-http.jsonl')
rows=[json.loads(s) for s in (b/names[0]/'results.jsonl').read_text().splitlines()]
def pair(case,source):
 return [next(r for r in rows if r.get('case')==case and r.get('source')==source and r.get('method')==m) for m in ('cjson','leanjson')]
labels={'short-elements':'32,768 short array objects','wide-objects':'32,768 small-object fields','wide-scalars':'32,768 scalar fields'}
table='| Shape | Source | cjson RSS | LeanJSON RSS | cjson CPU | LeanJSON CPU |\n| --- | --- | ---: | ---: | ---: | ---: |\n'
for case,label in labels.items():
 for source in ('memory','file','feed'):
  c,l=pair(case,source)
  table+=f"| {label} | {source} | {c['worker_hwm_kib']/1024:.2f} MiB | {l['worker_hwm_kib']/1024:.2f} MiB | {c['elapsed_cpu_s']*1000:.1f} ms | {l['elapsed_cpu_s']*1000:.1f} ms |\n"
http=[json.loads(s) for s in (b/'http-benchmark-reclaimed.jsonl').read_text().splitlines()]
httptable='| Shape | cjson RSS | LeanJSON RSS | cjson p50 | LeanJSON p50 |\n| --- | ---: | ---: | ---: | ---: |\n'
for case in ('short-elements','wide-objects'):
 c,l=[next(r for r in http if r['scenario']==case and r['method']==m) for m in ('cjson','leanjson')]
 assert c['oracle']['passed'] and l['oracle']['passed']
 httptable+=f"| {labels[case]} | {c['worker_hwm_kib']/1024:.2f} MiB | {l['worker_hwm_kib']/1024:.2f} MiB | {c['p50_ms']:.0f} ms | {l['p50_ms']:.0f} ms |\n"
env=rows[0]
section=f'''## Updated runtime

Measured runtime commit: `1f21ab56f87327afa968f35536238b19f06182d3`.
Pinned development image: `{env['image']}`, image ID
`{env['image_id']}`. Linux ARM64, native OpenResty 1.29.2.4,
LuaJIT 2.1 and Rust 1.90. Native library SHA256:
`{env['runtime']['native_sha256']}`; Lua runtime tree digest:
`{env['runtime']['lua_sha256']}`. The image revision is the development
image's own revision, not the mounted runtime revision. The checkout was dirty
only because the supervisor was preparing documentation. Native and Lua
fingerprints remained unchanged throughout all four matrices.

**63/63 paired process comparisons passed**, including every complete semantic,
duplicate-output, length/chunk and metadata-budget assertion:

| Configuration | Cases across memory/file/feed | Passed pairs |
| --- | --- | ---: |
| Defaults: depth 3, array prefix 3, 1 MiB budget, direct mutation | 11 shapes/access patterns | 33/33 |
| Defaults with two independent forks | Short array objects, wide objects, wide scalars | 9/9 |
| Depth 0, array prefix 0, budget 0, direct mutation | Far-array read, natural-GC wide traversal, wide duplicates, deep objects | 12/12 |
| Depth 1, array prefix 1, 512-byte budget, direct mutation | Short array objects, wide objects, wide scalars | 9/9 |

The default matrix also includes late/escaped duplicates, long prompts/messages,
explicit-close traversal and natural-GC traversal. It uses a 1 MiB fixture
**target**, not an assertion that every generated document has the same size:
32,768 short objects occupy 939,196 bytes, wide small-object fields 1,222,992
bytes, and wide scalar fields 469,328 bytes. A `model` field is added for the
same routing-style edit in both implementations.

{table}
The old baseline above uses two forks. Its directly comparable updated
completed-file/two-fork results are 13.62 MiB (array objects), 14.96 MiB (wide
objects), and 14.84 MiB (wide scalars), versus paired cjson 27.54, 34.47, and
19.61 MiB respectively. Do not compare the old two-fork rows to direct-mutation
rows as if only the implementation changed.

Raw process records: [bounded-metadata-after.jsonl](bounded-metadata-after.jsonl).
Each matrix starts with its own environment record. `source_stats.index_bytes`
measures retained native index capacity, not the entire Rust/Lua allocator.

### Real HTTP comparison

Fresh OpenResty workers, completed-file input, two concurrent clients, three
requests per client (six timed requests per method/shape), direct mutation,
64 KiB reader chunks. All four semantic oracle probes passed. These are small
local runs, not production throughput forecasts.

{httptable}
**Memory improved; wide-object processing is still much slower than cjson.**
Exact duplicate handling spills large key maps to disk and performs many small
synchronous I/O operations. The wide-object HTTP run recorded roughly 2.7
million write syscalls and 5.6 million read syscalls over six requests. This is
an explicit CPU/I/O/latency cost, not a speed improvement. Consider it before
using this path for latency-sensitive workloads consisting of many small fields.

Raw HTTP records: [bounded-metadata-http.jsonl](bounded-metadata-http.jsonl).

## Functional and resource checks

On the same runtime: complete `make openresty-verify` passed Rust default,
scalar-only and panic-injection suites, strict clippy, **403 Lua tests**, clean
luacheck (62 files), 2,000 encode property cases, 1,000 mutation cases x100
steps, 500 valid +500 mutated source stress cases, the pinned source corpus,
and **50/50 native HTTP checks**. All fuzz targets compiled with the locked
offline manifest; this is not a new timed fuzz campaign. A fresh isolated
LuaRocks installation passed memory/file/feed/fork/get/reader/close/import smoke
checks from outside the checkout with library paths restricted to that install.

Four independent Valgrind 3.18.1 probes (unfinished iterators, normal GC,
explicit close, and deep shared spill) exited zero with **0 errors, 0 suppressed
errors and 0 bytes in use at exit**. JIT was disabled for these probes; they do
not replace an exhaustive sanitizer campaign. A 48-level child-first
wide/duplicate fixture passed under a 64-descriptor limit. The held-reader
regression repeats 24 length/drain traversals, checks reused/coalesced spill
regions, bounded backing-file high-water, and zero file/live/free state on final
release. These address actual shutdown double-release and active-workspace
reclamation defects found during implementation.

Selected check receipts: [bounded-metadata-checks.txt](bounded-metadata-checks.txt).
Independent review and exact committed runtime-image smoke are recorded after
their final completion; they are not claimed by the process measurements.

## Reproduction

Build the mounted runtime in the pinned development image using
`make openresty-verify`; then run these sequentially with no competing builds.
Every output directory must be new/empty. `make openresty-memory-gate` is the
convenient default entry point; explicit commands for all 63 pairs are:

```sh
python3 scripts/verify-memory.py --image lua-qjson-dev:task3-repro \\
  --target-volume leanjson-bounded-target --branches 0 --output-dir /tmp/lean-default
python3 scripts/verify-memory.py --image lua-qjson-dev:task3-repro \\
  --target-volume leanjson-bounded-target --branches 2 \\
  --cases short-elements wide-objects wide-scalars --output-dir /tmp/lean-forks
python3 scripts/verify-memory.py --image lua-qjson-dev:task3-repro \\
  --target-volume leanjson-bounded-target --branches 0 \\
  --index-depth 0 --index-array-limit 0 --index-budget-bytes 0 \\
  --cases short-elements:far wide-objects:scan-auto wide-duplicates deep-objects \\
  --output-dir /tmp/lean-zero
python3 scripts/verify-memory.py --image lua-qjson-dev:task3-repro \\
  --target-volume leanjson-bounded-target --branches 0 \\
  --index-depth 1 --index-array-limit 1 --index-budget-bytes 512 \\
  --cases short-elements wide-objects wide-scalars --output-dir /tmp/lean-tiny
```

The `leanjson-bounded-target` volume must hold that revision's release library;
the runner records/checks fingerprints but does not compile it. To reproduce
HTTP rows, run `scripts/benchmark-openresty.sh` inside the same development
image with the checkout and target volume mounted, setting
`LEANJSON_BENCH_CASES="short-elements wide-objects"`,
`LEANJSON_BENCH_BYTES=1048576`, `LEANJSON_BENCH_BRANCHES=0`,
`LEANJSON_BENCH_CONCURRENCY=2`, and `LEANJSON_BENCH_REQUESTS=3`.

'''
p=Path('docs/verification/bounded-metadata.md')
s=p.read_text(); start=s.index('## Updated runtime'); end=s.index('## Scope of conclusions')
p.write_text(s[:start]+section+s[end:])
summary='''## Measured advantages and current limits

The bounded-metadata runtime passed **63/63** paired native-process memory
checks across memory/file/feed sources, defaults, zero/tiny budgets, traversal
and forks. The following rows use 32,768 entries, completed-file input,
direct mutation and no forced GC during measured phases:

| Shape | lua-cjson peak RSS | LeanJSON peak RSS |
| --- | ---: | ---: |
'''
for case,label in labels.items():
 c,l=pair(case,'file');summary+=f"| {label} | {c['worker_hwm_kib']/1024:.2f} MiB | {l['worker_hwm_kib']/1024:.2f} MiB |\n"
summary+='''
**The memory reduction has a CPU/I/O cost.** In the paired local HTTP run with
two concurrent clients, the wide-object case used 16.70 MiB versus cjson's
46.82 MiB, but p50 latency was **1,461 ms versus 30 ms**. Wide exact-key
normalization currently uses many synchronous disk operations. This is not a
speed improvement or a production latency guarantee.

The [bounded-metadata report](docs/verification/bounded-metadata.md) records
exact revisions, fingerprints, all process modes, CPU/HTTP results, raw data and
validation boundaries. These finite tests fix the measured small-object
regression; they do not prove lower RSS for every JSON shape or caller behavior.
Earlier [historical measurements](docs/verification/openresty-json-source.md)
and their original qjson labels remain available for traceability.

'''
p=Path('README.md');s=p.read_text();start=s.index('## Measured advantages and current limits');end=s.index('Additional boundaries:',start);p.write_text(s[:start]+summary+s[end:])
