from pathlib import Path
import importlib.util,json
root=Path.cwd();base=root/'.superpowers/f08-f09-f11-f12';out=base/'focused-upstream-final'
spec=importlib.util.spec_from_file_location('verify',root/'scripts/verify-cjson-compat.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
inv=v.inventory(root/'vendor/lua-cjson')
rows=[c for c in inv['cases'] if c['suite']=='test.lua' and (220<=c['line']<=282 or c['line'] in (312,314))]
source=(root/'vendor/lua-cjson/tests/test.lua').read_text();lines=source.splitlines(keepends=True)
prelude=source[source.index('local function gen_raw_octets()'):source.index('local cjson_tests =')]
code=prelude+'\nutil.run_test_group({\n'+''.join(''.join(lines[c['line']-1:c['end_line']])+'\n' for c in rows)+'\n})\n'
out.mkdir(exist_ok=True);(out/'upstream-slice.lua').write_text(code)
summary={'adaptation':'Exact upstream row definitions and fixture helpers, isolated at library defaults; excludes unavailable depth resets. Original complete matrix classifications remain unchanged.','selected_ids':[c['id'] for c in rows],'matrix':{}}
with v.Environment(root,out,locale_dir=base/'locale') as env:
 ref,_=env.worker(out/'reference','reference','native','memory',rows,kind='control',code=code)
 for r in ref:r['classification']='pass' if r.get('upstream_exact_pass') else 'baseline_failure'
 v.write_records(out/'reference/classified.jsonl',ref);assert all(r['classification']=='pass' for r in ref)
 for mode in v.MODES:
  for source_kind in v.SOURCES:
   cell=mode+'-'+source_kind
   got,_=env.worker(out/cell,'target',mode,source_kind,rows,kind='control',code=code)
   for a,b in zip(ref,got):b['classification']=v.classify(a,b)
   v.write_records(out/cell/'classified.jsonl',got)
   summary['matrix'][cell]=v.summarize(got)
   print(cell,summary['matrix'][cell]['classifications'],flush=True)
v.write_json(out/'summary.json',summary)
