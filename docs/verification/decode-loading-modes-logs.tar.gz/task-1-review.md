# Task 1 review: bc529be → db052d45a841e03370b774080cac1e437dece543

## Spec Compliance

- ❌ Issues found: deterministic cancellation cleanup is incomplete for repeated eager Decoder `finish()` and container `get()`. The separate native source and partially constructed ordinary value in `lua/leanjson/loading.lua:168–192` are not registered with the initiating holder's cancellation scope. Closing the decoder during a yielded rebuild closes the spool but retains the scratch native source and partial tree until the coroutine resumes or becomes collectible. This conflicts with the binding callback/cancellation/cleanup requirement and the documented immediate operation-resource release in `docs/file-source-api.md`.
- ✅ The remaining reviewed loading contracts are implemented: direct eager ordinary construction, immutable selector compilation, single-scan selective construction, full validation of ignored branches, explicit metadata outside automatic index bounds, duplicate ancestor invalidation, source-span preservation, independent repeated Decoder values, and additive ABI/loader support. Evidence is detailed below.
- ⚠️ Unchanged OpenResty Session implementation was outside the changed-source package. The new real HTTP assertions cover both socket and completed-body fallback Session edit visibility (`tests/openresty/loading-handler.lua:34–39`, `tests/openresty/acceptance.lua:73–105`), and the supplied canonical log records those checks passing. I did not independently inspect the unchanged adapter implementation or rerun that suite.
- ⚠️ The supervisor's 18-cell performance measurements are outside Task 1's diff and were not independently regenerated. The Task 1 report correctly states eager ordinary encoding and reader snapshots can cost more memory than cjson; this review does not establish allocator/CPU parity or a universal RSS bound.

## Strengths

- `lua/leanjson/loading.lua:10–35` validates a dense string array and compiles a native selector before file/spool creation; `lua/leanjson/options.lua:31–37` stores that immutable selector in normalized options. Supplied path mutation cannot change the compiled route set.
- `src/source/loading.rs:14–40` shares compiled prefixes. `src/source/loading.rs:115–135` advances those routes during the scanner's existing value traversal, and `src/source.rs:265–310` couples selected construction to validation rather than performing per-path full scans or filtering a full DOM.
- `src/source/loading.rs:136–147` bounds decoded key capture for exact routes to the longest requested key plus one; `src/source/loading.rs:149–165` emits only interesting route/selected events and selected scalar payload. `lua/leanjson/source_memory.lua:26–37` drains construction events per bounded feed.
- `lua/leanjson/loading.lua:88–99` constructs ordinary eager tables/scalars directly, preserves empty arrays, and handles false/null without proxy descendants. `lua/leanjson/loading.lua:120–133` performs whole-value last-key replacement, including removal of stale selected descendants when a later ancestor has no match.
- `lua/leanjson/loading.lua:100–113` preserves source identity and raw spans on selected nodes. `lua/leanjson/nodes.lua:27–32` uses selected cache values before native lookups; `lua/leanjson/nodes.lua:112–126` preserves both lexical occurrences and final/current member identity for iteration. The mutable-overlay and reader paths therefore retain their original source-token semantics.
- `lua/leanjson/loading.lua:135–157` computes retained payload/key/route counts independently of native indexes. `docs/source-proxy-api.md:113–128` explicitly identifies logical byte units and exclusions instead of presenting these counters as allocator or RSS measurements.
- `lua/leanjson/loading.lua:160–163` transfers and clears the first eager result. `lua/leanjson/source.lua:210–246` rebuilds later eager results from immutable source spans, so caller edits do not alter subsequent Decoder results and there is no duplicate retained eager DOM between successful calls.
- `src/source_ffi/loading.rs:18–73` adds panic-boundary exports without changing published structs. `include/leanjson.h:275–296`, the corresponding Lua cdefs/required-symbol checks, `tests/source_loading.rs:108–122`, and the installed module manifest cover ABI and installation integration.
- `tests/lua/decode_loading_spec.lua:61–160` exercises all memory/file/feed variants, scalar roots, duplicates, wildcards, immutable nodes, and malformed ignored subtrees. The new no-cjson fixture exercises ordinary eager values and independent repeated results without the optional dependency.

## Issues

### Critical

None found.

### Important

**I1 — Repeated eager rebuild retains partial values and native resources after explicit close while suspended.**

- Location: `lua/leanjson/loading.lua:168–192`, especially scratch source creation at 172–177, the yielding read at 180, and cleanup deferred until 191–192.
- `M.rebuild` receives `scope` and checks it after reads, but never calls `leases.track` for its own native source or builder. `Backend:read` registers only its temporary backend lease. `Decoder:close` clears `self.backend.loading`, which is the original builder, not this local scratch builder.
- A source callback can yield after an arbitrarily large prefix has been decoded. Explicit close then releases the source descriptor but leaves the partial ordinary tree, scratch scanner, and scratch source reachable from a retained suspended coroutine. Native resources also remain live when GC is stopped. This matters especially for canceled large eager bodies and abandoned workers.
- The added cancellation regression (`tests/lua/decode_loading_spec.lua:292–310`) pauses on the first rebuild read and immediately resumes after closing. It confirms rejection of a late result, but never verifies partial-build cleanup while the coroutine remains suspended.
- Fix: place scratch source and builder ownership in a cleanup record registered with the initiating `scope`. Cleanup must be idempotent, detach the native finalizer before release, null the source, and clear builder root/stack/frame payload references. Finish the same record on success/error, and check cancellation before every post-yield access so a late resume cannot use or release the canceled source again. Add a focused test that pauses after multiple reads, closes while preserving the suspended coroutine, checks builder payload/source cleanup before resumption, and then verifies the late resume returns the closed error.

### Minor

None independently actionable beyond I1.

## Focused risk check and evidence

- Named cross-cutting risk: scratch ownership during repeated eager rebuild. Inspected unchanged `lua/leanjson/leases.lua:58–81` (`finish`, `track`, and `release`) and the previously cut-off `Backend:read`/`notify` implementation in `lua/leanjson/source.lua:75–103`. These confirm holder cancellation executes registered cleanup immediately, while a read record releases only its temporary backend lease. No broader unchanged-code crawl was performed.
- Read the supplied review package in bounded portions; one initially truncated middle section was recovered from that same package. The `source.lua` surrounding implementation was inspected only for the named ownership risk above. No Git commands or Git mutations were performed.
- Ran one new focused Lua probe in the pinned image, using read-only workspace and native-target mounts; no builds or completed suites were rerun. It decoded a 201-element eager array with `chunk_size=64`, completed the initial value, wrapped `loading.new` to hold only a weak observer of the scratch builder, and suspended repeated `finish()` on the fourth source callback. After `input:close()` and `collectgarbage('collect')`, with the coroutine still strongly reachable, output was:

```text
before close: partial elements 47
after close: builder retained true partial elements 47 scratch native retained true spool closed true
after resume true nil leanjson: holder closed
```

- Probe command used `docker run --rm -i`, worktree mounted `/workspace:ro`, `leanjson-bounded-target:/workspace/target:ro`, image `sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`, and `LD_LIBRARY_PATH=/workspace/target/release LUA_PATH='./lua/?.lua;;' /usr/local/openresty/luajit/bin/luajit -`. Input Lua was provided through stdin and created only its normal temporary spool, which explicit close removed.
- Complete probe source is retained here as the reproduction artifact (no separate test file was created):

```lua
local json = require('leanjson')
local loading = require('leanjson.loading')
local input = json.new_decoder({ lazyload = false, chunk_size = 64 })
assert(input:feed('[' .. string.rep('123,', 200) .. '0]'))
assert(input:finish())
local weak = setmetatable({}, { __mode = 'v' })
local old_new = loading.new
loading.new = function(backend)
    local builder = old_new(backend)
    weak[1] = builder
    return builder
end
local calls = 0
input.backend.opts.on_chunk = function()
    calls = calls + 1
    if calls == 4 then coroutine.yield('paused') end
end
local worker = coroutine.create(function() return input:finish() end)
local ok, state = coroutine.resume(worker)
assert(ok and state == 'paused')
print('before close: partial elements', #weak[1].stack[1].values)
input:close()
collectgarbage('collect')
print('after close: builder retained', weak[1] ~= nil,
    'partial elements', #weak[1].stack[1].values,
    'scratch native retained', weak[1].backend.state.source ~= nil,
    'spool closed', input.backend.state.fd == nil)
loading.new = old_new
local resumed, value, err = coroutine.resume(worker)
print('after resume', resumed, value, err)
```

- Existing canonical evidence was inspected rather than rerun: `.superpowers/sdd/2026-11-02-decode-loading-modes/task-1-canonical.log:2476` records 435 Lua successes with no failures/errors; line 2546 records 0 lint warnings/errors across 67 files; line 2557 records source stress counts. The reported suites do not invalidate the focused cancellation finding because their existing repeated-build test resumes before checking resource retention.

## Assessment

**Task quality: Needs fixes.**

The loading architecture and selected-value semantics are well integrated and supported by substantial existing validation. I1 is a concrete ownership gap against the deterministic cancellation contract; register scratch rebuild cleanup before accepting the task.
