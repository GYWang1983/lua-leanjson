import os, subprocess, pathlib, json
root=pathlib.Path.cwd()
out=root/'.superpowers/sdd/2026-11-02-bounded-metadata'
image_id=subprocess.check_output(['docker','image','inspect','lua-qjson-dev:task3-repro','--format','{{.Id}}'],text=True).strip()
for mode in ('unfinished','collect','closed','deep-spill'):
    fixture='tests/lua/fixtures/source_deep_spill.lua' if mode=='deep-spill' else 'tests/lua/fixtures/source_shutdown.lua'
    args=['docker','exec','--env','LUA_INIT=if jit then jit.off() end','--env','LUA_CPATH=/usr/local/openresty/lualib/?.so;/usr/local/lib/lua/5.1/?.so;;','leanjson-bounded-memcheck','valgrind','--error-exitcode=97','--leak-check=full','--show-leak-kinds=definite,indirect,possible','--errors-for-leak-kinds=definite,indirect,possible','--num-callers=24','--suppressions=/workspace/valgrind.supp','/usr/local/openresty/luajit/bin/luajit','-joff',fixture]
    if mode!='deep-spill': args += [mode,'/tmp/leanjson-valgrind']
    with (out/f'valgrind-hardened-{mode}.log').open('w') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
    print('PASS Valgrind',mode,flush=True)
base=['python3','scripts/verify-memory.py','--image',image_id,'--target-volume','leanjson-bounded-target']
matrices=[
 ('matrix-hardened-default',['--branches','0']),
 ('matrix-hardened-forks',['--branches','2','--cases','short-elements','wide-objects','wide-scalars']),
 ('matrix-hardened-zero',['--branches','0','--index-depth','0','--index-array-limit','0','--index-budget-bytes','0','--cases','short-elements:far','wide-objects:scan-auto','wide-duplicates','deep-objects']),
 ('matrix-hardened-tiny',['--branches','0','--index-depth','1','--index-array-limit','1','--index-budget-bytes','512','--cases','short-elements','wide-objects','wide-scalars']),
]
for name,args in matrices:
    with (out/f'{name}.log').open('w') as log:
        subprocess.run(base+args+['--output-dir',str(out/name)],stdout=log,stderr=subprocess.STDOUT,check=True)
    print('PASS',name,flush=True)
args=['docker','run','--rm','--mount',f'type=bind,source={root},target=/workspace,readonly','--mount','type=volume,source=leanjson-bounded-target,target=/workspace/target,readonly','--workdir','/workspace','--env','LEANJSON_BENCH_CASES=short-elements wide-objects','--env','LEANJSON_BENCH_BRANCHES=0','--env','LEANJSON_BENCH_BYTES=1048576','--env','LEANJSON_BENCH_CONCURRENCY=2','--env','LEANJSON_BENCH_REQUESTS=3','--env','LUA_CPATH=/usr/local/openresty/lualib/?.so;/usr/local/lib/lua/5.1/?.so;;',image_id,'scripts/benchmark-openresty.sh']
with (out/'http-benchmark-hardened.jsonl').open('w') as log, (out/'http-benchmark-hardened.stderr').open('w') as err:
    subprocess.run(args,stdout=log,stderr=err,check=True)
print('PASS paired HTTP',flush=True)

revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
tag='lua-leanjson-openresty:bounded-'+revision[:7]
with (out/'image-build-hardened.log').open('w') as log:
    subprocess.run(['scripts/build-openresty-image.sh',revision,tag],stdout=log,stderr=subprocess.STDOUT,check=True)
image_id=subprocess.check_output(['docker','image','inspect',tag,'--format','{{.Id}}'],text=True).strip()
with (out/'image-smoke-hardened.log').open('w') as log:
    subprocess.run(['scripts/verify-openresty-image.sh',image_id],stdout=log,stderr=subprocess.STDOUT,check=True)
(out/'hardened-image.json').write_text(json.dumps({'revision':revision,'tag':tag,'image_id':image_id},indent=2)+'\n')
print('PASS exact committed image',revision,image_id,flush=True)
