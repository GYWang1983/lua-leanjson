import subprocess, pathlib, re, json
root=pathlib.Path.cwd()
out=root/'.superpowers/sdd/2026-11-02-cjson-f13-f14'
base=['docker','run','--rm','-v',str(root)+':/workspace','-v','leanjson-bounded-target:/workspace/target','-v','qjson-cargo-registry:/usr/local/cargo/registry','-w','/workspace','lua-qjson-dev:task3-repro','sh','-lc']
results=[]
for name,cmd in [('rust-default','cargo test --locked --release'),('rust-scalar','cargo test --locked --release --no-default-features'),('rust-panic','cargo test --locked --release --features test-panic'),('clippy','cargo clippy --locked --release --all-targets -- -D warnings'),('final-build','cargo build --locked --release')]:
    with (out/(name+'.log')).open('w') as f:
        result=subprocess.run(base+[cmd],stdout=f,stderr=subprocess.STDOUT)
    text=(out/(name+'.log')).read_text()
    counts=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed',text)]
    row=dict(gate=name,exit=result.returncode,passed=sum(counts));results.append(row)
    print(json.dumps(row),flush=True)
    if result.returncode: break
(out/'rust-gates.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(x['exit'] for x in results))
