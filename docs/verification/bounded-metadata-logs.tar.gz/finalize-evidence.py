from pathlib import Path
import gzip, hashlib, io, json, re, tarfile
b=Path('.superpowers/sdd/2026-11-02-bounded-metadata')
image=json.loads((b/'hardened-image.json').read_text())
assert image['revision']=='5729eb2bcacf015f54dcbc039cb3192ac13a4e91'
assert 'All findings addressed, no new Critical/Important breakage' in (b/'final-rereview.md').read_text()
image_log=(b/'image-smoke-hardened.log').read_text()
assert image['image_id'] in image_log
p=Path('docs/verification/bounded-metadata.md'); s=p.read_text()
marker='The raw-log archive retains original review reports, red/green and full-gate\n'
assert marker in s
s=s.replace(marker, f'''Exact committed runtime image: `{image['tag']}`, built from
`{image['revision']}`, ID
`{image['image_id']}`. The smoke check used the immutable image ID and passed
four memory/file/incremental length-and-SHA cases plus malformed-input
rejection. The runtime contains neither Rust nor Cargo. No hosted CI,
GitHub publication or package publication is claimed.

The [raw-log archive](bounded-metadata-logs.tar.gz) retains original review
reports, red/green and full-gate
''')
p.write_text(s)
logs=['final-wave-native-red.log','final-wave-native-green.log','final-wave-runner-red.log','final-wave-runner-green.log','final-wave-installed-lua-probe.log','final-wave-fullgate.log','final-wave-fuzz.log','final-wave-installed.log']
logs += [f'valgrind-hardened-{m}.log' for m in ('unfinished','collect','closed','deep-spill')]
logs += ['image-build-hardened.log','image-smoke-hardened.log']
receipt=[f"Runtime and harness revision: {image['revision']}", 'Environment: Linux ARM64, OpenResty1.29.2.4/LuaJIT, Rust1.90', 'Selected receipts. Raw bytes and review/command reports are in bounded-metadata-logs.tar.gz.', 'RED logs record expected regression failures, not final failures. No hosted CI or timed fuzz campaign claimed.', '']
pattern=re.compile(r'test result:|successes /|warnings /|cases|ERROR SUMMARY|in use at exit|All heap blocks|Installed LeanJSON|Installed Lua|file reads|Ran 3 tests|^OK$|^FAILED|^OK |^PASS|^1\.\.50$|^ok 50 |Finished|runtime image|Built |sha256=')
ansi=re.compile(r'\x1b\[[0-9;]*m')
for name in logs:
 data=(b/name).read_bytes()
 receipt += [name, 'original log SHA256: '+hashlib.sha256(data).hexdigest()]
 lines=ansi.sub('',data.decode(errors='replace')).splitlines()
 if name=='image-smoke-hardened.log': selected=lines
 else: selected=[line for line in lines if pattern.search(line)]
 receipt += [line.rstrip() for line in selected]+['']
Path('docs/verification/bounded-metadata-final-checks.txt').write_text('\n'.join(receipt)+'\n')
plan=Path('docs/plans/2026-11-02-bounded-metadata.md'); s=plan.read_text()
s=s.replace('- [ ] Independent whole-change review', '- [x] Independent whole-change review'); plan.write_text(s)
with (b/'progress.md').open('a') as f:
 f.write(f"\n- Final exactimagePASS source{image['revision']} ID{image['image_id']};4length/SHA cases+malformedrejection, noRust/Cargo. All requiredfinalgates/reviewscomplete; finaldocs/receipt/archive preparation complete. Preservefeaturebranch/worktree, no push. Collect2Rulings beforeownscratchcleanup; originalrawlogs/JSONL/reviews archivedunchanged.\n")
files=set()
for ext in ('*.log','*.md','*.jsonl','*.py','*.lua'):
 files.update(b.glob(ext))
for f in b.glob('**/summary.json'): files.add(f)
for f in b.glob('**/results.jsonl'): files.add(f)
files.add(b/'hardened-image.json')
files=sorted(files,key=lambda f:str(f.relative_to(b)))
manifest=''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(b))+'\n' for f in files)
archive=Path('docs/verification/bounded-metadata-logs.tar.gz')
with archive.open('wb') as out, gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as zipped, tarfile.open(fileobj=zipped,mode='w') as tar:
 for f in files:
  data=f.read_bytes(); info=tarfile.TarInfo(str(f.relative_to(b))); info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 data=manifest.encode(); info=tarfile.TarInfo('manifest.sha256');info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for line in tar.extractfile('manifest.sha256').read().decode().splitlines():
  digest,name=line.split('  ',1)
  assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
print('Archived and independently hash-verified',len(files),'raw evidence files,',archive.stat().st_size,'compressed bytes.')
print('Rulings retained:')
for line in (b/'progress.md').read_text().splitlines():
 if 'Ruling:' in line: print(line)
