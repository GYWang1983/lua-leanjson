# Independent coverage-results audit

Scope: read-only review of the completed receipts and result files under
.superpowers/sdd/2026-11-03-full-verification/primary for
33d00b522d87cc760f757404186488453ffcb498. No test, build, benchmark, Docker,
or workflow was started by this audit.

## Bottom line

- The canonical make openresty-verify receipt is **not green**. Its first
  failure is openresty-source-corpus: n_number_+1.json was incorrectly
  accepted; the inner make exit is 2.
- The two strict cjson runs are healthy compatibility reports, not harness
  crashes. Both have harness_healthy=true, compatible=false, and exit 1
  because differences are deliberately surfaced.
- The default 33-pair RSS gates pass for both proxy carriers. The 18-cell
  loading runs pass their semantic/byte/type oracles, but are **not RSS gates**.
- The separate HTTP receipt has 72/72 TAP successes. make bench-smoke has a
  real visible failure and supplies no benchmark result.

## Canonical verification counts

The canonical log contains four release cargo-test invocations: the script's
default run (444 passed), scalar-only run (444), panic-feature run (445), and
the default run repeated by make test (444). All had zero failures. The
separate debug scalar receipt also has 444 passed and zero failures. The Lua
suite in the canonical make test repeat is 802 successes, zero failures,
errors, or pending. Luacheck reports 0 warnings and 0 errors in 89 files; the
canonical clippy command completed before the later gates.

The deterministic supplementary outputs in that log are 2 property-test
successes with LEANJSON_PROP_CASES=2000, 17 mutation-property successes with
LEANJSON_MUT_PROP_CASES=1000 and 100 steps, and source stress of 500 valid
plus 500 mutated cases. These preceding successes remain valid evidence, but
do not turn the canonical gate into a pass after the corpus failure.

The separate actual HTTP receipt is exit 0 with TAP 1..72 and every test
marked ok.

## cjson compatibility matrices

Each carrier has a baseline of 164 records: 161 assertion records, of which
160 are applicable passes and 1 is environment-inapplicable, plus 3
setup-success records. Each is followed by the same nine 164-record matrix
cells across memory/file/feed sources.

| carrier and cells | classification per cell |
| --- | --- |
| table, 6 lazy/preload cells | 156 pass, 4 behavioral differences, 3 setup, 1 environment-inapplicable |
| table, 3 eager cells | 159 pass, 1 behavioral difference, 3 setup, 1 environment-inapplicable |
| userdata, 6 lazy/preload cells | 130 pass, 30 behavioral differences, 3 setup, 1 environment-inapplicable |
| userdata, 3 eager cells | 159 pass, 1 behavioral difference, 3 setup, 1 environment-inapplicable |
| table selective, 3 source cells | 62 pass, 18 behavioral differences |
| userdata selective, 3 source cells | 29 pass, 51 behavioral differences |

The classifications are identical for memory, file, and feed in each row.
For full matrix cells, table lazy/preload has exact/logical passes 157/157;
userdata lazy/preload has 131 exact and 148 logical passes; eager cells have
160/160. Selective replay is diagnostic-only: exact-pass count is 0, with
logical passes 62 (table) and 29 (userdata).

### Full-matrix incompatibility IDs and causes

All of the following IDs repeat in each applicable source cell.

- Both carriers, lazy/preload: test.lua:L94 is the module identity check
  (cjson, 2.1.0.11 in the reference versus leanjson, 0.1.0 in the target),
  and agentzh.t:TEST12, TEST13, TEST14 are the cjson array_mt behavior block.
  Eager cells only retain test.lua:L94.
- Userdata lazy/preload additionally has nine decode_cycle IDs:
  decode-cycle:example1.json, example2.json, example3.json,
  example4.json, example5.json, numbers.json, rfc-example1.json,
  rfc-example2.json, and types.json. Their cycle checks return false instead
  of the reference true result.
- Userdata lazy/preload also has exact-carrier differences for these
  direct_decode IDs:
  test.lua:L101,L110,L113,L116,L161,L167,L224,L226,L228,L231,L339,L341,L345,L347,L349,L351,L410.
  Their logical values pass, but the target returns a userdata proxy where the
  native reference returns a Lua table.

### Selective-replay incompatibility IDs and causes

Every selective record is decode_replay; it intentionally does not replay
the full setup/configuration, so it must not be conflated with the configured
lazy/eager matrix cells.

The table's 18 differences are:

- depth policy: test.lua:L164#decode1, L170#decode1 (over-limit arrays or
  objects are returned instead of throwing);
- permissive number policy: L241#decode1, L244#decode1, L247#decode1,
  L250#decode1, L253#decode1 (hexadecimal, leading-zero, Inf, Infinity,
  and NaN throw cases);
- comment handling/diagnostics: L339#decode1, L341#decode1,
  L343#decode1, L345#decode1, L347#decode1, L349#decode1,
  L351#decode1, L353#decode1, L356#decode1;
- safe-error shape/diagnostics: L512#decode1, L515#decode1.

The userdata selective set is those 18 plus these exact carrier-only families:

- agentzh.t:TEST12#decode1, TEST13#decode1, TEST14#decode1,
  TEST19#decode1;
- both #decode1 and #decode2 for each of the nine decode-cycle fixture
  IDs listed above (18 records);
- test.lua:L101#decode1, L110#decode1, L113#decode1, L116#decode1,
  L161#decode1, L167#decode1, L224#decode1, L226#decode1,
  L228#decode1, L231#decode1, and L410#decode1.

Thus the userdata selective total is 18 + 4 + 18 + 11 = 51. The selective
report's pass classifications and differences are captured outputs, not
process/harness failures.

### cjson identity/provenance constraint

The reference is native cjson built from upstream commit
617164a0fe3bb647128178f9caefb304b8573bb6. Its recorded native library SHA is
c7b4036f...3805f07 for table mode and a6ffb239...8dc106 for userdata mode.
The target library is the same prebuilt artifact
8bf0d9f2...ec38c0b in both reports, and the target explicitly denies native
cjson fallback. The generated runner changed only its display header
(tostring(json._VERSION)); definitions and expected values were unchanged.
Therefore the L94 identity difference is a known native-versus-target
identity constraint, not evidence that the reference or harness was replaced.

## Memory and loading receipts

The default memory runner is an actual paired RSS gate: each fresh process
must satisfy the semantic/byte oracle, equal visited-container counts, and
LeanJSON peak RSS / native cjson peak RSS <= 1.

- Table: 33/33 pairs pass; worst ratio is 0.990427 on
  wide-scalars/memory (cjson 16,296 KiB, LeanJSON 16,140 KiB), leaving only
  156 KiB (0.152 MiB) headroom. Largest observed absolute headroom is
  28,420 KiB on deep-objects/feed.
- Userdata: 33/33 pairs pass; worst ratio is 0.999013 on
  wide-scalars/memory (16,212 versus 16,196 KiB), leaving only 16 KiB
  (0.0156 MiB) headroom. Largest observed absolute headroom is 28,272 KiB on
  deep-objects/feed.
- The supplementary 16 MiB prompt/messages runs also pass all 6/6 pairs for
  each carrier; worst ratios are 0.485222 (table) and 0.485313 (userdata),
  with roughly 46.95 MiB minimum headroom.
- Completed budget/fork variants add 44 more RSS-gated pairs with no failures:
  22 per carrier (index-budget 0: 9, index-budget 1024: 9, branches=2: 4).
  The worst table budget/fork ratio is 0.941104 (budget 1024,
  wide-scalars/memory, 960 KiB headroom), and the worst userdata ratio is
  0.956074 (budget 0, wide-scalars/memory, 716 KiB headroom). The branches=2
  subsets peak at ratios 0.518487 (table) and 0.519568 (userdata).

Both loading receipts report 18/18 cells passed (wide eager, selected
preload, and wildcards preload over memory/file/feed). The script asserts
typed semantic output, untouched-byte preservation for preload, modified
output, byte counts, source callback behavior, and runtime fingerprint. It
records peak_rss_kib, but has no RSS ratio or threshold assertion; the loading
result is therefore a semantic/output acceptance result with observed peaks,
not a memory gate. Its own source header describes it as "not a universal RSS
gate."

## Corpus, benchmark, and receipt caveats

- The canonical source corpus fails at
  tests/openresty/source-corpus.lua:33 on n_number_+1.json. The later strict
  supplementary replay reports 95 valid, 188 invalid, and 35
  implementation-defined cases (11 accepted, 24 rejected) over file and
  17/65536-byte feeds under policy
  decode_invalid_numbers(false), decode_validate_utf8(true). That is a
  different policy/harness and does not repair the canonical failure; the two
  results must remain separately reported.
- make bench-smoke exits 2 after compiling cjson, then fails at
  benches/lua_bench.lua:670: attempt to call method 'parse' (a nil value).
  No timing or benchmark comparison is valid from this receipt.
- The canonical wrapper could not assign its outer PIPESTATUS because zsh's
  status is readonly, but the inner make log explicitly reports exit 2 and
  the first failure above. This is a receipt-wrapper defect, not evidence of
  a pass.
- The cjson locale directory recorded in provenance is an external
  old-worktree path; it exists and contains the recorded locale files, but
  should remain visible as provenance rather than being treated as checkout
  state. Loading environments pin revision
  33d00b522d87cc760f757404186488453ffcb498 and native/Lua hashes, while
  their status is dirty because the parent task is deleting historical
  reports and writing the new report.
- The first installed-LuaRocks attempt stopped in a diagnostic probe before
  smoke (boolean concatenation); its retry receipt is exit 0 and reports
  installed memory/file/feed/fork/get/reader/close and OpenResty imports
  passed. Both receipts should stay visible, with the retry treated as the
  completed gate.
