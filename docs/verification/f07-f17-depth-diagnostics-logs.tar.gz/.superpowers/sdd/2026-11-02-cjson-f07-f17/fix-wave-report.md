# Final F07/F17 review fix wave

Addressed all four confirmed P2 findings in review-report.md. This wave changes only three Lua runtime files and adds two focused regression files. It does not modify Rust, native ABI, upstream adapters, or other feature boundaries.

## Changes

- R1: proxy.fork now passes the calling codec's encode_max_depth snapshot limit into snapshot creation, with the existing1000 fallback for internal codecs without that setting. Tests cover an actual5000-container ordinary value through ordinary/safe fork, an exact low boundary and its rejection, and encoding a fork through a different lower-limit codec.
- R2: only snapshots originating from the empty_array sentinel carry an explicit immutable empty_array_sentinel flag. The reader treats that token as native does, without consuming container depth. Ordinary tables and source[] continue counting. Overlay/fork snapshots retain the flag; an actual array edit produces a normal container without the flag. Tests cover ordinary encode, reader:length/full output, fork, proxy assignment, held child proxies and mutation, plus negative controls for actual source arrays, empty Lua tables and marked array tables.
- R3: raw-depth scans check their lease scope immediately before and after every potentially yielding bounded read. Tests force a real scan using accepted source depth1000 versus encode limit3 and chunk size1; closing at the first yield terminates both next() and length() without read2 or returned bytes.
- R4: the shared object-key formatter renders the library's own null/empty_array sentinels as native userdata in unsupported-key errors, while retaining their existing implementation identity/type. A separate fresh LuaJIT subprocess denies cjson and verifies exact messages for ordinary/safe encoding, reader errors and proxy assignment.

Runtime files: lua/leanjson/proxy.lua; lua/leanjson/reader.lua; lua/leanjson/table.lua.

New tests: tests/lua/cjson_depth_review_spec.lua; tests/lua/fixtures/sentinel_key_errors.lua.

## RED / GREEN evidence

- fix-red.log:1success/4failures/1error. R1 high-depth fork stopped at1001; low-limit fork incorrectly succeeded; sentinel reader rejected the native exception; scan resumed into read2 after close; standalone sentinel key errors reported table.
- fix-focused-green.log:6successes/0failures/0errors, after the scoped fixes.
- fix-green.log:567successes/0failures/0errors for the full Lua suite; Lua lint0warnings/0errors in82files. Command exit0.
- Scoped diff against parent fix-base-sources.json confirms only the three runtime changes above. `git diff --check` passes.

Docker commands use image lua-qjson-dev:task3-repro, repository bind-mounted /workspace, leanjson-bounded-target:/workspace/target, and qjson-cargo-registry:/usr/local/cargo/registry. Lua commands set LD_LIBRARY_PATH=/workspace/target/release and use `busted --lua=/usr/local/openresty/luajit/bin/luajit --lpath='./lua/?.lua'`.

Focused command: that busted invocation with tests/lua/cjson_depth_review_spec.lua.

Full command: that busted invocation with tests/lua, followed by `make lua-lint`.

No commits, branch changes, pushes, subagents, Rust source edits or native rebuilds were performed in this wave. Parent owns the final affected integration gates and re-review.
