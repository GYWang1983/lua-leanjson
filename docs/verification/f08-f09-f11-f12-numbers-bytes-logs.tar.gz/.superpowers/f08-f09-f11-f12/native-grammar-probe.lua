local c = require "cjson"
local xs = { ".5", "-.5", "+.5", "1.", "0.", "01", "+012", "0x1", "0X1", "-0X1", "0x1.", "0x.8", "0x1p2", "0x1P+2", "0x1p", "nan(abc)", "NAN(x)", "nan()", "nan(123)", "-nan(x)", "infinite", "INFINITY", "1e9999", string.rep("9",309), "0x1p1024", "0x1.fffffffffffff7p1023", "0x1.fffffffffffff8p1023", "0x1p-999999", "+", "--1", "0x", "0x.p2", "00x2", "1.e1", "-1.", "-Inf", "+inF", "NaNfoo" }
for _, strict in ipairs { false, true } do
c.decode_invalid_numbers(not strict)
for _, s in ipairs(xs) do local ok,n=pcall(c.decode,s); print(strict and "strict" or "native",s,ok,ok and tostring(n) or n) end
end
