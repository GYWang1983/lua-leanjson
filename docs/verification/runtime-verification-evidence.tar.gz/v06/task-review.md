# V06/V08 independent task review

Spec Compliance: **Not yet compliant.** The production and portability changes follow the requested scope, but the runner fails open on incomplete Memcheck summaries. Final V06 distro and V08 rolling full Memcheck proof is also explicitly pending.

Quality: **Needs fixes.** Two findings below. This review does not approve either final Memcheck gate.

Reviewed the requested brief, provisional implementer report and supplied exact 13-file package against base `b2c670e81051d62bc1b2af8979a678f14a484848`. No source edits, commits, subagents or full-suite reruns were performed. Only two isolated, fake-runtime/checker controls were executed to resolve specific runner concerns. The V07 smoke19/Lua820/HTTP72 result is supplied by the parent's separate verifier, not independently established by this review.

## Findings, ranked by severity

### P1 — Incomplete ERROR SUMMARY lines can pass the Memcheck gate

Evidence: `scripts/verify-luajit.sh:66-67`.

The parser marks any line containing `ERROR SUMMARY:` as seen and evaluates `$4+0`. A missing or nonnumeric fourth field converts to zero in awk. It also never requires the rest of the summary to be present. Consequently, the explicit requirement to reject absent/incomplete summaries is not met.

Focused end-to-end control: a fake checker returned 0, wrote a complete zero-error parent summary, and wrote a second child log containing each of the following incomplete lines in turn:

```text
'==999999== ERROR SUMMARY:\n' runner_exit=0
'==999999== ERROR SUMMARY: 0 errors from\n' runner_exit=0
```

Both commands should have failed. The fixture used the real `scripts/verify-luajit.sh memcheck`, a temporary executable LuaJIT stub, a temporary checker and temporary library/output; nothing in the repository was modified.

Require a complete, syntactically valid summary before accepting zero errors. Preserve failure for any nonzero count, missing log, empty log or missing summary. Add runner controls for a missing count and a truncated zero-error summary, including a complete parent plus incomplete child. The existing eight controls do not cover these cases.

### P2 — Reusing an output root overwrites provenance for retained result directories

Evidence: `scripts/verify-luajit.sh:21-25`, `:27-34`, `:39`; related documentation claim in `docs/testing-luajit.md:8-12`.

`runtime.txt` and `source-sha256.txt` live at the shared output root and are overwritten on every invocation. Only the profile result directories are unique. After two invocations with different library/source/runtime contents, the earlier result directory remains but its matching manifest no longer exists; the only root manifest describes the latest invocation. Concurrent invocations using one root can also race on these files.

A focused plain-profile control ran twice using the same output root, first with temporary library bytes `library-A`, then `library-B`:

```text
library-A runner_exit=0
library-B runner_exit=0
profile_count=2
runtime_manifest_replaced=True
profile_runtime_manifests=0
```

Keep the source/runtime/library identity beside each invocation's immutable results, for example in a unique invocation directory containing its manifests and profiles. Extend the reuse control to verify that the first invocation's identity remains intact when a subsequent invocation uses a different library. This also makes the guide's evidence-preservation description accurate.

## Scope and behavior assessment

- `lua/leanjson/number.lua` changes only the conversion fallback for negative noninteger zero/underflow. Plain all-zero integer tokens still return positive zero before the new branch. The fallback retains full-token consumption and its existing private numeric locale; no alternate scanner or native-cjson dependency was added.
- The signed-zero regression uses reciprocal signs, so it distinguishes positive and negative zero. Its initial test matrix includes all memory/file/feed x lazy/eager/preload x table/userdata combinations and includes decimal, exponent, hexadecimal and underflow spellings. The strict-number checks continue rejecting hexadecimal input and preserving fractional signs for accepted decimal forms.
- Negative-zero encode expectations now construct negative zero dynamically instead of depending on the distro compiler's literal folding. The external-array expectation probes the VM conversion capability and still asserts the exact encoded/reader result; the report retains native cjson reference controls rather than treating a different runtime as proof of an original-runtime fix.
- The native `ipairs` capability probe does not replace a builtin. Both carrier modes always exercise portable empty-object traversal and closed ownership; runtime-dependent native behavior is still asserted, including the precise userdata type error on the distro VM. No new skip/pending case appears in the diff.
- The deep-spill child fixture applies the soft descriptor limit inside the tested process and queries it back before loading LeanJSON. The parent command no longer ignores a failed shell `ulimit`. The hard limit is retained.
- The runner selects the requested interpreter, disables JIT through inherited `LUA_INIT`, traces child execs, preserves the direct checker exit code, uses fresh profile log directories and includes a real invalid-write negative fixture. The existing suppression file is outside the change set; no new blanket suppression is present.
- The setup guide describes the selected-runtime command, matching-build-ID debug-symbol installation, physical-frame option and negative control. Its supplied symbol hash and runtime attribution are report claims; this review did not independently re-fetch or symbolize them.
- Full functional, Rust/lint and focused Memcheck outcomes in the provisional report remain implementer-reported results. They were not rerun during this review.

## Pending completion proof

1. Fix both runner findings and run focused runner controls, including the new incomplete-summary and provenance cases. Do not relax checker failure codes or expand suppressions.
2. Obtain the final original-distro V06 full plain + Memcheck receipt, with the exact distro executable/native-cjson identity, source/library hashes, command, suite counts and exit codes. Preserve the expected three documented table-`__len` pending cases explicitly.
3. Obtain the final V08 complete rolling OpenResty LuaJIT full-suite Memcheck receipt separately. Distro proof, an earlier partial rolling observation and V07 functional acceptance do not satisfy this gate.
4. Audit every final per-process Memcheck file with the corrected strict parser: at least one complete valid summary per file, every reported error total zero, no missing/empty/incomplete log accepted. The direct command must exit 0. Attribute any new context before closure, retain the existing narrow runtime suppression identity, and rerun the real invalid-write failure control on the final runner.
5. Attach the final results and immutable provenance to the provisional report and current verification document; record the cancelled/setup attempts only as non-acceptance evidence if retained elsewhere. The current report correctly labels both long runs pending and must not be promoted to passing before these proofs exist.
