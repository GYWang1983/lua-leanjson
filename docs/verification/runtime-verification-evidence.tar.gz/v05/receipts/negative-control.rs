use std::alloc::{alloc, dealloc, Layout};
fn main() {
    unsafe {
        let size = std::hint::black_box(8usize);
        let layout = Layout::from_size_align(size, 8).unwrap();
        let ptr = alloc(layout);
        assert!(!ptr.is_null());
        std::ptr::write_volatile(ptr.add(size), 42);
        dealloc(ptr, layout);
    }
}
