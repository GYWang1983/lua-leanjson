local cjson = assert(package.loadlib("/workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/parent-reference/cjson.so", "luaopen_cjson"))()
local ffi = require("ffi")
io.stdout:setvbuf("no")
local function show(label, fn, ...)
    local ok, value = pcall(fn, ...)
    print(label, ok, type(value) == "string" and string.format("%q", value) or tostring(value))
end
local c = cjson.new()
if arg[1] == "default-getter" then show("indent default", c.encode_indent); return end
if arg[1] == "empty-getter" then c.encode_indent(""); show("indent empty getter", c.encode_indent); return end
show("indent default output", c.encode, { 1 })
show("skip default", c.encode_skip_unsupported_value_types)
local inputs = { "", "  ", "abc", 2, 1.25, 0/0, math.huge, "x\0tail", "\0tail", false, {}, function() end }
for i, value in ipairs(inputs) do
    show("indent set " .. i, c.encode_indent, value)
    show("indent output " .. i, c.encode, { { a = 1 } })
end
c.encode_indent("abc")
show("indent nil", c.encode_indent, nil)
show("indent arity", c.encode_indent, "changed", nil)
show("indent after arity", c.encode_indent)
for i, value in ipairs({ true, "on", false, "off", 0, 1, "true", "ON", "on\0tail", {}, function() end }) do
    show("skip set " .. i, c.encode_skip_unsupported_value_types, value)
    show("skip get " .. i, c.encode_skip_unsupported_value_types)
end
show("skip nil", c.encode_skip_unsupported_value_types, nil)
show("skip arity", c.encode_skip_unsupported_value_types, false, nil)
show("skip after arity", c.encode_skip_unsupported_value_types)
local unsupported = { function() end, coroutine.create(function() end), newproxy(true), ffi.cast("void *", 0), ffi.new("int64_t", 42), ffi.new("uint64_t", 42), ffi.new("double", 1.5) }
for _, indent in ipairs({ "", "  ", "abc" }) do
    c.encode_indent(indent)
    for _, skip in ipairs({ false, true }) do
        c.encode_skip_unsupported_value_types(skip)
        local prefix = string.format("indent=%q skip=%s ", indent, tostring(skip))
        show(prefix .. "empty object", c.encode, {})
        show(prefix .. "empty array", c.encode, c.empty_array)
        for i, value in ipairs(unsupported) do
            show(prefix .. "root " .. i, c.encode, value)
            show(prefix .. "array " .. i, c.encode, { value, 1, value, 2, value })
            show(prefix .. "all-array " .. i, c.encode, { value, value })
            show(prefix .. "all-object " .. i, c.encode, { a = value })
            show(prefix .. "nested " .. i, c.encode, { { a = value } })
            show(prefix .. "invalid-key " .. i, c.encode, { [true] = value })
        end
    end
end
if debug.upvalueid then
    local captured = 1
    local function capture() return captured end
    local light = debug.upvalueid(capture, 1)
    for _, skip in ipairs({ false, true }) do
        c.encode_indent("  "); c.encode_skip_unsupported_value_types(skip)
        show("lightuserdata root skip=" .. tostring(skip), c.encode, light)
        show("lightuserdata array skip=" .. tostring(skip), c.encode, { light, 1 })
        show("lightuserdata object skip=" .. tostring(skip), c.encode, { a = light })
    end
end
