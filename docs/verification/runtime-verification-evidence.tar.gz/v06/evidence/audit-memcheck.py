#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

root = Path(sys.argv[1])
records = []
for path in sorted(root.rglob('memcheck.*.log')):
    raw = path.read_bytes()
    text = raw.decode(errors='replace')
    summaries = re.findall(r'ERROR SUMMARY: ([\d,]+) errors from ([\d,]+) contexts \(suppressed: ([\d,]+) from ([\d,]+)\)', text)
    summary = [int(value.replace(',', '')) for value in summaries[-1]] if summaries else None
    leaks = {kind: max([int(n.replace(',', '')) for n in re.findall(kind + r':\s+([\d,]+) bytes', text)] or [0])
             for kind in ['definitely lost', 'indirectly lost', 'possibly lost', 'still reachable']}
    records.append({'path': str(path.relative_to(root)), 'sha256': hashlib.sha256(raw).hexdigest(),
                    'summary': summary, 'leaks': leaks,
                    'strict_parser_exit': subprocess.run(['awk', '-f', '/Users/wanggy/Projects/lua-qjson/scripts/check-memcheck.awk', str(path)]).returncode,
                    'commands': re.findall(r'==\d+== Command: (.*)', text),
                    'warnings': [line for line in text.splitlines() if 'Warning:' in line]})
failures = [r['path'] for r in records if r['strict_parser_exit'] != 0 or r['summary'] is None or r['summary'][0] != 0
            or any(r['leaks'][kind] for kind in ['definitely lost', 'indirectly lost', 'possibly lost'])]
result = {'root': str(root), 'process_log_count': len(records), 'failed_logs': failures,
          'total_errors': sum(r['summary'][0] for r in records if r['summary']),
          'total_suppressed_errors': sum(r['summary'][2] for r in records if r['summary']),
          'total_suppressed_contexts': sum(r['summary'][3] for r in records if r['summary']),
          'max_still_reachable_bytes': max([r['leaks']['still reachable'] for r in records] or [0]),
          'records': records}
Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'records'}))
sys.exit(0 if records and not failures else 1)
