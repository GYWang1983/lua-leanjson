import tarfile,json,pathlib
w=pathlib.Path('.superpowers/sdd/2026-11-02-cjson-f06');out={};regressions=[]
with tarfile.open('docs/verification/f13-f14-encoding-logs.tar.gz') as t:
 for mode in ('lazy','eager','preload'):
  for source in ('memory','file','feed'):
   cell=mode+'-'+source
   name='.superpowers/sdd/2026-11-02-cjson-f13-f14/matrix/matrix/'+cell+'/records.jsonl'
   old={r['id']:r for line in t.extractfile(name) if (r:=json.loads(line))}
   new={r['id']:r for line in (w/'matrix'/'matrix'/cell/'records.jsonl').read_text().splitlines() if (r:=json.loads(line))}
   lost=sorted(set(old)-set(new));bad=[k for k in old if old[k]['classification']=='pass' and new[k]['classification']!='pass']
   added=[k for k in new if new[k]['classification']=='pass' and old[k]['classification']!='pass']
   row=dict(records=len(new),lost=lost,regressions=bad,new_passes=added,f06=new['agentzh.t:TEST23']['classification'])
   out[cell]=row;regressions.extend(lost+bad);assert row['f06']=='pass';print(cell,json.dumps(row))
(w/'matrix-audit.json').write_text(json.dumps(out,indent=2)+'\n');assert not regressions
