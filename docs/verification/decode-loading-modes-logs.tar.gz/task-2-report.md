# Independent acceptance and documentation (in progress)

Root owns README, scripts/verify-loading.py and tests/openresty/loading-modes.lua.
Probes generate input outside measured workers, run fresh native OpenResty processes,
and compare full typed output with an external Python oracle. A separate cjson-only
worker does not load LeanJSON; cjson decode_array_with_array_mt(true) preserves empty
array shape. Eager uses native rawget/next/pairs. Selective uses all three index limits
set to zero and asserts no extra source callbacks during selected reads (file/feed).
Untouched selective output must equal original bytes, including escaped duplicate
keys; modified normalized output must contain no duplicate keys and equal the entire
expected JSON. The fixture includes an unselected multi-MiB prompt, messages, deep path
and an array position well beyond the automatic prefix. CPU and process VmHWM are
observations, not universal RSS bounds; LeanJSON output uses its bounded reader.

Initial probe checks: python3 -m py_compile scripts/verify-loading.py passed;
luacheck tests/openresty/loading-modes.lua passed (0 warnings, 0 errors).
Runtime-dependent checks remain pending until implementer freezes the runtime.

Supervision caught and requested removal of hidden complete eager DOM retained by
incremental decoders for repeated finish/get, and unnecessary eager per-scalar frame
maps/key arrays. Implementer confirmed correction; final diff/review will verify.

Initial independent acceptance: 18/18 cells passed, runtime fingerprint stable;
raw evidence acceptance-initial/. Eager wide decode peak ~30MiB vs cjson20MiB,
requesting transient-allocation reductions. Initial all-LeanJSON-reader workload
peaked ~93MiB for wide ordinary values because reader intentionally snapshots them
into immutable logical nodes. Direct json.encode already has a plain-table path.
Final comparable eager workload uses json.encode vs cjson.encode; selective keeps
bounded reader. Initial reader cost remains documented and its evidence preserved;
this is not being relabeled as a decoder measurement or hidden by deleting results.

## Final independent evidence

acceptance-final/: 18/18 cells passed. Native SHA20e4db6e52ad82f7378550e2cc3943485e456cc1880e825f69ae445774c29d42 and Lua SHA6bf53d7b021b8bce5afaa320c13d28b8862b8af9d9b8d6f34e5b6591c70ec4fa unchanged before/after runs and after commit db052d4/canonical/install gates. Run command: python3 scripts/verify-loading.py --image lua-qjson-dev:task3-repro --target-volume leanjson-bounded-target --output-dir .superpowers/sdd/2026-11-02-decode-loading-modes/acceptance-final. Raw results and typed/hash oracles preserved.

README and docs/verification/decode-loading-modes.md disclose eager memory/CPU limits, plain-reader snapshot overhead, JSONPath subset, retained full JSON, index exemption, logical diagnostics and Decoder vs Session semantics. Plan checklist reflects implementation/acceptance complete, reviews pending. Root final Python syntax, probe Lua lint and git diff --check passed. No extra runtime edits or remote Git actions.

Self-review: all measurement numbers traced to phase/result records; no claims of universal memory parity, no cjson loaded in baseline through LeanJSON, no GC forced between phases, no missing output hidden by projection. File/feed I/O checks use on_chunk; memory backend has no I/O callback instrumentation. No new HTTP timing or live-provider validation claimed.

Scope: README.md; docs/design/2026-11-02-decode-loading-modes.md; docs/plans/2026-11-02-decode-loading-modes.md; docs/verification/decode-loading-modes.md and raw archive; scripts/verify-loading.py; tests/openresty/loading-modes.lua.

## Runtime-fix refresh

acceptance-reviewed18/18 passed on final runtime1bacb13; nativeSHA unchanged, LuaSHA c6f539b2f4971378e62756cfdda779a6d340227f6ef83ed2126e91aa2e827843. Current Lua source hash rechecked after commit. README and report table/ranges regenerated from this complete refreshed run; all prior runs preserved. Full435Lua/60HTTP canonical evidence remains db052d4, final narrow Lua fix has60 covering tests/full lint; report states these revision boundaries explicitly.
