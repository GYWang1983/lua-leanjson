local selected = assert(os.setlocale("cs_CZ"))
local ffi = require("ffi")
ffi.cdef[[struct localenumeric { char *decimal_point; }; struct localenumeric *localeconv(void);]]
local decimal = ffi.string(ffi.C.localeconv().decimal_point)
assert(decimal == ",")
print("locale", selected)
print("libc decimal point", decimal)
print("LuaJIT string.format (locale independent)", string.format("%.1f", 1.5))
