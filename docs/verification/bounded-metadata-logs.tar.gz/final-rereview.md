# Final scoped re-review

Base: `e7b3218bfce7dfbc83e59d4ca47988b413bcf5bb`.
Head: `5729eb2bcacf015f54dcbc039cb3192ac13a4e91`.

Reviewed the three findings in `final-review.md` against the bounded-metadata design/plan, the prepared five-file fix diff, current changed sources, and the appended final grouped fix-wave report. The initial combined tool output truncated part of the prepared diff; only the omitted sections were recovered in bounded reads. The diff was not rederived. Review remained read-only except for this report; no builds, suites, native workloads, Docker operations, Git mutations, or subagents were used.

## Findings

### Important: chosen-key quadratic synchronous spill I/O — ADDRESSED

- `src/source/duplicates.rs:189`: each production disk map carries its own hash-builder state; its constructor at `:192` selects `RandomState::new()`.
- `src/source/duplicates.rs:205`: `BuildHasher::hash_one` hashes the complete decoded key, replacing fixed public FNV itself. The production path does not merely salt an attacker-collidable FNV fingerprint.
- `src/source/duplicates.rs:237` and `:264`: insertion and current-occurrence lookup use that same map state. Growth at `:214` redistributes stored keyed fingerprints without replacing the state. Exact decoded-key byte/length comparison remains at `:253` and `:273`, preserving collision correctness and final-value behavior.
- The added state is constant-size per active spilled map. File ownership, geometric relocation, shared workspace reclamation, record layout, and optional index-budget semantics remain intact. Read-operation counters at `:47`, `:131`, and `:157` are test-only.
- `src/source/duplicates.rs:354` and `:364`: deterministic shared-path tests use exactly the review's 1,024 legacy FNV bucket keys and bound logical file-read operations for insertion/rehashing and current/stale lookup separately. Production uses randomized state; tests inject deterministic `DefaultHasher` through the same map implementation. The forced full-fingerprint collision test at `:379` also covers growth, duplicate replacement, current/stale lookup, and retained value/order.

Raw evidence agrees with the report: `final-wave-native-red.log` records **920,807** insertion/rehash reads and **1,053,696** current/stale lookup reads, with both tests failing. `final-wave-native-green.log` records **7,085** and **7,138**, within the 65,536/32,768 limits, and all four duplicate-map tests passing. These are instrumented logical reads, not kernel syscall counts. The fix removes the cheap public chosen-bucket construction; it does not promise universal worst-case work bounds.

### Minor: mutable image execution and missing packaged Lua hash — ADDRESSED

- `scripts/verify-memory.py:73`: resolve the requested reference before constructing container commands. Revision inspection at `:74`, native hashing at `:83`, packaged Lua export at `:84`, and all fixture/measurement launches through `:85`/`:109` use the resolved image ID. The original requested reference remains a separate environment field at `:118`.
- `scripts/verify-memory.py:91`: packaged-runtime fingerprinting reads regular installed `.lua` entries from an archive created by that exact image ID. It hashes sorted relative names plus contents with NUL delimiters, matching mounted-source path/content framing and excluding archive timestamps/order. Empty installed source trees fail explicitly. The before/after comparison at `:169` includes both native and Lua digests.
- `tests/test_verify_memory.py:104`, `:112`, and `:120` cover both execution modes, archive metadata/order changes, and rejection of a Lua-only change with an unchanged native hash.

`final-wave-runner-red.log` contains the expected four failures across three tests, including both mutable-tag modes, absent Lua digest, and undetected Lua-only change. `final-wave-runner-green.log` records three passing tests. The installed-tree metadata probe records 14 files and digest `9472b8880f4d4949010ec210bf8962008539819a3b18d29d805efbcfd5390db3`, matching the mounted tree; this is a provenance compatibility check, not new-runtime memory acceptance.

### Minor: 33 copied receipt whitespace errors — ADDRESSED

- `docs/verification/bounded-metadata-checks.txt:158`: all **16** changed lines differ from the base only by removal of trailing spaces/tabs; **218** lines remain.
- `docs/verification/bounded-metadata-final-checks.txt:151`: the corresponding **17** changed lines are likewise trailing-whitespace-only edits; **251** lines remain.
- Independent programmatic comparison confirmed every line's other content and both line counts. All **7 + 11** recorded original-log SHA256 values match the available raw logs. The fix manifest contains no raw log or JSONL edits.
- Independently executed `git diff --check 69261582ca7c0684c5453d7f270c091078c091b5`: **exit 0**, no output.

## New breakage

**None found.** No new Critical, Important, or Minor issue was identified in the scoped fix diff. The native change preserves exact comparison and output ordering; the runner change consistently propagates the immutable ID and checks both fingerprint components.

## Evidence boundary

Inspected raw `final-wave-fullgate.log`: 120 successful native test-result summaries and no failed summaries; **408 Lua successes / 0 failures / 0 errors**; strict Lua lint **0 warnings / 0 errors in 62 files**; passing encode/mutation property invocations; **500 valid + 500 mutated** source stress cases; JSONTestSuite **95 valid / 188 invalid / 35 implementation-defined (11 accept / 24 reject)**; and HTTP TAP **50/50**. The canonical verification script invokes default/scalar/test-panic modes and strict clippy and supplies the reported default property sizes of 2,000 encode cases and 1,000 mutation cases with 100 steps each.

`final-wave-fuzz.log` confirms locked target compilation completed; `final-wave-installed.log` confirms the fresh installed-package memory/file/feed/fork/get/reader/close and OpenResty import smoke passed. These existing receipts were reviewed, not rerun.

The supervisor's refreshed Valgrind, 63-pair strict memory, HTTP comparison, and exact-image acceptance work remains a separate completion gate. This scoped code/evidence review does not certify pending refreshes or substitute older revision measurements for head acceptance. The reported temporary OrbStack interruption is not treated as a native diagnostic.

## Out-of-Scope

None newly identified. Untouched implementation areas were not reopened. Previously disclosed ordinary wide-object CPU/I/O costs and universal RSS/disk limitations remain unchanged.

## Assessment

All findings addressed, no new Critical/Important breakage
