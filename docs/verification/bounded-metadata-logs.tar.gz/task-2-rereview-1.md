### Finding Verdicts

- **Cjson cells eagerly load LeanJSON and contaminate the total-RSS baseline** — **ADDRESSED**. `memory-phases.lua` reads/validates the method before conditionally requiring LeanJSON; cjson cells reject preloaded LeanJSON/runtime/adapter modules (`tests/openresty/memory-phases.lua:3-11`). The handler applies the same method-first conditional imports and rejects contaminated cjson workers (`tests/openresty/benchmark-handler.lua:1-13`). Recorded red checks demonstrate the original process import and fresh-worker contamination; green phase/preload-trap and fresh-worker checks pass (`task-2-phase-red.log`, `task-2-phase-green.log`, `task-2-http-cjson-red.log`, `task-2-http-cjson-green.log`, alongside this artifact). This fixes the harness defect; it does not retroactively establish the requested pure-cjson RSS inequality for the old records.
- **HTTP nondefault decoder index settings are silently ignored** — **ADDRESSED**. An explicit decoder table now carries depth, prefix and budget; the adapter receives it at `opts.decode`, and the direct cold decode/decode_file path receives the same table (`tests/openresty/benchmark-handler.lua:24-29`, `tests/openresty/benchmark-handler.lua:40-41`). Every timed LeanJSON driver response now asserts effective settings and retained-byte budget against the request (`tests/openresty/benchmark.lua:52-58`). Recorded red output shows defaults replacing requested zero settings; green normal/cold file-input probes show effective 0/0/0 and 1/1/64, and the real memory-input driver passes both configurations with its full output oracle (`task-2-http-options-red.log`, `task-2-http-options-green.log`, `task-2-driver-green.log`, alongside this artifact).

### New Breakage in the Fix Diff

- **None found.** The fix preserves cjson reporting/output and keeps adapter I/O/reader options at their supported level while forwarding the decoder-specific table. The real driver evidence covers the resulting request/output path (`tests/openresty/benchmark-handler.lua:24-41`, `tests/openresty/benchmark.lua:48-58`, `task-2-driver-green.log`).

### Out-of-Scope Observations

- The previously recorded packaged-image provenance minor remains deferred to final review (`scripts/verify-memory.py:79-89`, `scripts/verify-memory.py:99-104`); this fix does not touch that code.
- Corrected strict 32,768-entry process/HTTP acceptance, resource checks, whole-branch review and exact committed image verification remain controller-owned integration gates. This re-review does not verify RSS ordering or the final runtime; the appended round-1 report explicitly distinguishes its focused import/settings/output checks from memory acceptance.

### Checks Reviewed

- Read the appended round-1 report and the supplied `d4ea91c..8e07a36` diff once. Inspected only the three-file fix for new breakage; no unchanged runtime/source/helper files were read for this round.
- Inspected all eight named red/green/lint receipts without rerunning their commands. Red failures correspond to both original defects. Green phase logs cover cjson plus LeanJSON zero/tiny settings; HTTP logs cover uncontaminated cjson normal/cold requests and all four LeanJSON normal/cold setting combinations. The three real-driver output oracle flags pass. `task-2-lint.log` records zero warnings/errors in the three changed Lua files.
- No git commands, suites, builds, benchmarks, source changes or measurement reruns were performed. Incidental metrics in focused probe logs were not used as acceptance evidence.

### Verdict

**Fix round:** All findings addressed, no new Critical/Important breakage.

**Spec compliance for this fix round:** Pass. **Task quality for this fix round:** Approved. Full corrected acceptance and final integration remain unverified.
