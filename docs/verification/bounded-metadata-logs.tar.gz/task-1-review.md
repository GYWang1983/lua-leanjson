### Spec Compliance

- ❌ Issues found: the sparse object iterator breaks the required existing live-child/canonical-identity semantics for unique and final object occurrences (`lua/leanjson/proxy.lua:329`), and `ipairs` now exposes object members instead of preserving its previous empty result for objects (`lua/leanjson/proxy.lua:337`).
- ✅ The diff implements the specified 3/3/1048576 defaults and zero settings, bounded native indexing independent of eager validation, stable span handles, shared source adapters, sparse durable edits, streamed duplicate normalization, diagnostic accounting, additive ABI declarations/loader checks, and packaging. Evidence: `lua/leanjson/options.lua:26`, `lua/leanjson/source_backend.lua:29`, `src/source/sparse.rs:11`, `src/source_ffi/sparse.rs:8`, `tests/source_sparse.rs:45`, `rockspec/lua-leanjson-scm-1.rockspec:36`.
- ⚠️ Cannot verify from this diff: the unchanged OpenResty option-forwarding implementation and the supervisor-owned paired memory/HTTP acceptance evidence. The controller should use its existing canonical/paired receipts; this task gate does not grade the benchmark harness. The implementer reports the final canonical gate, locked fuzz compilation, and installed-package smoke all exited 0; no suites were rerun.

### Strengths

- `src/source/sparse.rs:11`, `tests/source_sparse.rs:85`: iteration state uses immutable spans and falls back to scans after index removal; the native test holds an iterator and span across clearing indexes and releasing the original owner.
- `src/source/duplicates.rs:220`, `tests/lua/bounded_metadata_spec.lua:125`: spill lookup compares the complete decoded key after matching fingerprints, preserves the first slot and final whole value, and has escaped-duplicate/one-byte-feed coverage.
- `src/source/duplicates.rs:42`, `tests/lua/bounded_metadata_spec.lua:148`: temporary regions are coalesced/reused with bounded relocation buffers, with a held-reader regression covering historical workspace growth.
- `lua/leanjson/source_backend.lua:70`, `tests/lua/source_shutdown_spec.lua:6`: native operations have one idempotent cleanup owner, with subprocess coverage for unfinished operations, collection, explicit closure, and constrained file descriptors.
- `docs/source-proxy-api.md:7`: the accounting boundary is stated honestly and distinguishes the native metadata budget from total memory and active duplicate workspace.

### Issues

#### Critical (Must Fix)

- None found in this task-scoped review.

#### Important (Should Fix)

- `lua/leanjson/proxy.lua:329`: `iterate` passes `not array` as the `lexical` argument for **every object occurrence**. `child_cell` consequently bypasses the canonical `parent.children[key]` entry even for a unique key. Previously only an occurrence that differed from the current logical member was lexical. Reproduction on the existing pinned native build: decode `{"a":{"x":1}}` with zero index budget; retain `held = body.a`; obtain `via_pairs` from `json.pairs(body)`. Observed `held == via_pairs` is false; after `held.x = 2`, `via_pairs.x` remains 1; after `via_pairs.x = 3`, `body.a.x` remains 2. This loses linked edits and violates the required preserved live-child semantics. Determine whether a container occurrence is the current logical member using targeted lookup/span identity, attach unique/final occurrences canonically, and preserve the earlier-duplicate lexical behavior. Add a regression covering unique keys and final escaped-equivalent duplicate occurrences without restoring an eager sibling cache.

#### Minor (Nice to Have)

- `lua/leanjson/proxy.lua:337`: `M.ipairs` now unconditionally calls the generic member iterator for any proxy. For `json.decode('{"a":1}')`, its first result is consequently the string key `"a"` and value 1; the previous numeric lookup loop returned nil immediately. Preserve the prior object behavior (or validate array kind explicitly if intentionally changing the API) and cover this iterator dispatch case.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The bounded source/duplicate infrastructure is coherent and the added tests cover meaningful capacity, ownership, ABI, and shutdown cases. The object iteration rewrite nonetheless introduces a confirmed public behavior regression that the broad reported gates did not exercise.

- Check run: one focused LuaJIT assertion script using `lua-qjson-dev:task3-repro`, the checkout and `leanjson-bounded-target` mounted read-only, and `LD_LIBRARY_PATH=/workspace/target/release`. After controller confirmation that memory measurements were idle, it failed with `pairs child lost canonical live link`; output was `canonical=false`, then `root=2 pairs_child=1`, then `root=2 pairs_child=3`.
- Review scope: runtime/ABI/tests/API-doc hunks were read once in sequential passes; supervisor-owned benchmark/harness hunks were excluded from the task gate. The first large tool result truncated the header/Lua-export portion, so diff lines 252–356 alone were recovered; no changed source file was read separately, no outside-diff code was inspected, no Git command was run, and only this requested review artifact was written.
