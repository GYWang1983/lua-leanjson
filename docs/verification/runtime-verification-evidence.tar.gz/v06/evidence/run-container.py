#!/usr/bin/env python3
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
args = sys.argv[1:]
label = args.pop(0)
runtime = '/usr/bin/luajit'
extra = []
target = root / 'target'
source = Path('/Users/wanggy/Projects/lua-qjson')
if args and args[0] == '--rolling':
    args.pop(0)
    runtime = '/usr/local/openresty/luajit/bin/luajit'
if args and args[0] == '--debug':
    args.pop(0)
    extra += ['--mount', 'type=bind,source=' + str(root / 'runtime/luajit.debug') + ',target=/usr/lib/debug/.build-id/c5/32105f1b77eb8e57e777c684b290e7b54c5ede.debug,readonly']
if args and args[0] == '--target':
    args.pop(0)
    target = root / args.pop(0)
    target.mkdir(parents=True, exist_ok=True)
if args and args[0] == '--frozen':
    args.pop(0)
    source = root / args.pop(0)
    target = None
command = ['docker', 'run', '--rm', '--name', 'lq-v06-' + label, '--platform', 'linux/arm64',
           '--mount', 'type=bind,source=' + str(source) + ',target=/workspace,readonly',
           '--mount', 'type=bind,source=' + str(root) + ',target=/evidence',
           *(['--mount', 'type=bind,source=' + str(target) + ',target=/workspace/target'] if target else []),
           '-w', '/workspace', '-e', 'LUA_INIT=if jit then jit.off() end', '-e', 'LUAJIT_BIN=' + runtime,
           '-e', 'LD_LIBRARY_PATH=/workspace/target/release',
           '-e', 'LUA_PATH=/workspace/lua/?.lua;/usr/local/openresty/lualib/?.lua;/usr/local/openresty/lualib/?/init.lua;/usr/local/openresty/luajit/share/lua/5.1/?.lua;/usr/local/openresty/luajit/share/lua/5.1/?/init.lua;;',
           '-e', 'LUA_CPATH=/usr/local/openresty/lualib/?.so;/usr/local/openresty/luajit/lib/lua/5.1/?.so;;',
           *extra, 'lua-qjson-v06:restored-20261103', *args]
sys.exit(subprocess.call([sys.executable, str(root / 'capture.py'), label, *command]))
