from pathlib import Path
import importlib.util, json, subprocess
root=Path.cwd(); out=root/'.superpowers/sdd/2026-11-02-cjson-f07-f17'
spec=importlib.util.spec_from_file_location('r',root/'scripts/verify-cjson-compat.py'); r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
fixtures=['',' ','{','[','[1','{"a"','{"a":','{"a":1','[1,','{"a":1,','[1 2]','{"a" 1}','{"a":1 "b":2}','true,','true false','[true,]','{"a":true,}','[False]','nul','tru','trux','nulx','-','+','-.','-x','[ 0.4eg10 ]','[1e+]','[1e-]','01x','0xG','0X1','nanx','NaN(','NaN(x','Infinityx','"abc','"abc\\','"\\q"','"\\u0f6 "','"\\uD800"','"\\uDC00"','"\\uD800x"','"\\uD800\\u0000"','"\\uD800\\q"','{"\\q":0}','{"\\uD800":0}','{"a":"\\uD800"}','["\\q"]','\0"\0"','"\0"\0','true\0x','[1\0]','//a','/*x*/true','{"a"/*x*/:0}','[1//x\n]']
for base in ['{"a":[true,false,null,12.5e-2,"x\\u0061"],"b":{"k":0}}','["x",{"a":1},false]']:
 for pos in range(len(base)):
  fixtures.append(base[:pos]+base[pos+1:])
  for char in [',',':','}','[','"','x','\\']:
   fixtures.append(base[:pos]+char+base[pos:])
fixtures=list(dict.fromkeys(fixtures))
(out/'parent-fixtures.json').write_text(json.dumps(fixtures,ensure_ascii=True))
code=r'''local ffi = require 'ffi'
local root, nativefile = ...
local native = assert(package.loadlib(nativefile,'luaopen_cjson'))()
package.loaded.cjson=nil;package.preload.cjson=function() error('native cjson denied',0) end
package.path=root..'/lua/?.lua;'..package.path
local lean = require 'leanjson'
local fixtures = FIXTURES
local total,both,different,policy=0,0,0,0
local rows={}
for i,input in ipairs(fixtures) do
 local a,b=pcall(native.decode,input)
 if not a then
  total=total+1
  local x,y=pcall(lean.decode,input,{index_depth=0,index_array_limit=0,index_budget_bytes=0})
  if x then
   lean.close(y)
   different=different+1;rows[#rows+1]={id=i,input=input,native=b,target='ACCEPTED'}
  else
   both=both+1
   if b~=y then different=different+1;rows[#rows+1]={id=i,input=input,native=b,target=tostring(y)} end
  end
 else
  local x,y=pcall(lean.decode,input)
  if x then lean.close(y) else policy=policy+1; rows[#rows+1]={id=i,input=input,native='ACCEPTED',target=tostring(y),policy=true} end
 end
end
print(native.encode({fixtures=#fixtures,native_rejected=total,both_rejected=both,differences=different,native_accepted_target_rejected=policy,rows=rows}))
'''.replace('FIXTURES',r.lua_literal(fixtures))
(out/'parent-differential.lua').write_text(code)
cmd=['docker','run','--rm','-v',str(root)+':/workspace','-v','leanjson-bounded-target:/workspace/target','-w','/workspace','-e','LD_LIBRARY_PATH=/workspace/target/release',r.IMAGE,'/usr/local/openresty/luajit/bin/luajit',r'/workspace/'+str((out/'parent-differential.lua').relative_to(root)),'/workspace',r'/workspace/'+str((out/'oracle/native-reference.so').relative_to(root))]
p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(out/'parent-differential-red.json').write_bytes(p.stdout)
print('exit',p.returncode)
try:
 d=json.loads(p.stdout);print({k:v for k,v in d.items() if k!='rows'})
except ValueError:print(p.stdout.decode()[-3000:])
