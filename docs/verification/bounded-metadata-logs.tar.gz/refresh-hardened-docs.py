from pathlib import Path
import json, re, shutil
b=Path('.superpowers/sdd/2026-11-02-bounded-metadata')
names=['default','forks','zero','tiny']
groups={name:[json.loads(line) for line in (b/f'matrix-hardened-{name}'/'results.jsonl').read_text().splitlines()] for name in names}
for name, rows in groups.items():
    summary=json.loads((b/f'matrix-hardened-{name}'/'summary.json').read_text())
    assert summary['passed'] and summary['pairs']=={'default':33,'forks':9,'zero':12,'tiny':9}[name]
    for i in range(1,len(rows),2):
        c,l=rows[i:i+2]
        assert (c['method'],l['method'])==('cjson','leanjson')
        assert c['oracle_passed'] and l['oracle_passed']
        assert c['input_sha256']==l['input_sha256']
        assert l['worker_hwm_kib']<=c['worker_hwm_kib']
env=groups['default'][0]
assert all(rows[0]['runtime']==env['runtime'] for rows in groups.values())
def pair(case,source,group='default'):
    return [next(r for r in groups[group] if r.get('case')==case and r.get('source')==source and r.get('method')==m) for m in ('cjson','leanjson')]
labels={'short-elements':'32,768 short array objects','wide-objects':'32,768 small-object fields','wide-scalars':'32,768 scalar fields'}
table='| Shape | Source | cjson RSS | LeanJSON RSS | cjson CPU | LeanJSON CPU |\n| --- | --- | ---: | ---: | ---: | ---: |\n'
for case,label in labels.items():
    for source in ('memory','file','feed'):
        c,l=pair(case,source)
        table+=f"| {label} | {source} | {c['worker_hwm_kib']/1024:.2f} MiB | {l['worker_hwm_kib']/1024:.2f} MiB | {c['elapsed_cpu_s']*1000:.1f} ms | {l['elapsed_cpu_s']*1000:.1f} ms |\n"
http=[json.loads(s) for s in (b/'http-benchmark-hardened.jsonl').read_text().splitlines()]
assert len(http)==4 and all(r['oracle']['passed'] for r in http)
httptable='| Shape | cjson RSS | LeanJSON RSS | cjson p50 | LeanJSON p50 |\n| --- | ---: | ---: | ---: | ---: |\n'
for case in ('short-elements','wide-objects'):
    c,l=[next(r for r in http if r['scenario']==case and r['method']==m) for m in ('cjson','leanjson')]
    assert c['payload_sha256']==l['payload_sha256']
    httptable+=f"| {labels[case]} | {c['worker_hwm_kib']/1024:.2f} MiB | {l['worker_hwm_kib']/1024:.2f} MiB | {c['p50_ms']:.0f} ms | {l['p50_ms']:.0f} ms |\n"
cw,lw=[next(r for r in http if r['scenario']=='wide-objects' and r['method']==m) for m in ('cjson','leanjson')]
fc,fl=zip(*(pair(case,'file','forks') for case in labels))
forktext=f"""The final completed-file/two-fork results are {fl[0]['worker_hwm_kib']/1024:.2f} MiB (array objects),
{fl[1]['worker_hwm_kib']/1024:.2f} MiB (wide objects), and {fl[2]['worker_hwm_kib']/1024:.2f} MiB (wide scalars), versus paired pure
cjson {fc[0]['worker_hwm_kib']/1024:.2f}, {fc[1]['worker_hwm_kib']/1024:.2f}, and {fc[2]['worker_hwm_kib']/1024:.2f} MiB respectively. The historical table above
used two forks and the old import policy; do not attribute differences caused
by branch count or corrected imports solely to runtime optimization.

"""
p=Path('docs/verification/bounded-metadata.md'); s=p.read_text()
s=s.replace('The final harness is commit `8e07a36`; its runtime is `d4ea91c`.', f"The final harness and runtime are commit `{env['checkout_revision']}`.")
s=s.replace('d4ea91c5dc28c8f8c6af922b50772956fede8f0a',env['checkout_revision'])
s=s.replace('c21c9712521496f1952abf30ca14ce24400ae5a7752499052db79d1b370b43a2',env['runtime']['native_sha256'])
s=s.replace('9472b8880f4d4949010ec210bf8962008539819a3b18d29d805efbcfd5390db3',env['runtime']['lua_sha256'])
s=s.replace('The runtime-only revision is stated above; the checkout revision in each record\nadds the corrected benchmark harness. Dirty status reflects supervisor documentation work.', 'The mounted runtime and harness revision is stated above.\nThe runner resolves the image ID before assembling any Docker command, executes\nthat immutable ID, and fingerprints both native and Lua code in mounted and\npackaged modes. Checkout dirty status is recorded in each environment row.')
start=s.index('| Shape | Source | cjson RSS'); end=s.index('Raw process records:',start)
s=s[:start]+table+'\n'+forktext+s[end:]
start=s.index('| Shape | cjson RSS | LeanJSON RSS | cjson p50'); end=s.index('**Memory improved',start)
s=s[:start]+httptable+'\n'+s[end:]
s=s.replace('roughly 2.7\nmillion write syscalls and 5.6 million read syscalls', f"{lw['io_delta']['syscw']:,}\nwrite syscalls and {lw['io_delta']['syscr']:,} read syscalls")
p.write_text(s)
p=Path('README.md'); s=p.read_text()
start=s.index('| Shape | lua-cjson peak RSS |'); end=s.index('The [bounded-metadata report]',start)
t='| Shape | lua-cjson peak RSS | LeanJSON peak RSS |\n| --- | ---: | ---: |\n'
for case,label in labels.items():
    c,l=pair(case,'file')
    t+=f"| {label} | {c['worker_hwm_kib']/1024:.2f} MiB | {l['worker_hwm_kib']/1024:.2f} MiB |\n"
t+=f"""
**The memory reduction has a CPU/I/O cost.** In the paired local HTTP run with
two concurrent clients, the wide-object case used {lw['worker_hwm_kib']/1024:.2f} MiB versus cjson's
{cw['worker_hwm_kib']/1024:.2f} MiB, but p50 latency was **{lw['p50_ms']:,.0f} ms versus {cw['p50_ms']:.0f} ms**. Wide exact-key
normalization currently uses many synchronous disk operations. This is not a
speed improvement or a production latency guarantee.

"""
p.write_text(s[:start]+t+s[end:])
# Preserve pre-hardening evidence in the final raw-log archive before replacing final summaries.
for name in ('bounded-metadata-final.jsonl','bounded-metadata-final-http.jsonl'):
    dest=b/('pre-hardening-'+name)
    assert not dest.exists()
    shutil.copyfile(Path('docs/verification')/name,dest)
Path('docs/verification/bounded-metadata-final.jsonl').write_text(''.join((b/f'matrix-hardened-{name}'/'results.jsonl').read_text() for name in names))
shutil.copyfile(b/'http-benchmark-hardened.jsonl','docs/verification/bounded-metadata-final-http.jsonl')
print('Refreshed final tables and records from63 passing pairs plus4 HTTP rows; prior records preserved.')
