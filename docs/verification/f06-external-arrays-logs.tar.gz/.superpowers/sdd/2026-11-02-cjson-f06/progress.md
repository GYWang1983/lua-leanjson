# SDD ledger — plan: docs/design/plans/2026-11-02-cjson-f06.md

Base161071f7375b9a4170966031a04e726391b75a1b. Clean existing linked worktree; no CodeGraph, no relevant memory-registry hit. Origin main fetched. User explicitly authorizes F06 and local-main commit; no push.
Ruling: execute the already requested F06 spec without a second design approval — existing requirements and current user instruction authorize implementation; cost if wrong is reversible rework.
Ruling: retain existing linked worktree and prior five unpushed local-main commits — isolate in fix/cjson-external-arrays, do not merge other worktrees.
Ruling: reject nonfinite/out-of-signed32 __len results with a documented error — native C conversion is undefined/nonportable; do not reproduce overflow or huge-loop accidents. Ordinary native finite/coerced semantics remain required.

Preflight:
| Tasks | Interface | Finding |
| --- | --- | --- |
| 1 self | classify, encode, snapshot, origin, callback ownership | one coupled runtime task; source-owned proxies bypass shared classifier |
| 2 self | source/evidence identity, gates, review, local integration | no push; retain strict-matrix/RSS boundary failures |
| 1,2 | runtime paths and docs | sequential handoff, parent owns checklist/report; no concurrent runtime edits |

Task1 pending dispatch; Task2 pending gates/review/integration.

Task1 dispatched external_arrays_impl (gpt-6.1-sol/max); baseline607 green. Full feature RED80 then ownership RED and actual unreachable-holder RED captured. Runtime limited classifier/origin plus snapshot capture and callers, no leases.lua/native edits.
Parent gates: Rust444/444/445, Clippy clean, controls11pass. Harness output contained in this plan; only2 new shared scratch dirs moved,32 prior sibling dirs preserved. Independent pinned168 output/callback-trace cases green. Runtime handoff stable with focused94pass; full Lua/lint/report in progress. Parent full runtime gates started.

Task1 delivered final report. Focused94; full Lua first700pass/1heapthresholdfail(513.1279KiB vs<512), unchanged-source recheck701pass and focused metadata10pass, lint85 clean. No threshold or code change in response; failure explicitly retained.
Parent full gates:168 exact native output/trace matches; HTTP60; matrix TEST23 passes all9cells with0old-pass regressions; loading18; RSS33/33 this run (not universal/stable memory proof); installed-only smoke pass. All51 runtime/header source hashes and built/installed/matrix native hash match.
Parent named-risk probe: abandoned suspended reader/fork constructors release file descriptors after coroutine GC; source.lua:Backend:retain uses idempotent ffi.gc lease tokens, no additional fallback code required. Artifact parent-abandoned-construction.lua/log.
Task1 implementation complete pending independent spec/quality review; package includes all9 text deliverables. Task2 gates complete; docs explicitly preserve first-run heap failure and remaining F05/F15/F16 boundaries.

Review P2 confirmed: reader.lua constructor formats callback error before releasing captured pins; throwing __tostring causes constructor throw and1lease/FD retained until GC. Reviewer reproducible file/control logs retained. Task1 fix round1/5 started; original implementer resumed, no commit yet.
Ruling: retain the reader nil/string-error contract even if user error formatting throws — protect formatting with a stable fallback and release owned resources before calling user formatting. Normal/safe encode error-object identity remains unchanged. Cost if wrong: fallback text differs for pathological error objects; avoids secondary errors bypassing cleanup.

Initial independent review: request changes, sole P2 premature error stringification/lease cleanup. All other checks approved; no suppressed heap observation. Round0 source-matched parent results moved to round0-gates/ to retain original source/provenance/logs while rerunning source-affected gates after fix. Rust/native/Clippy/control gates unchanged and reused. Rocktree remains same install location for explicit reinstall; previous installed smoke log archived.

Task1 fix round1: implementation ready. Original report appended with RED95pass/12fail, affected179pass, finalfull714pass, lint85clean, sourcehash reader71c842f1. Parent exact reviewer-reproducer now reader normal/unprintable both return nil/string without throwing and0lease/closedfd beforeGC; fork retains original error-object identity. Core classifier/proxy unchanged. Final source-affected parent gates rerunning; previous results under round0-gates/ retained. Scoped review package fix-round1.patch includes only amended reader/test + fallback documentation excerpts.

Task1 fix round1/5:1addressed,0open. Reviewer scoped report P2 ADDRESSED, spec/quality approved; no new fix-diff findings. Final full714, affected179, lint85clean. Parent affected gates all current source:168 native match,HTTP60,matrix TEST23all9pass0regression,loading18,RSS33/33,installed-only smoke. Native/source/installedLua hashes verified,51 source/header files match final matrix.
Final integration assessment pending; archive not yet sealed. No parked code findings. Original metadata heap first-run failure remains archived and explicit; no claimed memory cause/fix or universal RSS bound.

Task1 complete (base161071f, fix round1/5 P2addressed0open; independent spec/quality re-review PASS).
Task2 final integration review PASS; all final source/installed receipts coherent. All required task verification complete with explicit old heap threshold and remaining global compatibility boundaries. No deferred code findings, no push requested.
Parent final steps: add archive to explicit10-file manifest, seal and verify all evidence/source snapshots, stage exact manifest, commit then fast-forward local main. Retain original linked worktree and prior local-main commits. Clean only this task workspace after committed archive verification.
