from pathlib import Path
import hashlib,json,tarfile,shutil
w=Path('.superpowers/sdd/2026-11-02-cjson-f13-f14')
manifest=(w/'manifest.txt').read_text().splitlines()
source={}
for name in manifest:
 p=Path(name)
 if p.suffix=='.gz':continue
 dest=w/'source-snapshot'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 source[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(w/'source-final.json').write_text(json.dumps(source,indent=2)+'\n')
files=[]
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 relative=p.relative_to(w)
 if relative.parts[0] in ('rocktree','parent-reference') or '__pycache__' in relative.parts or p.name=='SHA256SUMS':continue
 files.append(p)
(w/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p)+'\n' for p in files))
files.append(w/'SHA256SUMS')
archive=Path('docs/verification/f13-f14-encoding-logs.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p),recursive=False)
with tarfile.open(archive) as t:
 for line in t.extractfile(str(w/'SHA256SUMS')).read().decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==digest,name
 for name,digest in source.items():assert hashlib.sha256(t.extractfile(str(w/'source-snapshot'/name)).read()).hexdigest()==digest,name
print('Sealed',len(files),'files;',archive.stat().st_size,'bytes; all member/source hashes verified')
