# Sealed primary-evidence archive audit

Scope: read-only inspection of
`docs/verification/full-verification-primary-evidence.tar.gz`. No tests,
builds, benchmarks, Docker commands, or workflows were started.

## Archive integrity and cleanup

- Outer archive size is `17,642,272` bytes and SHA-256 is
  `77aea26436ad83fec617436a88ef0a3782d9b8678fe97e4c962d9ba09d028c29`.
- The tar has 2,571 unique regular-file members, with no directories,
  symlinks, hardlinks, duplicate names, absolute paths, or `..` path
  components. One member is `SHA256SUMS`; the other 2,570 are covered by it.
- Extracting to a temporary directory and running `shasum -a 256 -c
  SHA256SUMS` returned exit 0 with 2,570/2,570 `OK` lines. `SHA256SUMS`
  itself is intentionally not self-listed.
- No `docs/verification/` paths, old report bodies, or old report archives
  are present in the tar. `old-verification-manifest.json` is intentional
  deletion metadata only: 37 historical paths totaling 217,076,807 bytes;
  none of those files' contents are archived.

## Raw cjson matrix coverage

Both `primary/cjson-table` and `primary/cjson-userdata` inventories are
schema 1 for upstream commit `617164a0fe3bb647128178f9caefb304b8573bb6`.
Each has 164 unique case IDs, 161 assertion records (160 applicable plus one
environment-inapplicable), three helpers, and four excluded source files.

The raw `records.jsonl` files, rather than summaries, were compared with each
inventory:

- Each native baseline has 164 raw case records with exactly the inventory ID
  set and classifications 160 `pass`, 3 `setup_success`, and 1
  `environment_inapplicable`.
- Each carrier has all nine matrix cells. Every cell has 164 raw case lines,
  164 unique IDs, no missing IDs, no extra IDs, and no duplicates. The ID set
  exactly matches the inventory in all 18 cells.
- Table: each eager cell is 159 pass / 1 behavioral difference / 3 setup / 1
  environment-inapplicable; each lazy/preload cell is 156 / 4 / 3 / 1.
- Userdata: each eager cell is 159 / 1 / 3 / 1; each lazy/preload cell is
  130 / 30 / 3 / 1.

The worker aggregation order differs from inventory order (decode-cycle IDs
precede `agentzh.t` IDs in raw cell files), but membership is exact. No raw
record is missing because of this ordering.

## Referenced artifacts and receipts

- All primary JSON/JSONL evidence parsed without errors. Contract-defined
  `artifact` references total 3,985 occurrences across 231 unique `.bin`
  paths. Every referenced file exists; every declared SHA-256, filename hash
  stem, and declared byte length matches.
- Required failure/diagnostic evidence is present (32/32 checked paths),
  including canonical source-corpus failure and receipt, bench-smoke failure,
  strict-corpus log/receipt/script, both initial and retry installed-package
  receipts/logs, cjson table/userdata logs and receipts, HTTP receipt, and
  runtime-image build/verify receipts.
- Canonical receipt records inner exit 2 and
  `source-corpus.lua:33: n_number_+1.json was incorrectly accepted`.
  Bench-smoke records exit 2. Strict corpus records exit 0 and its log records
  95 valid, 188 invalid, and 35 implementation-defined cases. The first
  installed-package attempt records exit 1 before smoke; the retry records
  exit 0. The cjson strict receipts preserve exit 1 as intentional
  compatibility differences; HTTP and runtime-image receipts record exit 0.

## Source-manifest reconciliation

- `source-snapshot/` contains 177 files. The archived
  `parent-runtime-test-source-fingerprints.json` has exactly 177 unique keys;
  its key set equals the snapshot path set, and all 177 recorded hashes match
  the archived snapshot bytes.
- `primary/source-fingerprints.sha256` has 51 runtime-file entries. All 51 are
  present in the 177-file snapshot and all hashes match; the 51 overlapping
  parent-fingerprint values have no conflicts. The manifest's recorded digest,
  recomputed digest, and `primary/provenance.txt`/`summary.json` source-manifest
  SHA are all
  `11f1aab63df8a8a868163d5ffdea9212938e37f57bb829c976b4f77eaafc1ee9`.
- The target `libleanjson.so` path itself is not an archive member, but both
  archived installed-package copies hash to the provenance runtime-library
  SHA `8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b`.

## Limits

This audit verifies archive completeness, raw-record identity membership,
contract-defined blob references, and provenance consistency. It does not
rerun any gate or independently recreate the target build from the archived
source snapshot.
