from pathlib import Path
import json,subprocess,hashlib
root=Path.cwd();p=Path('.superpowers/sdd/2026-11-02-cjson-f10');out=p/'comment-memory';out.mkdir(exist_ok=True)
fixture=out/'input.json'
with fixture.open('wb') as f:
 f.write(b'{"model":"original",/*')
 for _ in range(4096):f.write(b'[]{}"\\\xffx'*512)
 f.write(b'*/"items":[{/* nested */"id":1}],"keep":"literal // /* */"}')
sha=hashlib.sha256(fixture.read_bytes()).hexdigest();rows=[]
for source in ['memory','file','feed']:
 pair={}
 for method in ['cjson','leanjson']:
  name=source+'-'+method;target=out/(name+'-output.json')
  cmd=['docker','run','--rm','-v',str(root)+':/workspace','-v','leanjson-bounded-target:/workspace/target','-w','/workspace','-e','LD_LIBRARY_PATH=/workspace/target/release','lua-qjson-dev:task3-repro','/usr/local/openresty/bin/resty','-I','/workspace/lua','-I','/workspace/tests/openresty','/workspace/'+str(p/'comment-memory-worker.lua'),method,source,'/workspace/'+str(fixture),'/workspace/'+str(target),'/workspace/'+str(p/'oracle/native-reference.so')]
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/(name+'.log')).write_bytes(r.stdout);assert r.returncode==0,r.stdout[-2000:]
  row=json.loads(r.stdout);value=json.loads(target.read_text());assert value=={'model':'rewritten','items':[{'id':1}],'keep':'literal // /* */'}
  target.unlink();row['input_sha256']=sha;row['oracle_passed']=True;rows.append(row);pair[method]=row['peak_rss_kib']
 print(source,pair,'ratio',round(pair['leanjson']/pair['cjson'],4),flush=True)
(out/'summary.json').write_text(json.dumps({'input_sha256':sha,'input_bytes':fixture.stat().st_size,'rows':rows},indent=2)+'\n');fixture.unlink()
