from pathlib import Path
import importlib.util,json,subprocess
root=Path.cwd();p=Path('.superpowers/sdd/2026-11-02-cjson-f10')
spec=importlib.util.spec_from_file_location('r',root/'scripts/verify-cjson-compat.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
fixtures=['','//x','//x\r','//x\r\n','/*x*/','/','/*','/*/','/**/','/*x*','/***/true','/*a/*b*/true','/*a*/true/*b*/','[1/*x*/0]','{"a":1/*x*/0}','[tr/*x*/ue]','[fals/*x*/e]','[nu/*x*/ll]','[1e/*x*/2]','[1/*x*/.2]','[1./*x*/2]','[0x/*x*/a]','[Na/*x*/N]','[NaN(/*x*/a)]','{"/*x*/":"// literal /* */"}','"http://example/a/*b*/"//tail','{}/*unclosed','{//line\r}','{//line\r\n}','{/*[]{}\\"*/"a"/*before*/:/*after*/[1/*end*/,2]}','["bad\\q"/*comment*/]','/*a*/{"a" /*b*/ "bad\\q"}','/*\0*/true','1//\0x','[1,//\0x]','/*\xff*/true']
tokens=['{','"a"',':','[','1',',','true',',','null',',','"literal // /* */ \\""',']',',','"b"',':','{','"x"',':','2','}','}']
for i in range(len(tokens)+1):
 for comment in ['/**/','/*x*/','//x\n','//x\r\n','//x\r','/*"[]{}\\*/','/*','/','/*/**/*/','//EOF']:
  fixtures.append(''.join(tokens[:i])+comment+''.join(tokens[i:]))
# Mutate actual comments, making every closure/expectation combination visible.
for base in ['{/*x*/"a":1}','[/*x*/true,/*y*/false]','/*x*/{"a":2}//z\n']:
 for i in range(len(base)):
  fixtures.append(base[:i]+base[i+1:])
  for char in ['/', '*', '\n', '"', ':', 'x']:
   fixtures.append(base[:i]+char+base[i:])
fixtures=list(dict.fromkeys(fixtures));(p/'parent-fixtures.json').write_text(json.dumps(fixtures,ensure_ascii=True))
code=r'''local root,nativefile=...
local native=assert(package.loadlib(nativefile,'luaopen_cjson'))()
package.path=root..'/lua/?.lua;'..package.path
package.loaded.cjson=nil;package.preload.cjson=function() error('native cjson denied',0) end
local json=require 'leanjson'
local fixtures=FIXTURES
local missing=json.decode_allow_comment==nil
if not missing then json.decode_allow_comment(true) end
native.decode_allow_comment(true)
local check=native.new();check.decode_allow_comment(false)
local function equal(a,b)
 if a==native.null then return b==json.null end
 if type(a)~='table' then return a==b or type(a)=='number' and a~=a and b~=b end
 if type(b)~='table' then return false end
 local n,m=0,0
 for k,v in pairs(a) do n=n+1;if not equal(v,b[k]) then return false end end
 for _ in json.pairs(b) do m=m+1 end
 return n==m
end
local rows={};local accepted,rejected,mismatch,policy,output_errors=0,0,0,0,0
for id,input in ipairs(fixtures) do
 local a,expected=pcall(native.decode,input)
 local b,value=pcall(json.decode,input,{index_depth=0,index_array_limit=0,index_budget_bytes=0})
 if a then
  accepted=accepted+1
  if not b then policy=policy+1;rows[#rows+1]={id=id,input=input,native='ACCEPTED',target=value,acceptance=true}
  elseif not equal(expected,value) then mismatch=mismatch+1;rows[#rows+1]={id=id,input=input,native='VALUE',target='DIFFERENT'}
  else
   local ok,out=pcall(json.encode,value)
   if not ok or not pcall(check.decode,out) then output_errors=output_errors+1;rows[#rows+1]={id=id,input=input,native='ENCODABLE',target=tostring(out),output=true} end
  end
 else
  rejected=rejected+1
  if b or value~=expected then mismatch=mismatch+1;rows[#rows+1]={id=id,input=input,native=expected,target=b and 'ACCEPTED' or value} end
 end
 if b then json.close(value) end
end
print(native.encode({missing_api=missing,fixtures=#fixtures,native_accepted=accepted,native_rejected=rejected,message_or_value_differences=mismatch,acceptance_differences=policy,output_errors=output_errors,rows=rows}))
'''.replace('FIXTURES',r.lua_literal(fixtures))
(p/'parent-comments.lua').write_text(code)
cmd=['docker','run','--rm','-v',str(root)+':/workspace','-v','leanjson-bounded-target:/workspace/target','-w','/workspace','-e','LD_LIBRARY_PATH=/workspace/target/release',r.IMAGE,'/usr/local/openresty/luajit/bin/luajit','/workspace/'+str(p/'parent-comments.lua'),'/workspace','/workspace/'+str(p/'oracle/native-reference.so')]
s=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/'parent-comments-red.json').write_bytes(s.stdout);assert s.returncode==0,s.stdout
x=json.loads(s.stdout);print({k:v for k,v in x.items() if k!='rows'})
