# Task 1 report: F13/F14 indentation and unsupported values

## Result

Implemented `encode_indent` and `encode_skip_unsupported_value_types` in the
existing per-codec closures and iterative encoders. The default module, normal
`new()` instances, `leanjson.safe` and safe `new()` instances expose independent
settings. Readers freeze their format/skip policy at construction.

No commit, branch operation, push, subagent, native fallback, Rust change,
upstream expectation change or compatibility-adapter change was made. The
parent-owned plan, ledger and verification report were not edited. Work stayed
in `/Users/wanggy/Projects/lua-qjson/.worktrees/bounded-metadata`.

## Changed deliverable paths

- `lua/leanjson/table.lua`: settings, supported-type predicate, ordinary-table
  punctuation/skip emission, whole-container origin bypass prevention, reader
  policy snapshot, codec export list.
- `lua/leanjson/reader.lua`: raw-container formatting bypass prevention,
  unsupported filtering, matching length formulas, bounded indentation frames,
  lexical duplicate traversal for indented source output.
- `lua/leanjson.lua`: public API exports.
- `tests/lua/cjson_indent_skip_spec.lua`: 24 focused regression cases.
- `README.md`: API examples and compatibility/resource boundaries.
- `docs/source-proxy-api.md`: proxy and reader contracts.

Task-local oracle, logs and this report live under
`.superpowers/sdd/2026-11-02-cjson-f13-f14/`. The untracked
`docs/design/plans/2026-11-02-cjson-f13-f14.md` was already present when this
task began and belongs to the parent.

## Oracle provenance and decisions

Read `vendor/lua-cjson/lua_cjson.c` configuration helpers, array/object emission,
unsupported-type dispatch, upstream `tests/test.lua` indentation cases and
`tests/agentzh.t` TEST 22. The pinned submodule is
`617164a0fe3bb647128178f9caefb304b8573bb6`.

The reproducible independent probe is `task-1-oracle.lua`. Its final version
explicitly invokes
`package.loadlib('/workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/parent-reference/cjson.so', 'luaopen_cjson')()`;
the parent built this reference from the untouched pinned source with its native
Makefile. This avoids silently loading the image's cjson.

| Oracle artifact | SHA-256 |
| --- | --- |
| `vendor/lua-cjson/lua_cjson.c` | `d60ac768f4c367ee57db3151c4099998c4ac59c149bbb092115ae76d221b2c82` |
| `parent-reference/cjson.so` | `fd6fd6158e718fbd3608baefbbb655100b07334840a2e814a4f8054aa7e61cac` |

The final `task-1-oracle.log` contains 324 protected observations, covering
configuration, numeric/non-whitespace/NUL indent, unsupported roots and members,
all-skipped containers, invalid keys and non-null lightuserdata. Two separate
crashing getter probes are preserved as
`task-1-oracle-default-getter.log` and `task-1-oracle-empty-getter.log`.

- Compact indent defaults to the empty string. Nonempty indent inserts LF,
  repeats the exact indent bytes by container depth, and adds one space after an
  object colon. Truly empty containers stay `{}`/`[]`.
- Numeric indent uses Lua's number-to-string conversion, including `nan`/`inf`.
  Non-whitespace indent is accepted. Embedded NUL truncates the setting, getter
  and actual output at its first byte; leading NUL disables indentation.
- The native skip option defaults to false and accepts booleans and on/off,
  including `on\0tail`/`off\0tail`. The new setter preserves that native C-string
  behavior without changing other existing boolean setters.
- Skip omits unsupported roots as `""`, removes unsupported object members and
  compacts arrays. `has_items` tracks visited members independently of emitted
  count: all-skipped nonempty containers still receive the native LF and
  closing indent, unlike truly empty containers.
- Keys are validated before the associated unsupported value can be skipped.
  Null, nil/array holes, supported numbers and numeric cdata are not skipped.
  Sparse classification, nonfinite policy, cycles and depth validation remain
  active and do not mutate inputs.
- Nonempty indent rebuilds every container through iterative traversal,
  including clean raw proxies and complete `keep_origin` containers. Eligible
  source scalar spellings remain original. Indented untouched source objects
  retain lexical duplicates unless reader normalization is requested. The
  existing compact fallback normalization remains unchanged.

### Explicit compatibility boundaries

1. **Pinned native empty/default getter crash.** Calling `encode_indent()` on a
   fresh native codec or after `encode_indent('')` exits 139. Its C code
   dereferences NULL after `json_string_option`. LeanJSON returns `""` safely in
   both cases, including nil-as-getter. This boundary is documented publicly.
2. **Existing numeric-cdata extension.** Pinned native cjson rejects all cdata,
   or skips it when enabled. LeanJSON already encodes `int64_t`/`uint64_t`, and
   this support remains available under either skip setting. Unsupported
   pointer/double cdata still errors or skips normally.
3. **Native arbitrary lightuserdata bug.** A non-null lightuserdata produced by
   `debug.upvalueid` encodes as an empty token under both native skip modes;
   arrays/objects retain punctuation and can become invalid JSON. LeanJSON
   preserves its existing unsupported-type error when skip is disabled and
   omits the value when enabled. Null and the empty-array sentinel remain
   recognized separately.
4. Preloading/eager materialization and origin reuse retain their established
   scalar spelling/shape limits. Indentation does not introduce a general JSON
   canonicalizer or extend external `__len` arrays or proxy mutation semantics.

An initial probe accidentally fell through an absent `vendor/.../cjson.so` to
the image module (observed version 2.1.0.11). Those superseded observations were
kept as `task-1-image-oracle*.log`; they are not the pinned oracle evidence.

## TDD and verification

Before production edits, ran the complete existing Lua suite once:
`task-1-baseline.log`: **583 successes, 0 failures, 0 errors**.

Wrote the complete focused public/behavior spec before production edits. The
clean API RED is `task-1-red.log`: **0 successes, 1 expected failure, 0 errors**
for missing `encode_indent`. After adding setters/exports but before encoder
changes, `task-1-red-behavior.log` captured **1 expected failure, 0 errors**:
the calling codec requested indentation but an unchanged proxy still emitted
its compact raw span.

The first integrated focused run (`task-1-green-attempt.log`) had 23 passes and
one fixture failure: an infinity-only numeric-key table triggered existing
sparse-array validation before the intended invalid-object-key test. Added a
string key to force that fixture down the intended object path; the expected
invalid-number error was retained. No sparse policy was changed.

Self-review identified that lexical traversal could change existing compact
comment-container duplicate normalization. Added an explicit regression first:
`task-1-red-compact-duplicates.log` captured **1 expected failure, 0 errors**.
Restricted lexical traversal to nonempty indentation unless explicit
normalization is requested; compact fallback keeps the prior behavior.

Final results on unchanged runtime and test source:

| Gate | Result | Evidence |
| --- | --- | --- |
| Focused spec | 24 successes / 0 failures / 0 errors | `task-1-green.log` |
| Full Lua suite after final runtime/test edits | 607 successes / 0 failures / 0 errors | `task-1-full-lua.log` |
| `make lua-lint` | 0 warnings / 0 errors, 84 files | `task-1-lua-lint.log` |
| `git diff --check` | exit 0 | final self-review invocation |

The final focused and complete 607-test runs include the compact duplicate
regression and the final read-bound assertions. A transient early Docker read immediately after a host file edit
reported an incomplete Lua file, and the first lint run flagged direct writes
to read-only standard-library fields in test instrumentation. The eventual
complete file syntax check and final suite/lint passed; test instrumentation
now uses the repository's existing `rawset` convention.

### Coverage exercised

- Default module/normal/safe/new isolation, atomic invalid setters, arity,
  numeric indent, arbitrary non-whitespace indent, NUL handling and native
  option values.
- Function/thread/full userdata/pointer-cdata/double-cdata roots, array
  compaction, omitted object members, nested all-skipped objects, empty versus
  all-skipped punctuation, input preservation and existing 64-bit cdata.
- Invalid boolean/sentinel/nonfinite object keys, nonfinite values, sparse
  arrays, cycles and depth limits with skip enabled.
- Memory/file/feed × lazy/eager/preload × ordinary/safe codecs, including clean
  and dirty containers, forks, keep-origin materialization, nested mixed
  table/proxy values and retained source numeric/string spellings.
- Comments, lexical duplicates and explicit duplicate normalization. Calling
  codec policy and frozen reader settings/input snapshots across later edits.
- Reader chunk sizes **1 and 7**, exact length, repeated length and cached length
  after EOF. A 1200-container structure exercises explicit traversal and
  1,444,801 encoded bytes; `string.rep`/`table.concat` instrumentation rejects
  reader temporaries above the seven-byte output bound.
- File and feed payload strings of **196,608 decoded source bytes**, with slash
  escaping, bounded source reads (at most **127** bytes), output chunks at most
  **7** bytes, scalar-materialization traps and exact output length/count.
- GC-stopped file/feed EOF, count failure, suspended length and suspended output
  cancellation. Source descriptors close and lease counts reach zero through
  explicit reader ownership release, without forced GC.

Rust variants, Clippy, HTTP, the complete upstream compatibility matrix,
controls, loading/resource checks, RSS comparison and installed-only smoke are
owned by the parent; this task does not duplicate or claim those results. The
previous RSS limitation remains a separate parent verification boundary.

## Reproduction commands

Run from the assigned worktree. Docker image:
`lua-qjson-dev:task3-repro` (pinned OpenResty 1.29.2.4 / LuaJIT / Rust 1.90).
The native LeanJSON release library was already built in the named target
volume before baseline; this task did not rebuild it.

```sh
# Full Lua suite; substitute tests/lua/cjson_indent_skip_spec.lua for focused.
docker run --rm \
  -v "$PWD:/workspace" \
  -v leanjson-bounded-target:/workspace/target \
  -v qjson-cargo-registry:/usr/local/cargo/registry \
  -w /workspace lua-qjson-dev:task3-repro sh -lc '
    LD_LIBRARY_PATH=/workspace/target/release \
    LUA_PATH="./lua/?.lua;/usr/local/openresty/lualib/?.lua;/usr/local/openresty/lualib/?/init.lua;;" \
    LUA_CPATH="./vendor/lua-cjson/?.so;/usr/local/openresty/lualib/?.so;;" \
    busted --lua=/usr/local/openresty/luajit/bin/luajit tests/lua --lpath="./lua/?.lua"'

docker run --rm -v "$PWD:/workspace" -w /workspace \
  lua-qjson-dev:task3-repro make lua-lint

# The oracle uses explicit package.loadlib of the parent's pinned build.
docker run --rm -v "$PWD:/workspace" -w /workspace \
  lua-qjson-dev:task3-repro /usr/local/openresty/luajit/bin/luajit \
  .superpowers/sdd/2026-11-02-cjson-f13-f14/task-1-oracle.lua

# Isolate known pinned-native getter crashes; each exits 139.
# Append default-getter or empty-getter to the oracle command above.
git diff --check
```

The main suite's existing native comparisons use its usual image cjson module;
the new focused tests use independently hand-checked literal expectations.
Pinned native F13/F14 observations are separated in the explicit-load oracle.

## Final self-review and source identity

Checked the complete runtime/test/document diff against the task brief: no
source whole-materialization path, no cjson encoding fallback, no recursive
indent generation, no broad formatting/refactor, and no swallowed key/number/
sparse/cycle/depth error. Reader length counts formatting arithmetically while
output uses a bounded repeat frame; all-skipped membership and emitted count
are separate in both paths. Existing cancellation scopes and release paths
remain responsible for traversal operations.

Final runtime/test SHA-256 values, also used for parent evidence matching:

| Path | SHA-256 |
| --- | --- |
| `lua/leanjson.lua` | `5b1a48456be8b4176516fb1d637dd3219b436847477b5a41f48f30ef9caa380a` |
| `lua/leanjson/table.lua` | `fe539bdaadcf1cf1fa2fcf4b057f273547c0338cde94417510e06b0784b73a10` |
| `lua/leanjson/reader.lua` | `c3d96ef67163c81459a2d8e3f6bc79a6f0a306c709bf21bb79c80308c3920fef` |
| `tests/lua/cjson_indent_skip_spec.lua` | `9a3520acd50545be61d47b4ba2e1c53de715bd638a851a79226b1ad2ba0f7275` |

No additional unresolved implementation issue was found. The explicit native
bug/extension boundaries above and the parent's broader verification gates
remain visible for independent review.
