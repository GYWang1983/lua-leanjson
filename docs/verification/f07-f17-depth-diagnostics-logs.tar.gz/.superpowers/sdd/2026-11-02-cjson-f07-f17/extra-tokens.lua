local root,nativefile=...
local n=assert(package.loadlib(nativefile,'luaopen_cjson'))()
package.path=root..'/lua/?.lua;'..package.path
package.preload.cjson=function() error('denied',0) end
local j=require 'leanjson'
for _,v in ipairs({'-Inf','+Inf','-NaN','+NaN','-Infinity','+Infinity'}) do
 for _,s in ipairs({'true '..v,'{"a" '..v..'}','[1 '..v..']'}) do
  local _,a=pcall(n.decode,s); local _,b=pcall(j.decode,s)
  if a~=b then print(n.encode({input=s,native=a,target=b})) end
 end
end
