local prefix=arg[1]
package.path=prefix..'/share/lua/5.1/?.lua;'
package.cpath=prefix..'/lib/lua/5.1/?.so;'
package.preload.cjson=function() error('native cjson denied',0) end
local json=require 'leanjson'
assert(json.encode_indent()=='')
assert(json.encode_skip_unsupported_value_types()==false)
local c=json.new();c.encode_indent('  ');c.encode_skip_unsupported_value_types(true)
local f=function() end
assert(c.encode(f)=='')
assert(c.encode({1,f,2})=='[\n  1,\n  2\n]')
local value=c.decode('{"x":1}',{index_depth=0,index_budget_bytes=0});value.hidden=f
local expected='{\n  "x": 1\n}'
assert(c.encode(value)==expected)
local r=c.reader(value,{chunk_size=1})
c.encode_indent('abc');c.encode_skip_unsupported_value_types(false)
assert(r:length()==#expected)
local parts={}
while true do local s,e=r:next();assert(not e,e);if s==nil then break end;assert(#s<=1);parts[#parts+1]=s end
assert(table.concat(parts)==expected);c.close(value)
local s=require('leanjson.safe').new();s.encode_skip_unsupported_value_types(true);assert(s.encode(f)=='')
assert(s.new().encode_skip_unsupported_value_types()==false)
local maps=assert(io.open('/proc/self/maps'));local text=maps:read('*a');maps:close()
assert(text:find(prefix..'/lib/lua/5.1/leanjson.so',1,true))
assert(not text:find('/workspace/target/release/libleanjson.so',1,true))
print('installed-only F13/F14 smoke passed; source-tree/native-cjson fallbacks denied; native map verified')
