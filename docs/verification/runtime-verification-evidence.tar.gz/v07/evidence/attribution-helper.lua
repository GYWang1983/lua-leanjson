io.stdout:write('attribution jit=', jit.version, ' arch=', jit.arch, '\n')
io.stdout:write('attribution package.cpath=', package.cpath, '\n')
local native = require('cjson')
io.stdout:write('attribution cjson=', native._VERSION, ' decode_allow_comment=', type(native.decode_allow_comment), '\n')
local maps = assert(io.open('/proc/self/maps', 'r'))
for line in maps:lines() do
    if line:find('cjson.so', 1, true) or line:find('/luajit', 1, true) then io.stdout:write('attribution map ',line,'\n') end
end
maps:close()
