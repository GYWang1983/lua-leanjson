### Task 1: Implement the complete comment policy with RED/GREEN regression coverage

Files: src/source.rs and comment/token helper as needed, src/source/diagnostic.rs, source_ffi/sparse.rs, source policy users/window/walkers/loading, include/leanjson.h, lua/leanjson/table.lua/options.lua/source_backend.lua/reader.lua/lib.lua and public export list; focused Rust and Lua tests. Reuse existing modules; minimal helper extraction only when useful.

- [ ] Read pinned native comment configuration/tokenization and F10 cases337–359. Reproduce missing API/acceptance with RED logs before implementing.
- [ ] Add actual policy and incremental scanner/diagnostic behavior across initial and resumed paths, preserving offsets and internal diagnostics.
- [ ] Use source flags/iterator output to remove comments with bounded memory; cover affected empty containers, nested unaffected spans, modified proxies, duplicate normalization and keep_origin, encode limits and reader cancellation.
- [ ] Test ordinary/safe/new isolation and getter/errors; nine lazy/eager/preload × memory/file/feed combinations including selected/unselected fields, changes after decoder creation, zero indexes, cross-codec output and repeated finish/get. Cover all split points, CR/CRLF, leading/trailing/adjacent comments, malformed comments, invalid lexical tokens touching comments, and strings containing comment-looking text.
- [ ] Add a large-comment bounded-read/output regression (no comment payload materialization or output); run focused Rust/Lua and full Lua/lint. Report files/RED/GREEN/decisions/limitations in assigned workspace, no commit.

