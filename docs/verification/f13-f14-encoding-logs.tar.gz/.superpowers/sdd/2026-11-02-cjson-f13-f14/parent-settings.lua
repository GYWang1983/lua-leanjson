local native=assert(package.loadlib('/workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/parent-reference/cjson.so','luaopen_cjson'))()
local target=require 'leanjson'
local inputs={'',' ', 'abc','x\0y','\0y','on','off','on\0suffix','off\0suffix','other\0x',true,false,0,1,1.25,math.huge,-math.huge,0/0,{},function() end,coroutine.create(function() end),newproxy(true)}
local count,bad=0,0
for _,name in ipairs({'encode_indent','encode_skip_unsupported_value_types'}) do for _,v in ipairs(inputs) do
 local n=native.new();local j=target.new();if name=='encode_indent' then n[name]('x');j[name]('x') end
 local a,b=pcall(n[name],v);local c,d=pcall(j[name],v)
 count=count+1
 if a~=c or b~=d then bad=bad+1;print('MISMATCH',name,type(v),tostring(v),a,tostring(b),c,tostring(d)) end
end end
print('SETTINGS_CHECKS',count,'MISMATCHES',bad);assert(bad==0)
