#!/usr/bin/env python3
import datetime, hashlib, json, os, pathlib, platform, re, subprocess, sys, time
ROOT=pathlib.Path('/root/leanjson-v05-20261103-native-171329z')
E=ROOT/'evidence'; E.mkdir(exist_ok=True)
TC='nightly-2026-10-30'
env=os.environ.copy()
env.update(RUSTUP_HOME=str(ROOT/'rustup'), CARGO_HOME=str(ROOT/'cargo'), CARGO_TARGET_DIR=str(ROOT/'target'), RUSTUP_DIST_SERVER='https://rsproxy.cn', RUSTUP_UPDATE_ROOT='https://static.rust-lang.org/rustup', RUSTUP_INIT_SKIP_PATH_CHECK='yes', CARGO_BUILD_JOBS='4')
env['PATH']=str(ROOT/'cargo/bin')+os.pathsep+env['PATH']
commands=[]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,argv,timeout=120,cwd=None,extra=None):
    runenv=env.copy();runenv.update(extra or {})
    started=now(); print(f'{started} START {name}: '+ ' '.join(argv),flush=True)
    t=time.monotonic()
    with (E/(name+'.stdout')).open('wb') as out,(E/(name+'.stderr')).open('wb') as err:
        try:
            p=subprocess.run(argv,cwd=cwd or ROOT,env=runenv,stdout=out,stderr=err,timeout=timeout)
            rc=p.returncode; timedout=False
        except subprocess.TimeoutExpired:
            rc=124;timedout=True
        except Exception as exc:
            err.write((repr(exc)+'\n').encode());rc=125;timedout=False
    info={'name':name,'argv':argv,'cwd':str(cwd or ROOT),'environment':{k:runenv[k] for k in ['RUSTUP_HOME','CARGO_HOME','CARGO_TARGET_DIR','RUSTUP_DIST_SERVER','RUSTUP_UPDATE_ROOT','CARGO_BUILD_JOBS']},'additional_environment':extra or {},'started_at_utc':started,'finished_at_utc':now(),'duration_seconds':round(time.monotonic()-t,3),'exit_code':rc,'timed_out':timedout,'stdout':name+'.stdout','stderr':name+'.stderr'}
    (E/(name+'.json')).write_text(json.dumps(info,indent=2)+'\n');commands.append(info)
    (E/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(f'{now()} END {name}: exit={rc}',flush=True)
    for f in ['stdout','stderr']:
        lines=(E/(name+'.'+f)).read_text(errors='replace').splitlines()
        if lines: print('\n'.join(lines[-12:]),flush=True)
    return info

def required(name,argv,**kw):
    result=run(name,argv,**kw)
    if result['exit_code']:
        (E/'setup-failure.json').write_text(json.dumps(result,indent=2)+'\n');sys.exit(2)
    return result

required('source-archive-check',['sha256sum','-c','source.tar.gz.sha256'])
required('source-extract',['tar','-xzf','source.tar.gz','-C',str(ROOT/'source')])
required('source-pre-check',['sha256sum','-c','SOURCE_SHA256SUMS'],cwd=ROOT/'source')
(ROOT/'source').chmod(0o555)
required('host-os',['sh','-c','uname -srm; cat /etc/os-release; getconf LONG_BIT; nproc; ldd --version; gcc --version; df -h .'])
required('host-cpu',['lscpu'])
required('installer-check',['sh','-c','printf "%s  rustup-init\\n" "$(cut -d " " -f1 rustup-init.sha256)" | sha256sum -c -'],cwd=ROOT/'downloads')
required('mirror-manifest-check',['sh','-c','cmp downloads/channel-rust-nightly-2026-10-30.toml downloads/channel-rust-nightly-2026-10-30.rsproxy.toml'])
required('manifest-check',['sh','-c','printf "%s  channel-rust-nightly-2026-10-30.toml\\n" "$(cut -d " " -f1 channel-rust-nightly-2026-10-30.toml.sha256)" | sha256sum -c -'],cwd=ROOT/'downloads')
(ROOT/'downloads/rustup-init').chmod(0o700)
required('rustup-install',[str(ROOT/'downloads/rustup-init'),'-y','--no-modify-path','--profile','minimal','--default-toolchain','none'],timeout=180)
required('toolchain-install',['rustup','toolchain','install',TC,'--profile','minimal'],timeout=1500)
required('rustup-version',['rustup','--version'])
required('toolchain-version',['rustc','+'+TC,'-vV'])
required('cargo-version',['cargo','+'+TC,'-V'])
required('toolchain-components',['rustup','component','list','--installed','--toolchain',TC])
required('toolchain-download-hashes',['sh','-c','find downloads -maxdepth 1 -type f ! -name "*.stderr" -exec sha256sum {} +'])
manifest=(ROOT/'downloads/channel-rust-nightly-2026-10-30.toml').read_text()
sections={}
for name in ['rustc','rust-std','cargo']:
    heading=f'[pkg.{name}.target.x86_64-unknown-linux-gnu]'
    start=manifest.index(heading); end=manifest.find('\n[',start+len(heading))
    sections[name]=manifest[start:end if end>=0 else None]
(E/'official-component-manifest.txt').write_text('\n\n'.join(sections.values())+'\n')
ver=(E/'toolchain-version.stdout').read_text()
if '92b5b8c87c61b20adc9001b41baf587634a74734' not in ver:
    (E/'unexpected-toolchain.txt').write_text('Dated nightly compiler did not match official pinned manifest 92b5b8c87c61b20adc9001b41baf587634a74734.\n'+ver)
    sys.exit(2)
asan={'RUSTFLAGS':'-Z sanitizer=address','ASAN_OPTIONS':'detect_leaks=1'}
results=[]
for target,count in [('ffi_smoke',6),('ffi_strings',3),('ffi_ops_interleave',2)]:
    result=run('asan-'+target,['cargo','+'+TC,'test','--locked','--release','--target','x86_64-unknown-linux-gnu','--test',target],timeout=1500,cwd=ROOT/'source',extra=asan)
    output=(E/result['stdout']).read_text(errors='replace')+(E/result['stderr']).read_text(errors='replace')
    result['expected_test_count']=count
    result['test_result_ok']=bool(re.search(r'test result: ok\. '+str(count)+r' passed; 0 failed;',output))
    result['asan_error_reported']='ERROR: AddressSanitizer:' in output or 'ERROR: LeakSanitizer:' in output
    result['accepted']=result['exit_code']==0 and result['test_result_ok'] and not result['asan_error_reported']
    (E/(result['name']+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    results.append(result)
# Supporting native scanner checks retain ASan instrumentation and explicit leak detection.
# Scalar-only scanner_crosscheck has placeholders on x86_64 and is intentionally omitted.
feature_probe=ROOT/'cpu-feature-probe.rs'
feature_probe.write_text('fn main() { println!("avx2={} pclmulqdq={}", std::is_x86_feature_detected!("avx2"), std::is_x86_feature_detected!("pclmulqdq")); }\n')
(E/'cpu-feature-probe.rs').write_bytes(feature_probe.read_bytes())
required('cpu-feature-probe-compile',['rustc','+'+TC,str(feature_probe),'-o',str(ROOT/'cpu-feature-probe')])
required('cpu-feature-probe-run',[str(ROOT/'cpu-feature-probe')])
scanner=[]
for name,args in [('default',[])]:
    result=run('scanner-'+name,['cargo','+'+TC,'test','--locked','--release','--target','x86_64-unknown-linux-gnu',*args,'--test','scanner_crosscheck'],timeout=900,cwd=ROOT/'source',extra=asan)
    scanner.append(result)
# Standalone negative control; never changes product source.
control=ROOT/'negative-control.rs'
control.write_text('''use std::alloc::{alloc, dealloc, Layout};\nfn main() {\n    unsafe {\n        let size = std::hint::black_box(8usize);\n        let layout = Layout::from_size_align(size, 8).unwrap();\n        let ptr = alloc(layout);\n        assert!(!ptr.is_null());\n        std::ptr::write_volatile(ptr.add(size), 42);\n        dealloc(ptr, layout);\n    }\n}\n''')
(E/'negative-control.rs').write_bytes(control.read_bytes())
compile_result=run('negative-control-compile',['rustc','+'+TC,'--crate-name','asan_negative_control','-Z','sanitizer=address','-C','opt-level=1','-g','--target','x86_64-unknown-linux-gnu',str(control),'-o',str(ROOT/'asan-negative-control')],timeout=180,extra={'ASAN_OPTIONS':'detect_leaks=1'})
negative={'compiled':compile_result['exit_code']==0,'accepted':False}
if negative['compiled']:
    negative_result=run('negative-control-run',[str(ROOT/'asan-negative-control')],timeout=30,extra={'ASAN_OPTIONS':'detect_leaks=1'})
    negout=(E/'negative-control-run.stdout').read_text(errors='replace')+(E/'negative-control-run.stderr').read_text(errors='replace')
    negative.update(exit_code=negative_result['exit_code'],address_sanitizer_report='ERROR: AddressSanitizer: heap-buffer-overflow' in negout,write_of_size_1='WRITE of size 1' in negout)
    negative['accepted']=negative_result['exit_code']!=0 and negative['address_sanitizer_report'] and negative['write_of_size_1']
# Record hashes and sanitizer symbols from every FFI executable; copy no binary into portable evidence.
binaries=[]
for stem in ['ffi_smoke','ffi_strings','ffi_ops_interleave','scanner_crosscheck']:
    binaries.extend(p for p in (ROOT/'target/x86_64-unknown-linux-gnu/release/deps').glob(stem+'-*') if p.is_file() and os.access(p,os.X_OK) and p.suffix!='.d')
if (ROOT/'asan-negative-control').exists():binaries.append(ROOT/'asan-negative-control')
proof=[]
for i,p in enumerate(sorted(set(binaries))):
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    nm=run('instrumentation-'+str(i),['nm','-a',str(p)],timeout=90)
    alltext=(E/nm['stdout']).read_text(errors='replace')
    lines=[s for s in alltext.splitlines() if '__asan_' in s]
    (E/(nm['name']+'.symbols.txt')).write_text('\n'.join(lines)+'\n')
    # Whole nm stdout is unneeded in portable receipts; retained remotely only.
    proof.append({'binary':str(p.relative_to(ROOT)),'sha256':digest,'bytes':p.stat().st_size,'asan_init_present':any('__asan_init' in s for s in lines),'asan_report_store_present':any('__asan_report_store' in s for s in lines),'asan_symbol_count':len(lines),'symbols_receipt':nm['name']+'.symbols.txt'})
(E/'binary-provenance.json').write_text(json.dumps(proof,indent=2)+'\n')
post=run('source-post-check',['sha256sum','-c','SOURCE_SHA256SUMS'],cwd=ROOT/'source')
(E/'source.SHA256SUMS').write_bytes((ROOT/'source/SOURCE_SHA256SUMS').read_bytes())
(E/'source-provenance.json').write_bytes((ROOT/'source-provenance.json').read_bytes())
accept={'host_label':'x86-validation-host','scope':'V05 native x86_64 ASan FFI gap','toolchain':TC,'requested_rustc_commit':'92b5b8c87c61b20adc9001b41baf587634a74734','actual_rustc_commit':'92b5b8c87c61b20adc9001b41baf587634a74734','prior_cargo_commit':'31d3246e0','toolchain_identity_note':'Prior 31d3246e0 identifier belongs to Cargo, not rustc. This channel matches prior rustc92b5b8c87 dated 2026-10-29.','target':'x86_64-unknown-linux-gnu','ci_commands_equivalence':'Pinned dated nightly, --locked, ASAN_OPTIONS=detect_leaks=1; CI uses unpinned +nightly and advisory continue-on-error','core_asan_tests':results,'core_expected_total':11,'core_passed':all(r['accepted'] for r in results),'scanner_support':scanner,'negative_control':negative,'binary_instrumentation':proof,'source_pre_post_unchanged':post['exit_code']==0,'finished_at_utc':now(),'passed':all(r['accepted'] for r in results) and negative['accepted'] and post['exit_code']==0 and all(p['asan_init_present'] and p['asan_report_store_present'] for p in proof)}
(E/'acceptance-summary.json').write_text(json.dumps(accept,indent=2)+'\n')
(E/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'passed':accept['passed'],'core_passed':accept['core_passed'],'negative_control':negative,'scanner_exit_codes':[r['exit_code'] for r in scanner]},indent=2),flush=True)
sys.exit(0 if accept['passed'] else 1)
