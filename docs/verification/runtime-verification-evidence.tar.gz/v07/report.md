# V07 exact OpenResty 1.27 verification — 2026-11-03

The exact requested official ARM64 image now runs. On the isolated V06 functional-fix snapshot, canonical smoke passes 19 assertions, full Busted with the pinned cjson oracle passes 820 tests, and native HTTP acceptance with the original official bundled cjson passes 72 checks, all exit 0. The original committed baseline is retained separately and has two actual numeric assertion failures under this LuaJIT. This is functional validation, not a memory/RSS/throughput result.

## Identities and isolation

- Repository baseline: `b2c670e81051d62bc1b2af8979a678f14a484848`, exported with `git archive` to `source/`. No main-checkout files were changed, committed, merged, or pushed by this task.
- Final snapshot: separate `source-v06/`, baseline plus supplied `v06-current-functional.patch`, SHA-256 `0ca6a5205fb99aeb72784fe62c8f8a08dc64f2388aa9f6ba7aadf14d337eac18`. All eight file hashes exactly match the parent's `v06-functional-manifest.json`; these are the only differences between the two snapshots (`evidence/source-comparison.json`). No patch edits or test expectation changes were made independently in V07.
- Official image tag: `openresty/openresty:1.27.1.2-0-jammy`; all containers created from immutable image ID `sha256:59095000111495453846cb82fc1cbc281e5ef8d2c96179565e6b134410258b86` (`linux/arm64`). RepoDigest: `openresty/openresty@sha256:75b4cc0454b577ed167a0e95064149bef6590e8e041fc86902f58bccdfe60d4e`. No official-image retag or replacement was performed.
- Runtime: nginx `openresty/1.27.1.2`, resty `0.29`, bundled `LuaJIT 2.1.ROLLING`, Linux arm64, Lua 5.2 compatibility enabled. Executable is `/usr/local/openresty/luajit/bin/luajit`; the Busted launcher's shebang/body and an actual Busted helper `/proc/self/maps` control prove the bundled executable ran, rather than distro Lua.
- Release library copied from `/tmp/leanjson-v06-20261103/evidence/target/release/libleanjson.so`: SHA-256 `8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b`. Current checkout versus baseline `src/`, `Cargo.toml`, `Cargo.lock`, `build.rs` comparison was empty (`evidence/rust-source-current.diff`). The supplied V06 patch changes no Rust/build files. Reuse of this already-built Linux library is preparation, not a new Rust test/build result.
- Submodule inputs exported by exact commit (not copied from dirty worktrees): JSONTestSuite `1ef36fa01286573e846ac449e8683f8833c5b26a` (`test_parsing`); cJSON `fb16e5cf358798aabb049655975cde8427101056` (`tests`); simdjson `43766fc7efdedc87111c48bda55f758ca212335b` (`jsonexamples`); lua-cjson `617164a0fe3bb647128178f9caefb304b8573bb6` (complete source).

## Results

| Snapshot / run | Result | Exit | Evidence log |
| --- | --- | ---: | --- |
| Baseline, original canonical script, `OPENRESTY_FULL_BUSTED=false` | 19 smoke assertions pass | 0 | `canonical-smoke.log` |
| Baseline, original canonical script, `OPENRESTY_FULL_BUSTED=true`, first archive without submodule fixtures | 762 success / 37 failure / 3 error / 0 pending | 1 | `canonical-full-busted.log` |
| Baseline, complete fixtures, stock bundled cjson | 798 success / 2 failure / 2 error / 0 pending | 1 | `full-busted-stock-complete-fixtures.log` |
| Baseline, complete fixtures, pinned reference cjson | 800 success / 2 failure / 0 error / 0 pending | 1 | `full-busted-pinned-reference-baseline.log` |
| Baseline, stock HTTP first attempt without test dependencies | missing `lfs` / `resty.http`; acceptance not reached | 1 | `native-http-stock.log` |
| Baseline, stock bundled cjson + installed HTTP dependencies | 72/72 HTTP checks pass | 0 | `native-http-with-dependencies.log` |
| V06 snapshot, original canonical script, `OPENRESTY_FULL_BUSTED=false` | 19 smoke assertions pass | 0 | `v06-canonical-smoke.log` |
| V06 snapshot, pinned reference cjson, full Busted | 820 success / 0 failure / 0 error / 0 pending | 0 | `v06-full-busted-pinned-reference.log` |
| V06 snapshot, pinned reference cjson, native HTTP | 72/72 checks pass | 0 | `v06-native-http-pinned-reference.log` |
| V06 snapshot, restored original official bundled cjson, final native HTTP | 72/72 checks pass | 0 | `v06-native-http-stock-final.log` |
| V06 Busted runtime/reference attribution control | 16 comment-policy tests pass, actual process mappings prove LuaJIT + reference library | 0 | `busted-attribution-control.log` |

Each log has an adjacent `.exit`; consolidated codes are `evidence/exit-summary.json`. The 16 attribution-control tests repeat an existing subset and are not added to the 820 full-suite count. Smoke counts are the 19 `assert` calls in the unchanged `.github/scripts/openresty-smoke.lua`; the script itself emits no pass-count line.

The initial missing-fixture attempt is retained as a setup mistake, not counted as a product regression: 35 fixture failures and one JSONTestSuite fixture error disappear after exact pinned fixtures are populated. The corrected stock-cjson run leaves two actual numeric failures and two missing-reference-API errors. Pinned lua-cjson resolves the latter without changing LuaJIT, LeanJSON, or assertions.

The original baseline's remaining actual failures are exactly:

- `tests/lua/cjson_numeric_limits_spec.lua:13`, test declared at line 3: huge decimal/hexadecimal exponent conversion, actual `-Inf`, expected `Inf`.
- `tests/lua/cjson_settings_spec.lua:31`, test declared at line 27: negative-zero encoding, actual `"0"`, expected `"-0"`.

The stock bundled cjson errors are `tests/lua/cjson_comments_spec.lua:55` and `:122`: `decode_allow_comment` is absent. The official bundle reports cjson `2.1.0.11`, but that version string is not sufficient to identify its API/source. The pinned reference also reports `2.1.0.11` and has the required function.

The V06 snapshot has 820 total tests (18 more than the 802 baseline); its two formerly failing test cases now pass together with the added focused coverage. The patch contains implementation and test fixes, so the baseline and final counts remain separately attributed.

HTTP coverage is the existing unmodified 72-check local acceptance suite: table/userdata, preload/eager, completed memory/file and incremental/fallback input, length/output, duplicates and invalid-input rejection, HTTP/1.1 chunked/HTTP/2 fallback, abort/cancel/fault handling, multiwaiter/fork/resource cleanup. It is a local sink test, with no real Kong/provider or performance claim. Final stock-cjson HTTP artifacts are `evidence/leanjson-openresty.QYfeeK/`; preceding pinned-reference replay artifacts are `evidence/leanjson-openresty.C6bf2U/`; baseline artifacts are `evidence/leanjson-openresty.tRZsHO/`; setup-failure artifacts are `evidence/leanjson-openresty.AfNJnU/`. The optional missing `resty.openssl.*` mTLS warning is retained; this harness does not exercise mTLS.

## Dependencies and reference selection

The original full canonical script was executed unchanged and installs apt test tooling plus LuaRocks Busted/lua-cjson. Its installed Busted was `2.3.0-1`; its actual selected cjson was the official bundled `/usr/local/openresty/lualib/cjson.so`, not the subsequently installed LuaRocks `2.1.0.10` module. Live provenance was captured before its `--rm` container exited.

Subsequent full-suite and HTTP runs use a separate transient `v07-runtime` container based on the same immutable official image. Additional apt packages: `liblua5.1-0`, `liblua5.1-0-dev`, `lua-any`, `lua5.1`, `luarocks`, `zip`; `ca-certificates` upgraded. Exact package versions are in dependency/provenance logs. LuaRocks installs are Busted `2.3.0-1`, lua-cjson `2.1.0.10-1`, lua-resty-http `0.17.2-0`, and transitive dkjson `2.11-1`, lua-term `0.8-1`, lua_cliargs `3.0.2-1`, luafilesystem `1.9.0-1`, luassert `1.9.0-1`, luasystem `0.7.1-1`, mediator_lua `1.1.2-0`, penlight `1.15.0-1`, say `1.4.1-3`.

`/usr/bin/luarocks` is the apt script, but actual loaded LuaRocks core reports `3.11.1`; final installs live under `/usr/local/openresty/luajit`. The original canonical installation selected `/usr/local` instead. Both actual trees and paths are recorded rather than inferred from package labels. Busted primary and child interpreter are explicitly the official LuaJIT binary.

Pinned reference cjson was built separately at `/evidence/native-reference/` using unchanged `617164a` source and `make LUA_INCLUDE_DIR=/usr/local/openresty/luajit/include/luajit-2.1`. Build settings are default `cc`, `-O3 -Wall -pedantic -DNDEBUG -g`, `-fpic`, `-shared`, libc `fpconv.o`. SHA-256: `87c13272cb1b9c6d4db1c91965ae64c7fae64011b6c8382baeaf8cc1b59c2489`. Busted sets `LUA_CPATH=/evidence/native-reference/?.so;;`; the attribution helper confirms this exact file is mapped in the test process.

For the first patched-source HTTP replay only, the stock cjson was saved as `evidence/official-cjson-stock.so` and the pinned reference copied to `/usr/local/openresty/lualib/cjson.so` inside the transient test container. This is an explicit test-reference overlay, not a claim that the unmodified official image contains that reference. The official image itself was not modified or retagged. The baseline HTTP run used the original official cjson. A final patched-source HTTP replay then restored the saved original cjson to `/usr/local/openresty/lualib/cjson.so`, verified SHA-256 `1a1a63451597f538bd6c595cc2792e2b6552827ad661d8372d62751ed7fdb347`, and passed all 72 checks, exit 0. Thus the final-source HTTP result does not require replacing the official bundled cjson. Test dependencies including lfs/resty.http remain installed for this replay; full Busted was not rerun because its comment-policy oracle correctly needs the pinned reference. The final identities are recorded in `final-stock-runtime-identities.log`; the original cjson API probe again reports `decode_allow_comment=nil`. LuaJIT executable/shared library and nginx hashes remained unchanged:

| Binary | SHA-256 |
| --- | --- |
| LuaJIT executable | `d6d6fed8b3fec6a86dda49b71ed96b7ed138a2643bf55d6d07a80409e79531ac` |
| LuaJIT shared library | `cb9b795abd8208bdafd0b7934933e56884b81f63e01fa802da1de8e2f37d6333` |
| nginx | `acdb9e31aa38e3953d22db5dd9e491a6472c086820e503782a85c39e898ffa1e` |
| Original bundled cjson | `1a1a63451597f538bd6c595cc2792e2b6552827ad661d8372d62751ed7fdb347` |

## Reproduction / evidence

See `evidence/commands.md` for command forms actually used, with source-path distinctions and setup ordering. Complete per-file snapshot fingerprints are `evidence/source-manifest.json` and `evidence/source-v06-manifest.json`. Image metadata, tree identity, empty Rust diff, installed versions, runtime paths, compiled reference/source, original cjson binary, helper source, test output and HTTP artifacts remain under `evidence/`.

No Rust suite, sanitizer, Valgrind, complete cjson compatibility matrix, RSS gate, or performance benchmark was run for V07. These functional results close the previously unexecuted exact 1.27 runtime coverage for the stated patched source and test-reference dependency; they do not rewrite the retained original-baseline failures or certify other versions/platforms.
