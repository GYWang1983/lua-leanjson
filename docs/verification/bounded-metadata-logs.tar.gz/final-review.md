### Strengths

- The branch implements the seven approved directions coherently: shared memory/file/feed sparse sources, 3/3/1048576 defaults, full eager validation independent of indexing depth, capacity-bounded native metadata, immutable span identities, sparse mutation overlays, and streaming normalized length/output. The contiguous parser and published v1 layouts remain separate; v2 is additive.
- Cache removal does not invalidate public spans, and durable edits are independent of indexes. Exact decoded-key comparisons preserve last-wins behavior; the final iterator changes preserve canonical live children while keeping earlier duplicate occurrences as snapshots. The focused tests exercise these behaviors rather than only implementation details.
- Resource ownership has meaningful coverage: idempotent native cleanup owners, shared unlinked spill storage, free-region reuse/coalescing, held-reader reclamation, shutdown subprocesses, and a 64-descriptor deep-spill case. The existing four final Valgrind receipts record zero errors, zero suppressed errors, and zero bytes remaining.
- The corrected comparison harness conditionally loads LeanJSON, forwards HTTP decoder options correctly, checks effective settings, and performs external typed/duplicate-output validation. Independent inspection of the final artifacts confirms 63 strict matched process comparisons and four HTTP oracle rows. The documentation prominently discloses CPU/I/O costs and the limits of RSS conclusions.

### Issues

#### Critical (Must Fix)

- None found.

#### Important (Should Fix)

1. **Chosen object keys make the new disk hash map perform quadratic synchronous I/O.**
   - **File:** `src/source/duplicates.rs:225` (fixed hash at `:159`; linear probing at `:226-248`; rehash probing at `:209-210`).
   - **What is wrong:** `hash()` is public, fixed FNV-1a, and slots use its low bits with linear probing. An input producer can cheaply choose distinct decoded keys that all start in the same slot at every relevant power-of-two capacity. Exact comparison preserves correctness, but does not bound this collision cost. The path is reached by ordinary `json.len`, normalized readers, and annotated object iteration, including memory input and zero/default index budgets.
   - **Confirmed effect:** In the exact committed runtime image with `index_budget_bytes=0`, `json.len` on 1,024 colliding scalar fields (12,768 input bytes) performed **922,857 read syscalls and 0.258 CPU seconds**, versus **8,298 and 0.006 CPU seconds** for ordinary keys. Doubling colliding fields yields approximately four times as many reads:

     | Fields | Colliding read syscalls | Colliding CPU seconds | Ordinary read syscalls |
     | ---: | ---: | ---: | ---: |
     | 128 | 14,971 | 0.004666 | 1,071 |
     | 256 | 58,653 | 0.016668 | 2,031 |
     | 512 | 232,033 | 0.063992 | 4,024 |
     | 1,024 | 922,857 | 0.257571 | 8,298 |

   - **Why it matters:** These are valid, small JSON inputs. Slot probes call unbuffered file seek/read operations inside a native call, so the work blocks the Lua/OpenResty worker. This is input-controlled amplification beyond the disclosed normal wide-object cost. A bounded algebraic construction produced 32,768 distinct decoded ASCII keys sharing the low 16 bits in 694,964 JSON bytes; insertion alone then requires at least **536,887,296 slot probes**, before rehash work. That larger document was constructed and checked analytically only; it was **not** run through the native runtime, and no elapsed-time extrapolation is claimed.
   - **Fix:** Use a per-map/source keyed collision-resistant hash, such as a standard-library randomized hasher, or a collision-bounded disk structure/fallback. Keep full decoded-key comparison and the existing memory/cleanup constraints. Add a regression using crafted bucket collisions and a meaningful work/probe bound so the test does not depend on wall-clock noise. The change must cover both insertion/rehashing and `is_current` lookup.
   - **Reproduction/evidence:** The focused probe used image ID `sha256:94b90eff3bc0323118abd43052b0b1a5db44122e3c75ee11e9d366f8e0a773fa`, source `e7b3218bfce7dfbc83e59d4ca47988b413bcf5bb`. Its directory is `/var/folders/sy/sj4rcsyd2nx3090p_tk87hyw0000gn/T/leanjson-final-review-collisions-e2z5r8_k/` (`probe.lua`, fixtures, `output.jsonl`, construction receipts). The tested keys are increasing ASCII `k<decimal>` strings selected by `FNV1a64(key) & 2047 == 0`; the first keys are `k990`, `k1643`, `k2556`, `k4921`, `k5948`, `k8460`, `k10090`, `k13864`. The 1,024th is found by candidate 2,034,177. The probe asserts the exact member count and zero spill file/live regions after traversal.

#### Minor (Nice to Have)

1. **The memory runner records an image ID but executes the mutable reference.**
   - **File:** `scripts/verify-memory.py:78`, `:88`, `:98`.
   - **What is wrong / impact:** Docker commands retain `args.image` after its ID is recorded; packaged-runtime mode also leaves its Lua digest null. Reassigning that tag during a future run can change the actual environment or packaged Lua while the recorded image ID/native fingerprint appears stable. This is a future reproducibility gap, not evidence that the archived measurements were contaminated; the final mounted-runtime rows consistently record both native and Lua fingerprints.
   - **Fix:** Resolve the image ID before assembling commands, launch all fixture/fingerprint/measurement containers by that ID, and record a packaged Lua-tree digest. **Merge triage:** nonblocking on its own; the final evidence is usable, but harden the runner before relying on mutable-tag packaged comparisons.

2. **The committed whole-branch whitespace check fails on copied log receipts.**
   - **File:** `docs/verification/bounded-metadata-checks.txt:158` and `docs/verification/bounded-metadata-final-checks.txt:151` (and subsequent copied Valgrind blank-prefix lines).
   - **What is wrong / impact:** `git diff --check 69261582ca7c0684c5453d7f270c091078c091b5..e7b3218` reports 33 trailing-whitespace lines. This is a documentation/check-hygiene issue, with no runtime effect.
   - **Fix:** Trim trailing whitespace in the selected receipt files while preserving the original raw logs, their hashes, and all JSONL evidence. **Merge triage:** nonblocking runtime-wise; resolve as part of the required final diff check.

### Recommendations

- Fix the collision amplification before merging. Refresh the affected functional/resource checks and runtime acceptance evidence after the runtime change; the existing 63-pair results establish the reviewed revision's normal-workload behavior, not an unmeasured successor's behavior.
- Keep the disclosed wide-object latency and page-cache/tmpfs boundaries visible. Neither the successful finite memory matrix nor the collision fix should be presented as universal memory or CPU dominance.

### Checks and Scope

- Reviewed base `69261582ca7c0684c5453d7f270c091078c091b5` through head `e7b3218bfce7dfbc83e59d4ca47988b413bcf5bb` against `docs/design/2026-11-02-bounded-metadata.md` and `docs/plans/2026-11-02-bounded-metadata.md`. Read the complete code/doc review view in sequential passes; recovered the initially truncated documentation segment. Read both task reports and their review/fix reports as claims, then checked implementation and evidence independently.
- Programmatically verified the final JSONL: four environment groups, 33 + 9 + 12 + 9 = **63 pairs**, matching input hashes/lengths, all **126 semantic flags**, strict RSS ordering, phase HWM/Lua maxima, effective index settings/capacities, and LeanJSON chunk bounds. The tightest ratio is **0.992887**, wide-scalars/memory/default. Four HTTP rows match paired input hashes/lengths, branch count 0, concurrency 2, six timed requests, and passing separate output oracles.
- Matched **11 selected receipt hashes** to the original logs. Inspected the canonical **408 Lua / 50 HTTP** result, native modes, lint, properties, source stress/corpus, locked fuzz compilation, installed-package smoke, and four final Valgrind summaries. The current Lua-tree digest equals the final recorded digest `9472b8880f4d4949010ec210bf8962008539819a3b18d29d805efbcfd5390db3`.
- Inspected the final exact-image build/smoke receipts: image ID above, source label `e7b3218`, four memory/file/incremental length+SHA checks and malformed-input rejection. The controller also reports the runtime image has no Rust/Cargo; no build/smoke was rerun by this review.
- Outside-diff reads were limited to concrete named risks: cancellation checks around the shared scalar/iterator callbacks (`source.lua`/`leases.lua`), actual RSS metric collection (`metrics.lua`), and decoder-option forwarding through `read_body`/`start_body` (`openresty.lua`). These checks resolved those doubts without additional findings.
- The sole runtime execution was the small, controller-coordinated collision probe above. No suites, broad benchmarks, builds, source edits, Git index/HEAD/branch changes, or subagents were used. Only this review artifact was added to the checkout; probe artifacts are outside it.

### Declined to Judge

- Kong/Gateway integration, GitHub/branch publication, package publication, and repository renaming: explicitly excluded from this task.
- Universal process/container RSS or disk bounds across all documents, allocators, filesystems, caller-held values, or simultaneous readers: the approved contract bounds rebuildable retained metadata and requires a finite matched workload gate; the implementation documents the other storage categories separately.
- Whether the disclosed ordinary wide-object HTTP p50 of 1,387 ms meets a particular deployment's latency SLO: no deployment SLO is supplied. The measured cost and its disclosure were assessed; the separately reproducible adversarial amplification is graded above.

### Assessment

**Ready to merge? With fixes.**

**Reasoning:** The seven memory optimizations and normal-workload acceptance are supported by the reviewed code and evidence, with the earlier public-iterator and harness defects addressed. The new exact-key disk map still allows cheaply chosen valid JSON keys to impose quadratic blocking I/O, so that Important issue should be fixed before merge; the two Minor issues do not independently invalidate the runtime or its archived acceptance results.
