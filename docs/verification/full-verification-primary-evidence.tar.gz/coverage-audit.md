# Full-verification coverage audit

Audit date: 2026-11-03. Scope is read-only at
verify/full-suite-2026-11-03, HEAD
33d00b522d87cc760f757404186488453ffcb498. No build, test, benchmark, Docker
run/build, fuzz session, or GitHub workflow was started for this audit.

## Primary-run boundary

The primary agent's make openresty-verify campaign covers release Rust
default/scalar/test-panic matrices, Clippy, Lua tests and lint, deterministic
properties, source stress/corpus replay, and native HTTP acceptance. Separate
primary work covers both 9-cell cjson matrices, both 33-pair memory matrices,
both 18-cell loading matrices, 16 MiB prompt/messages pairs, the installed
Linux LuaRocks tree, and the exact-commit runtime image. This audit does not
duplicate those heavy runs.

The remaining meaningful families are the native macOS gate, six-target
libFuzzer/corpus coverage, Miri/ASan, Valgrind, supply-chain audit, OpenResty
version profiles, and full performance timing. Their canonical definitions are
in Makefile:36-110, .github/workflows/ci.yml:216-564,
.github/workflows/fuzz.yml, .github/workflows/lua-valgrind-full.yml, and
.github/workflows/supply-chain-audit.yml.

## Host inventory

This host is Darwin 27.0, arm64. Present: Apple clang 21.0.0, GNU make 3.81,
Docker CLI 29.8.2, Python 3.9.6, PUC Lua 5.5.1, and LuaRocks 3.13.0. Absent:
cargo, rustc, rustup, LuaJIT, Busted, Luacheck, resty, OpenResty/nginx,
cargo-fuzz, cargo-audit, Miri, Valgrind, CMake, and QEMU. PUC Lua 5.5 is
not a substitute: the package requires LuaJIT FFI despite the Lua 5.1 ABI in
the rockspec. Docker daemon state was not probed. All four git submodules are
populated at the commits shown by git submodule status.

## Prioritized extended gates

### P0: native macOS Rust and installed rock (finite, minutes)

The macOS CI profile should be reproduced on an arm64/macOS runner, plus the
panic feature if available:

~~~sh
rustup toolchain install stable --profile minimal --no-self-update
rustup default stable
cargo test --locked --release
cargo test --locked --release --no-default-features
cargo test --locked --release --features test-panic
cargo clippy --locked --release --all-targets -- -D warnings
cargo build --locked --release
~~~

Then use an isolated LuaRocks tree, outside the checkout and without workspace
library paths:

~~~sh
rm -rf /tmp/lua-leanjson-rock
ROCKSPEC="$(.github/scripts/latest-rockspec.py)"
luarocks make "$ROCKSPEC" --tree /tmp/lua-leanjson-rock
unset LD_LIBRARY_PATH DYLD_LIBRARY_PATH
LUA_PATH='/tmp/lua-leanjson-rock/share/lua/5.1/?.lua;/tmp/lua-leanjson-rock/share/lua/5.1/?/init.lua' \
LUA_CPATH='/tmp/lua-leanjson-rock/lib/lua/5.1/?.so' \
  luajit .github/scripts/installed-package-smoke.lua
~~~

The smoke must prove installed-module/native loading, not accidentally load
checkout files. CI uses LuaJIT 2.1.0-beta3 and LuaRocks 3.11.1. The current
host cannot run this gate until Rust and LuaJIT are provisioned. Rust tests,
Clippy and the release artifact may share a platform-local Cargo target but
should be serialized. A macOS dylib cannot feed Linux Docker gates.

### P0: bounded libFuzzer and corpus replay (finite, 3-10 minutes)

~~~sh
rustup toolchain install nightly --profile minimal --no-self-update
cargo +nightly install --version 0.13.2 --locked cargo-fuzz
LEANJSON_FUZZ_SECONDS=30 LEANJSON_KEEP_FUZZ_OUTPUT=1 make bounded-fuzz
~~~

The wrapper runs fuzz_parse_eager, fuzz_parse_lazy, fuzz_ffi_ops, fuzz_depth,
fuzz_numbers, and fuzz_source_windows for the bounded time per target. CI's
-runs=0 replay covers all except fuzz_numbers; add:

~~~sh
cargo +nightly fuzz run fuzz_numbers -- -runs=0
~~~

Run the other replay commands from .github/workflows/ci.yml:329-337, retaining
the source-window fuzz_parse_eager corpus and -max_len=16384. Replay of the
committed corpus is finite. A 30/60-second libFuzzer session is only a bounded
sample, never exhaustive fuzzing; unbounded fuzzing cannot be marked complete.
Fuzz uses a separate fuzz/target and should not run with Cargo release or
sanitizer builds.

### P1: Miri and ASan cross-target checks (finite, high cost)

On Linux nightly, install x86_64-unknown-linux-gnu,
i686-unknown-linux-gnu, powerpc64-unknown-linux-gnu, and the Miri component.
Run the four scalar FFI tests (ffi_smoke, ffi_cursor, ffi_strings,
ffi_ops_interleave) with:

~~~sh
cargo +nightly miri test --target <target> --no-default-features --test <test>
~~~

for every target/test pair, exactly as .github/workflows/ci.yml:366-385
specifies. Then run the three ASan tests from lines 387-394, preferably with
CARGO_TARGET_DIR=target/asan:

~~~sh
RUSTFLAGS='-Z sanitizer=address' CARGO_TARGET_DIR=target/asan \
  cargo +nightly test --release --target x86_64-unknown-linux-gnu --test ffi_smoke
RUSTFLAGS='-Z sanitizer=address' CARGO_TARGET_DIR=target/asan \
  cargo +nightly test --release --target x86_64-unknown-linux-gnu --test ffi_strings
RUSTFLAGS='-Z sanitizer=address' CARGO_TARGET_DIR=target/asan \
  cargo +nightly test --release --target x86_64-unknown-linux-gnu --test ffi_ops_interleave
~~~

Miri is interpreter-level scalar/32-bit/big-endian coverage and does not make
a deployable library. ASan needs Linux nightly/LLVM sanitizer runtime. Existing
CI marks ASan continue-on-error; a comprehensive report must call it advisory
unless a strict rerun removes that allowance. Expect tens of minutes or more;
run sequentially and keep Miri/ASan artifacts separate. Neither is available
on this host.

### P1: full LuaJIT Valgrind (finite, high cost)

Use Linux with upstream LuaJIT 2.1.0-beta3, Busted dependencies, the release
so, and valgrind.supp. The full scheduled command is:

~~~sh
LUA_INIT='if jit then jit.off() end' \
LD_LIBRARY_PATH="$PWD/target/release" \
  valgrind --trace-children=yes --error-exitcode=1 --leak-check=full \
    --show-leak-kinds=definite,indirect,possible \
    --errors-for-leak-kinds=definite,indirect,possible --num-callers=24 \
    --suppressions=valgrind.supp busted --lua="$LUAJIT_BIN" tests/lua \
    --lpath='./lua/?.lua'
~~~

The workflow timeout is 120 minutes; the focused eight-spec CI smoke is triage,
not a full memory gate. Valgrind is absent on this macOS arm64 host, so use
Linux CI/container. Serialize it from memory/benchmark/fuzz jobs.

### P1: supply-chain audit (finite, usually minutes)

Provision Cargo and cargo-audit using the CI installation policy, then run the
exact HEAD:

~~~sh
cargo audit
~~~

Record tool/advisory-database versions and network timestamp. This reads
Cargo.lock and does not share or validate the release binary. The ordinary CI
audit can conditionally skip unchanged manifests, so a fresh report must not
cite that skip as an audit result. The current host lacks both tools.

### P1: OpenResty/LuaJIT profile matrix (finite, minutes per image)

After one Linux release build, run the CI images through
.github/scripts/run-openresty-runtime.sh, recording each immutable image ID
and printed resty/LuaJIT version:

~~~sh
OPENRESTY_IMAGE=openresty/openresty:1.21.4.4-0-jammy \
  OPENRESTY_FULL_BUSTED=false .github/scripts/run-openresty-runtime.sh
OPENRESTY_IMAGE=openresty/openresty:1.27.1.2-0-jammy \
  OPENRESTY_FULL_BUSTED=false .github/scripts/run-openresty-runtime.sh
OPENRESTY_IMAGE=openresty/openresty:1.29.2.4-0-jammy \
  OPENRESTY_FULL_BUSTED=true .github/scripts/run-openresty-runtime.sh
~~~

This shares one Linux target/release/libleanjson.so; Docker invocations are
isolated and should be serialized when resources are limited. CI smoke-tests
1.21/1.27 and runs full Busted only on 1.29; full Busted on all three is a
stronger optional profile check. The current host has no OpenResty/resty and
Docker availability was not exercised. Plain PUC Lua is not an extra valid
runtime profile.

### P2: full performance timing (finite, performance-only)

Only run this if the final report replaces current performance claims:

~~~sh
make bench
make bench-rust
LEANJSON_BENCH_CASES='prompt input messages escaped short-elements explicit cold' \
  make openresty-bench
~~~

These require native resty/LuaJIT, lua-cjson (and optional simdjson), and quiet
CPU/I/O. They share the release library but must not run with memory, Valgrind,
or fuzz gates. bench-smoke is correctness smoke, not current timing evidence.

## Artifact sharing and serialization

* Freeze one Linux release library SHA-256 and Lua source-tree digest before
  fan-out to Lua/OpenResty, memory/loading, compatibility, and runtime-image
  checks.
* The two cjson matrices may share the immutable image and binary, but require
  separate output/locale directories. Their source-built reference cjson and
  target bootstrap must stay isolated.
* Memory/loading cells intentionally use fresh processes and serialize cjson vs
  LeanJSON pairs; do not infer from a reused worker.
* macOS builds a separate dylib; Miri, ASan, Valgrind and fuzz use separate
  targets/artifacts and should be serialized from Cargo release builds.
* Preserve harness errors separately from expected compatibility differences.
  strict exit 1 with harness_healthy=true is an intentional behavioral result,
  not a harness failure.

## Historical claims and cjson identity constraints

No pre-HEAD report is fresh evidence for this verification. In particular,
f18-userdata-proxies.md and f16-module-identity.md stop at parent 72d424e and
predate HEAD's identity/version commit; their Lua counts, 9-cell
classifications and 33-pair memory results need fresh HEAD receipts.
upstream-cjson-compatibility.md explicitly reports the pre-F03 b928a20
baseline; F03/F04/F15/F18 are historical task snapshots. The old
decode-loading-modes.md, bounded-metadata.md, openresty-json-source.md, and
F01-F15 reports are also tied to earlier revisions. README.md:637-649,
:676-685, :717-724, and docs/benchmarks.md must not be used as current
measurements until replaced. Old OpenResty results use qjson labels and are
not evidence for renamed leanjson.

The replacement report must preserve these facts:

1. LeanJSON intentionally reports _NAME="leanjson" and _VERSION="0.1.0";
   rockspec scm-1 is a development package revision. The pinned reference
   expects cjson/2.1.0.11. Do not alias or relabel LeanJSON to turn that
   intentional brand difference into a compatibility pass; classify the actual
   result as a behavioral difference.
2. The compatibility matrix uses source-built vendored lua-cjson commit
   617164a0fe3bb647128178f9caefb304b8573bb6 with native cjson denied during
   target bootstrap. Memory/loading baselines use the image-installed native
   cjson. Equal _VERSION strings do not prove equal binaries: record loaded
   path, source revision, compiler/image digest, and binary SHA-256 separately.
3. Table and userdata carriers are separate matrices. Preserve actual Lua
   types and native exact verdicts; logical agreement or a healthy harness does
   not erase carrier/identity differences.

## Final boundary

Finite full verification can cover all listed bounded commands at this exact
HEAD when prerequisites and receipts exist. It cannot claim exhaustive fuzzing,
unsupported platforms, or unrun CI profiles. Missing tools on this host are an
execution-environment blocker, not a reason to mark runnable Linux/macOS gates
as skipped; use the existing CI profiles or a provisioned equivalent and keep
each result visible.
