local method = assert(arg[1])
if method == "cjson" then
    package.preload["leanjson"] = function() error("cjson phase imported LeanJSON", 0) end
end
local printed, previous = nil, print
print = function(line) printed = line; previous(line) end
dofile("tests/openresty/memory-phases.lua")
print = previous
local result = require("cjson").decode(assert(printed))
local output = assert(io.open(arg[4], "rb"))
local value = require("cjson").decode(assert(output:read("*a"))); assert(output:close())
assert(value.model == "rewritten-1" and value.items[1].id == 1)
if method == "cjson" then
    for name in pairs(package.loaded) do
        assert(name ~= "leanjson" and not name:match("^leanjson%."), "cjson loaded " .. name)
    end
else
    assert(package.loaded.leanjson and package.loaded["leanjson.lib"])
    for _, phase in ipairs(result.phases) do
        if phase.index then
            assert(phase.index.budget_bytes == tonumber(arg[6]))
            assert(phase.index.index_depth == tonumber(arg[8]))
            assert(phase.index.index_array_limit == tonumber(arg[9]))
        end
    end
end
print("phase module/options assertions passed: " .. method)
