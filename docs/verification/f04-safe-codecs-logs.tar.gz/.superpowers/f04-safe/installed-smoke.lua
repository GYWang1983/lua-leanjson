local root = "/workspace/.superpowers/f04-safe/rocktree"
package.path = root .. "/share/lua/5.1/?.lua"
package.cpath = root .. "/lib/lua/5.1/?.so"
package.preload.cjson = function()
    package.loaded.cjson = nil
    error("native cjson disabled")
end
local safe = require("leanjson.safe")
assert(package.searchpath("leanjson.safe", package.path) == root .. "/share/lua/5.1/leanjson/safe.lua")
assert(package.loaded.cjson == nil)
assert(safe.decode("false") == false)
local value, err = safe.decode("Oops")
assert(value == nil and type(err) == "string")
assert(not pcall(safe.encode))
local a, b = safe.new(), safe.new()
a.encode_number_precision(3)
assert(a.encode(1 / 3) == "0.333" and b.encode_number_precision() == 14)
local d = assert(a.new_decoder({ preload_paths = { "$.n" } }))
assert(d:feed('{"n":1}'))
value = assert(d:finish()); d:close()
value.n = 1 / 3
assert(a.encode(value) == '{"n":0.333}')
a.close(value)
local f = assert(io.open("/proc/self/maps"))
local maps = f:read("*a"); f:close()
assert(maps:find(root .. "/lib/lua/5.1/leanjson.so", 1, true))
print("installed safe module and native library: PASS; no source-tree/native-cjson fallback")
