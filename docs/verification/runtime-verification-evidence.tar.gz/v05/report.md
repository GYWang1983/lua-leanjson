# V05 native x86_64 ASan verification

Result: PASS. The three CI FFI suites completed with **11/11 tests passed and actual exit 0** under native x86_64 ASan, including explicit `ASAN_OPTIONS=detect_leaks=1`. The standalone illegal-write control compiled successfully and produced an ASan heap-buffer-overflow report with actual exit 1.

## Source identity

- Git HEAD: `b2c670e81051d62bc1b2af8979a678f14a484848`; working tree was dirty and its current source changes are included.
- Snapshot captured: `2026-11-03T17:15:02.395892+00:00`; 180 files.
- `source/source.tar.gz` SHA-256: `3820b604beb64d7c879aa58c7a184be85b4ab60825ba8cc47f4fe5b14b3fa2b2`.
- Source manifest SHA-256: `24fc4cc35489070f880e406e8ec314440f059f9ad48a52822c6d4f22863579cf`.
- Per-file SHA-256 checks passed on the remote snapshot before and after verification. The source archive contains the explicit source/test/include/Lua/benchmark roots and manifests, excluding `.git`, build output, ignored vendor build caches, docs, secrets and unrelated workspace paths.
- `source/git-status.txt` and `source/git-diff-stat.txt` disclose the original workspace state. No repository product files were edited by this verification task.

## Environment and exact tools

Host label: `x86-validation-host`; native x86_64 Ubuntu 22.04.5 LTS, GNU C toolchain. Full OS/CPU receipts are in `receipts/host-os.stdout` and `receipts/host-cpu.stdout`.

```text
rustc 1.101.0-nightly (92b5b8c87 2026-10-29)
binary: rustc
commit-hash: 92b5b8c87c61b20adc9001b41baf587634a74734
commit-date: 2026-10-29
host: x86_64-unknown-linux-gnu
release: 1.101.0-nightly
LLVM version: 23.1.4
cargo 1.101.0-nightly (31d3246e0 2026-10-27)
```

Pinned channel: `nightly-2026-10-30`. Rust's compiler commit and Cargo's commit are recorded separately. The prior `31d3246e0` identity belongs to Cargo; this run matches the prior Rust compiler `92b5b8c87`.

Rustup, Cargo and all generated output were confined to the task's directories. Docker was not used. No daemon, service, firewall, global toolchain or unrelated host configuration was changed. Canonical host-side rustup-init transfer timed out after its bounded 180-second attempt; rsproxy transport was then used. The installer matched the official static.rust-lang.org SHA-256 and an independent local official download (`b1c8cb14e30889e7e2999e6b69e62d9e9b9ffc0f4df8180564d306d9680e6c55`). The dated mirror manifest was byte-identical to the official manifest, whose published SHA-256 was checked. Rustup validated component downloads using this manifest. Download and installed tool identities are preserved in the receipts and `downloads/`.

## CI-equivalent ASan suites

The workflow's `.github/workflows/ci.yml:387-394` uses `RUSTFLAGS=-Z sanitizer=address` and advisory `continue-on-error: true`. This run uses the same target and test suites, pins the nightly to match prior evidence, adds `--locked`, enables leak detection, and requires actual exit 0.

```sh
RUSTFLAGS='-Z sanitizer=address' ASAN_OPTIONS=detect_leaks=1 \
  cargo +nightly-2026-10-30 test --locked --release \
  --target x86_64-unknown-linux-gnu --test <suite>
```

| Suite | Passed | Actual exit |
| --- | ---: | ---: |
| `ffi_smoke` | 6/6 | 0 |
| `ffi_strings` | 3/3 | 0 |
| `ffi_ops_interleave` | 2/2 | 0 |

Every suite's command, timestamps, duration, environment and actual exit are in `receipts/asan-*.json`; full stdout/stderr are alongside them. There were no AddressSanitizer or LeakSanitizer error reports in these positive runs.

## Instrumentation and negative control

The final binary paths are taken from Cargo’s actual `Running` lines. The initial driver used the older Cargo artifact layout and its preserved `driver-binary-provenance.json` contained only the control binary; the final post-run receipts supersede that incomplete glob result. No tests were rerun or their output changed. The exact FFI test binary hashes and ASan symbols are recorded in `receipts/binary-provenance.json` and `receipts/instrumentation-*.symbols.txt`. The binaries contain `__asan_init` and `__asan_report_store*` symbols. FFI function disassembly receipts additionally show sanitizer checks in the product code when available. Binary files and target caches are omitted from the portable evidence.

The standalone `receipts/negative-control.rs` allocates 8 bytes, writes one byte at offset 8 with `write_volatile`, and is compiled by the same Rust toolchain with `-Z sanitizer=address`. Compilation exit was 0; the executable exited 1 with `ERROR: AddressSanitizer: heap-buffer-overflow` and `WRITE of size 1`. This is an executed sanitizer failure, not a compile failure. Full output and actual exits are in `receipts/negative-control-*`.

## Supporting scanner check and scope

Rust runtime feature probe: `avx2=true pclmulqdq=true`. The default-feature scanner cross-check completed with exit 0: its two substantive tests include 2000 generated scalar-versus-AVX2 comparisons and the continued-backslash boundary case. Its `skip_neon` test is a platform placeholder and is not counted as NEON coverage. The scalar-only scanner target was omitted because it has placeholder tests on x86_64.

This evidence closes the native x86_64 ASan FFI gap for the identified snapshot. It does not add RSS/performance, a full Rust-suite, a Lua-suite, additional targets, or whole-program memory-safety claims. Public receipts use a host label; test output/results were not redacted or changed.
