# Independent F13/F14 task review

Reviewed on 2026-11-02 against base `15bada3`, using the uncommitted working-tree
review package. The assignment, global constraints, implementer report and full
`review-package.patch` were read before targeted integration checks. The package
includes the new regression test, plan and parent verification document as well
as the tracked runtime/document changes.

## Verdicts

- **Spec compliance: APPROVED.** No actionable runtime/spec defect was found.
  The supported native indentation/skip behavior is implemented within the
  stated extension and native-bug boundaries.
- **Task quality: APPROVED.** The implementation and regression coverage are
  suitable for the task gate. The sole P3 documentation note below was corrected
  by the parent and the exact revised paragraph was checked. No open finding
  requires a runtime change or another test run.

## Findings

### P3-1 — RED evidence description (closed)

**Location:** `docs/verification/f13-f14-encoding.md:69`.

The original sentence said the RED artifacts record both indentation and
unsupported-value behavior failures before their corresponding changes. The
available RED artifacts establish the following:

- `task-1-red.log`: missing `encode_indent` public function.
- `task-1-red-behavior.log`: a clean raw proxy returns compact source bytes
  instead of the requested indented layout.
- `task-1-red-compact-duplicates.log`: compact rebuilding retains both duplicate
  keys instead of the prior final-value behavior.

They do not show a distinct unsupported-value behavior RED. The new test source
does contain skip coverage, and its reported GREEN result is not in question.
The parent corrected the paragraph to name only the missing API, indentation
behavior and compact duplicate regression as the recorded REDs. It now explicitly
states that a separate historical skip-behavior RED was not captured and that
skip correctness is established by GREEN regressions and independent native
probes. I checked the revised paragraph at lines 68–74. **Closed; no remaining
action.** This was an evidence-description nit, not a missing functionality
finding, and its correction changed no runtime/test source.

**Critical/high/medium findings:** none.

## Spec evidence from the code

1. **Isolated configuration and public APIs.** `lua/leanjson/table.lua:148`
   allocates both settings inside each codec closure. The setters at lines 162
   and 177 validate arity before assignment, preserve the previous setting on
   invalid input, accept nil getters, coerce numeric indentation and truncate
   C-string options at NUL. The new public export list at line 582 and
   `lua/leanjson.lua:276` expose them. The existing safe wrapper copies a fresh
   codec's methods, keeping configuration errors outside protected conversions.

2. **Skip semantics and preserved errors.** The shared predicate at
   `lua/leanjson/table.lua:142` admits only unsupported kinds and excludes the
   existing int64/uint64 numeric extension. The ordinary encoder at line 448
   handles sentinels/nil before unsupported checks, validates object keys before
   skipping children, and leaves classification, numeric checks, active-table
   cycle checks and depth checks intact. Array holes still reach null emission.
   Visited membership and emitted count are separate, so all-skipped nonempty
   containers retain their final newline without stray commas.

3. **Uniform container layout.** `lua/leanjson/reader.lua:19` disables raw-span
   reuse for every container when indentation is nonempty. The ordinary encoder
   at `lua/leanjson/table.lua:448` similarly prevents whole-container keep_origin
   reuse while preserving eligible scalar records. Nested proxies enter the
   calling codec's reader at their actual depth. Empty indentation retains the
   previous raw-byte behavior rather than introducing a canonicalizer.

4. **Frozen readers and consistent output length.**
   `lua/leanjson/table.lua:538` captures the new policy values at reader creation.
   `lua/leanjson/reader.lua:105` counts the same emitted members, separators,
   newlines, indent byte lengths and object-colon spacing as the output loop.
   The repeat frame at lines 164 and 203 emits at most the current output room;
   it does not allocate a depth-sized repeated indentation string. The existing
   next/length lifecycle validates before publishing output and closes on EOF,
   error or cancellation.

5. **Native contracts and explicit differences.** Focused reads of
   `vendor/lua-cjson/lua_cjson.c:318`, `:430`, `:700`, `:806` and `:930` confirm
   numeric/string coercion, C-string NUL behavior, all-skipped final newlines,
   key validation before skip, and the native lightuserdata empty-token branch.
   The safe empty/default getter, existing integer-cdata support and non-null
   lightuserdata behavior are explicitly documented as differences. They are
   not counted as native-equivalence successes.

## Concrete integration risks checked outside the diff

These were bounded checks of named risks; no broad repository rereview was done.

| Named risk | Focused source check | Result |
| --- | --- | --- |
| Reader filtering might suppress invalid keys or retain mutable input/settings | `lua/leanjson/proxy.lua:101` snapshot construction and `lua/leanjson/reader.lua:321` initialization | Object keys are converted/validated before children are accepted; ordinary values are snapshotted, source nodes are immutable, and reader policy values are captured. Null and empty-array sentinels receive supported node kinds. |
| New public settings might be shared or accidentally protected by safe wrappers | `lua/leanjson/safe.lua:23` fresh-codec construction and method copying | Safe instances own fresh normal codecs; setters remain direct configuration calls, while encode/decode retain their established protected behavior. |
| Indentation might lose source-duplicate semantics or normalize edited objects differently | `lua/leanjson/nodes.lua:70` iterator branches | Clean/preloaded source iteration supports lexical occurrences; dirty object overlays intentionally normalize their base. The new reader chooses lexical traversal only for pretty output unless normalization is explicitly requested, retaining compact rebuilding behavior. |
| Retained keep_origin strings might bypass slash/DEL policy, or mixed proxies might indent at root depth | `lua/leanjson/table.lua:60` materialization records and `:370` proxy encoding | Raw scalar records are restricted to strings unaffected by the escape policy; nested proxy encoding passes the current depth and calling codec. |
| Newly forced container traversal might leak source operations after error/cancellation | `lua/leanjson/source_backend.lua:154`, `lua/leanjson/leases.lua:51`, `:77`, and `lua/leanjson/reader.lua:278` | Source iterators register native operation and lease cleanup in the reader scope. EOF/error finishes iterator records; reader failure/close releases every remaining record and backend lease. Cancellation wins over resumed output. |
| The independent oracle might silently use the image cjson after the initial setup error | `task-1-oracle.lua:1` explicit loader and the focused pinned C source reads above | The final oracle explicitly loads the parent-built pinned shared object. The superseded image observations are disclosed separately. |

## Regression quality and verification boundary

The new 303-line regression file exercises public defaults and isolation,
argument failure atomicity, numeric/non-whitespace/NUL indentation, normal/safe
unsupported roots and members, compacted arrays, empty versus all-skipped
containers, holes, integer cdata, preserved key/number/sparse/cycle/depth errors,
all nine source/loading combinations, dirty/fork/keep_origin/mixed values,
comments/duplicates, reader snapshots and one/seven-byte output chunks.

The focused deep case at `tests/lua/cjson_indent_skip_spec.lua:226` rejects reader
indent/concat temporaries above its output bound. The file/feed cases at line
249 trap scalar materialization and bound source reads; cases at line 272 stop
GC and assert descriptor/lease cleanup for failure and suspended cancellation.
These tests exercise meaningful behavioral and resource contracts rather than
merely mirroring the new setter implementations.

No tests, builds, benchmarks or oracle processes were rerun for this review: the
targeted source checks resolved the concrete doubts without requiring a probe.
The parent's already-completed gates are accepted as supplied verification
evidence, not represented as independent reviewer executions: Rust
444/444/445, clean Clippy, Lua 607, lint 84 files, HTTP 60, 9 x 164 upstream
records, loading 18, installed-only smoke and independent native comparisons.
The parent reports source hashes matched the final runtime/matrix evidence.

The matrix still has its documented F05/F06 and F15/F16 differences. RSS remains
32/33 with the wide-scalars/memory sample +84 KiB (about 0.52%); this review does
not turn that failed boundary into a universal memory claim or attribute the
small sample difference causally to F13/F14.

## Final whole-branch integration assessment

At the parent's subsequent request, I assessed integration using the already
reviewed parent verification document and plan, plus `manifest.txt`,
`runtime-source-verified.json` and `native-final.sha256`. The runtime source
review and passing gates were not repeated.

**Verdict: APPROVED for local-main integration after the parent's stated archive
sealing and explicit staging checks.** No open code, design or task-quality
finding remains. This is an integration assessment, not a claim that the
not-yet-sealed archive or a future commit has already been verified.

- The nine current manifest entries are exactly the reviewed three runtime
  files, focused regression test, README, source API document, compatibility
  ledger, implementation plan and verification report. They contain no vendor
  expectation/adaptor changes, Rust changes or unrelated work.
- The source-verification receipt records 51 files with an empty mismatch list.
  Its three changed runtime SHA-256 values match the implementer report's final
  source identities. This supports reuse of the parent's completed runtime and
  matrix gates; it is not a newly executed reviewer test.
- The native hash receipt identifies the same LeanJSON shared-library hash for
  the release build and installed-only copy
  (`8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b`).
  The explicitly loaded pinned cjson reference hash
  (`fd6fd6158e718fbd3608baefbbb655100b07334840a2e814a4f8054aa7e61cac`)
  matches the report's oracle identity. These are checks of the supplied hash
  receipts, not a new binary build or execution.
- The parent report preserves the remaining compatibility failures, native
  differences, historical skip-RED limitation, native-macOS/latency validation
  limits and the 32/33 RSS result. Its completion claims therefore retain their
  practical boundaries.
- `manifest.txt` currently has no archive entry because the archive will be
  sealed after this report returns. Before committing, the parent must add
  `docs/verification/f13-f14-encoding-logs.tar.gz` to the explicit staging manifest
  and verify that the archive includes this final report and corrected evidence
  wording with the intended provenance/hashes. Archive integrity and the final
  staged-path check remain parent-owned mechanical completion steps.

No further source review or suite rerun is warranted for the documentation-only
correction and evidence packaging, provided the reviewed runtime/test files
remain unchanged. Any subsequent source change would require review and
verification proportionate to that change.

## Reviewer scope

Only this assigned report was written. Runtime, tests, product docs, index and
HEAD were not changed. No branch switch, commit, push, subagent, full-suite
rerun, benchmark rerun or runtime probe was performed. Final evidence sealing
and integration belong to the parent gate; this report includes the coupled
runtime task's independent spec/quality review and the subsequently requested
integration assessment.
