### Task 2: Independent acceptance and user documentation (supervisor)

**Files:** README, focused probes/scripts under `tests/openresty` or `scripts`,
`docs/verification/decode-loading-modes.md` and raw evidence, this plan/spec.
**Interfaces:** Task 1 options and documented diagnostics; no private test-only
shortcuts for measured public behavior.

- [ ] Independently verify selected reads perform no source I/O with every index
  disabled; unselected content remains lazy, readable and fully encoded. Verify
  eager results work through ordinary Lua operations and release source ownership.
- [ ] Measure matched eager cjson/LeanJSON wide small-object cases and selective
  large-prompt/message cases, with external typed output oracles and separate CPU/
  RSS reporting. Preserve prior evidence and avoid concurrent builds/measurements.
- [ ] Update README examples and report exact revisions, scopes, selected-memory
  accounting, path limitations and performance tradeoffs. Do not claim a complete
  JSONPath/Schema implementation or universal cjson performance equivalence.
- [ ] Complete independent task/whole-change review and meaningful final checks;
  preserve the local branch/worktree and original raw evidence.
