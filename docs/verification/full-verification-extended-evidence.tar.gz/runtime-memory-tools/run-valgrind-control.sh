#!/usr/bin/env bash
set -u

export DEBIAN_FRONTEND=noninteractive
apt_opts=(
  -o Acquire::ForceIPv4=true
  -o Acquire::http::Timeout=20
  -o Acquire::Retries=1
  -o Acquire::Languages=none
  -o Acquire::PDiffs=false
  -o Acquire::CompressionTypes::Order::=gz
)
apt-get "${apt_opts[@]}" update
apt-get install -y --no-install-recommends "${apt_opts[@]}" \
  luajit valgrind libc6-dbg

DISTRO_LUAJIT=/usr/bin/luajit
echo "luajit_path=$DISTRO_LUAJIT"
"$DISTRO_LUAJIT" -v 2>&1
echo "valgrind_path=$(command -v valgrind)"
valgrind --version
dpkg-query -W -f='${Package} ${Version}\n' luajit valgrind libc6-dbg libluajit-5.1-2 2>&1 || true

export LUA_INIT='if jit then jit.off() end'
set +e
env -u LUA_PATH -u LUA_CPATH \
  LD_LIBRARY_PATH=/workspace/target/release \
  valgrind \
    --trace-children=yes \
    --error-exitcode=1 \
    --leak-check=full \
    --show-leak-kinds=definite,indirect,possible \
    --errors-for-leak-kinds=definite,indirect,possible \
    --num-callers=24 \
    --suppressions=/workspace/valgrind.supp \
    "$DISTRO_LUAJIT" -e 'local s = string.gsub("abc", "a", "b"); assert(s == "bbc"); local t = {}; for i = 1, 100 do t[i] = tostring(i) end; assert(#t == 100); print("control_no_leanjson_ok")'
control_rc=$?
echo "control_valgrind_exit_code=$control_rc"
exit "$control_rc"
