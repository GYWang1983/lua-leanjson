local native=assert(package.loadlib("/workspace/.superpowers/sdd/2026-11-02-cjson-f13-f14/parent-reference/cjson.so", "luaopen_cjson"))()
local ffi=require "ffi"
local values={
 {name="empty-object",make=function(c) return {} end},
 {name="empty-array",make=function(c) return c.empty_array end},
 {name="all-skip-object",make=function() return {x=function() end} end},
 {name="all-skip-array",make=function() return {function() end,coroutine.create(function() end)} end},
 {name="nested-skip",make=function() return {a={function() end}} end},
 {name="array-mixed",make=function(c) return {1,function() end,2,coroutine.create(function() end),c.null,3} end},
 {name="object-mixed",make=function() return {a=1,z=function() end} end},
 {name="root-function",make=function() return function() end end},
 {name="root-thread",make=function() return coroutine.create(function() end) end},
 {name="root-userdata",make=function() return newproxy(true) end},
 {name="root-pointer",make=function() return ffi.new("int[1]") end},
 {name="root-int64",make=function() return ffi.new("int64_t",123) end},
 {name="bad-key-skip",make=function() return {[false]=function() end} end},
 {name="bad-number",make=function() return {0/0,function() end} end},
 {name="sparse",make=function() return {[100]=function() end} end},
 {name="cycle",make=function() local t={};t.a=t;return t end},
 {name="empty-nested",make=function() return {a={b={}}} end},
 {name="nil-root",make=function() return nil end},
 {name="boolean-root",make=function() return false end},
}
local indents={"","  ","\t","abc","\0tail","  \0tail"}
local function result(codec,v)
 local ok,r=pcall(codec.encode,v)
 return ok,r
end
local checks,mismatches=0,0
local target
if arg[1]=="compare" then target=require "leanjson" end
for _,indent in ipairs(indents) do for _,skip in ipairs({false,true}) do for _,case in ipairs(values) do
 local c=native.new();c.encode_indent(indent);c.encode_skip_unsupported_value_types(skip)
 local ok,want=result(c,case.make(c))
 if target then
  local j=target.new();j.encode_indent(indent);j.encode_skip_unsupported_value_types(skip)
  local got_ok,got=result(j,case.make(j))
  if case.name=="root-int64" then
   print("PRESERVED_CDATA_EXTENSION",string.format("%q",indent),skip,ok,string.format("%q",want),got_ok,string.format("%q",got))
  elseif ok~=got_ok or want~=got then
   mismatches=mismatches+1;print("MISMATCH",case.name,string.format("%q",indent),skip,ok,string.format("%q",want),got_ok,string.format("%q",got))
  end
 else print(case.name,string.format("%q",indent),skip,ok,string.format("%q",want)) end
 checks=checks+1
end end end
print("ORACLE_CHECKS",checks,"MISMATCHES",mismatches)
assert(mismatches==0)
