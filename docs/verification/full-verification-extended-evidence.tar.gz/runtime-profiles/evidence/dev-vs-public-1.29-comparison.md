# Development-image versus public 1.29.2.4 identity

The primary 802-Busted/72-HTTP run used `lua-qjson-dev:task3-repro`, not the
separate exact-commit runtime image. The dev image ID is
`sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`.

The public stock image is
`openresty/openresty:1.29.2.4-0-jammy`, local ID
`sha256:6e7cc7910d6bd4c7e2cdd3e23e9f17c8217062d50794e6be54791ba7d5620862`,
repo digest
`openresty/openresty@sha256:0a887716d1bc7a3d38e6a765e4c9df31a4b4e27473fc30def6601511330c7f2f`.

Both images are Linux/arm64, carry the OpenResty `1.29.2.4-jammy-arm64`
base labels, and have identical first four rootfs layers. The dev image has
five additional tool/source layers; therefore this is same-runtime development
image evidence, not exact whole-image identity and not a literal stock-image
full-profile run.

Read-only container probes also matched the runtime binaries exactly:

| Path | SHA-256 in both images |
| --- | --- |
| `/usr/local/openresty/bin/resty` | `3bed9cbb56d948f7426f13492bb48d9db64be763328f5b7b0e1a92dfab57ab63` |
| `/usr/local/openresty/luajit/bin/luajit` | `f01956cada29a681852e97ace4e6b3acb43ea9a203cb11438b47cbdc57bb35d3` |
| `/usr/local/openresty/nginx/sbin/nginx` | `9aece94267131b5d2fd78c4bb4f6288e1254f13c59b6a00349fa45a4182e91a1` |
| `/usr/local/openresty/luajit/lib/libluajit-5.1.so` | `fb5237f546147606a660124236c67bd056e44627c47640c6742b7779cb9fdb64` |

Both probes printed resty 0.29, OpenResty 1.29.2.4, and LuaJIT
2.1.ROLLING. The full-suite counts remain reused primary evidence from the dev
image: Busted 802 successes/0 failures/0 errors/0 pending and HTTP 72/72. The
separate `lua-leanjson-openresty:full-20261103` image (`sha256:08294519…`) was
only built and verified by its image smoke; it must not be cited as the image
that produced those 802/72 counts.
