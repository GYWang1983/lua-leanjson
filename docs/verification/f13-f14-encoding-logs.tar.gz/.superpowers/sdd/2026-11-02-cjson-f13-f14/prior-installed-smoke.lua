local prefix=...
package.path=prefix..'/share/lua/5.1/?.lua;'
package.cpath=prefix..'/lib/lua/5.1/?.so;'
package.preload.cjson=function() error('native cjson denied',0) end
local json=require 'leanjson'
assert(json.decode_allow_comment()==false)
local c=json.new();c.decode_allow_comment(true)
local raw='/*lead*/{"model"/*key*/:/*value*/"seedance","nested":{/*empty*/},"n":1.00}//tail'
local value=c.decode(raw,{index_depth=0,index_budget_bytes=0,preload_paths={'$.model'}})
c.decode_allow_comment(false)
assert(value.model=='seedance')
local out=c.encode(value);assert(out:find('1.00',1,true));assert(not out:find('/*',1,true));json.close(json.decode(out));c.close(value)
local d=c.new_decoder();c.decode_allow_comment(true);local ok=d:feed('{/*off*/}');assert(ok==nil);d:close()
d=c.new_decoder();c.decode_allow_comment(false);assert(d:feed('{/*on*/"x":1}'));local v=assert(d:finish());assert(v.x==1);c.close(v);d:close()
local s=require('leanjson.safe').new();s.decode_allow_comment(true)
local v,e=s.decode('{}/*unclosed');assert(v==nil and e=='Expected the end but found unclosed multi-line comment at character 13')
assert(s.decode('false//tail')==false)
local f=assert(io.open('/proc/self/maps'));local maps=f:read('*a');f:close()
assert(maps:find(prefix..'/lib/lua/5.1/leanjson.so',1,true));assert(not maps:find('/workspace/target/release/libleanjson.so',1,true))
print('installed-only F10 smoke passed; native cjson denied; installed mapping verified')
