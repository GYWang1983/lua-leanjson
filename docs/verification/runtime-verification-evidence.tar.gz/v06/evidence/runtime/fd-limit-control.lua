local ffi = require("ffi")
ffi.cdef[[
struct v06_rlimit { unsigned long current; unsigned long maximum; };
int getrlimit(int, struct v06_rlimit *);
int setrlimit(int, const struct v06_rlimit *);
int open(const char *, int, ...);
int close(int);
]]
local limit = ffi.new("struct v06_rlimit[1]")
assert(ffi.C.getrlimit(7, limit) == 0)
print("initial soft limit", tonumber(limit[0].current))
limit[0].current = 64
assert(ffi.C.setrlimit(7, limit) == 0)
assert(ffi.C.getrlimit(7, limit) == 0)
assert(tonumber(limit[0].current) == 64)
local descriptors = {}
while true do
    local fd = ffi.C.open("/dev/null", 0)
    if fd < 0 then assert(ffi.errno() == 24); break end
    assert(fd < 64, "soft limit did not constrain open")
    descriptors[#descriptors + 1] = fd
end
assert(#descriptors > 0 and #descriptors <= 61)
print("bounded descriptors", #descriptors, "maximum fd", descriptors[#descriptors])
for _, fd in ipairs(descriptors) do assert(ffi.C.close(fd) == 0) end
