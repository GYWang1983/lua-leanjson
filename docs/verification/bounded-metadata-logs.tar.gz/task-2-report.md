# Task 2 acceptance report

Supervisor-owned scope: independent paired native-memory/HTTP acceptance harness, README and verification artifacts. Requirements are Task 2 in docs/plans/2026-11-02-bounded-metadata.md. Runtime implementation belongs to Task 1.

Implemented harness in b21c251,a352050,48c9399,e4e8f1e,0dade0d,faf4353: external fixture generation; same bytes per pair; fresh native processes; no forced GC in measured phases; native RSS/HWM, Lua heap, CPU, phase/cache diagnostics; direct mutation by default; optional two forks; full typed external oracle and escaped duplicate-output rejection; chunk/length/hash checks; runtime native and Lua fingerprints checked before/after; strict per-pair Lean RSS <= cjson criterion. HTTP comparison supports direct mutation and the same wide/short fixtures, preserving legacy benchmark defaults.

Immutable old-runtime file/two-fork baseline: all three semantic oracles pass, all three memory gates fail. Raw records in docs/verification/bounded-metadata-before.jsonl. Post-reclamation runtime1f21ab5: all63/63paired comparisons and4HTTP oracle rows pass; four independentValgrind probes0errors/0suppressed/0bytes. Native and Lua fingerprints, full phase records, exact versions and limits are in docs/verification/bounded-metadata.md and bounded-metadata-{after,http}.jsonl. Root docscommit56d38e3. Task1 review is correcting iteration semantics; these artifacts explicitly measure1f21ab5 and will be refreshed after that runtime fix. Final whole-branch review and exact committed image smoke are integration gates pending Task1; no claim of these in current report.

Focused harness validation completed: Python compilation, direct semantic-oracle typed/null/duplicate/escape tests, Lua harness lint, old-runtime small escaped-duplicate smoke across memory/file/feed, phase/budget assertions and unchanged-runtime fingerprint checks in the measured matrices. Canonical library gate exercises the shared HTTP benchmark fixture modules via lint. No mock allocation measurements or threshold tolerance.

Known limitations documented: finite workload matrix cannot prove universal RSS dominance; process RSS excludes OS page cache/tmpfs; sparse indexes trade CPU and synchronous disk I/O for memory; explicit materialization/user-held values/patches/active work are outside optional metadata budget. Final docs must report actual broad-object latency, not just memory benefits. No current push/publication or Kong work.


## Task 2 supplemental-review fix round 1

Commit: 8e07a36d61b0091dbd2ce4e6560009ace1cdbb8f (fix: isolate cjson benchmarks and forward decode settings), following runtime fix d4ea91c5dc28c8f8c6af922b50772956fede8f0a. Finalized supplemental findings: task-2-review.md. Three explicitly staged paths: tests/openresty/memory-phases.lua, tests/openresty/benchmark-handler.lua, plus the expressly permitted effective-setting assertions in tests/openresty/benchmark.lua. Supervisor README/verification edits were preserved. No runtime bytes, strict thresholds, baseline artifacts or image pinning changed; no push/delegation.

Both Important findings are fixed:

1. The phase script and HTTP handler validate the method before importing LeanJSON. Only Lean cells require the runtime/adapter. Cjson cells assert that leanjson, leanjson.lib and leanjson.openresty are absent from package.loaded, so a contaminated process/worker fails explicitly. The benchmark config skips instrumentation when LEANJSON_RUN_MODE=benchmark; its health endpoint imports only cjson/lfs. A separate HTTP module-state probe verified all three entries absent before and after cjson requests, and present after LeanJSON requests.
2. The handler shares an explicit decoder-options table between opts.decode for adapter.read_body and direct cold decode/decode_file. Chunk/on_chunk settings remain at the supported adapter/reader level too. The real benchmark driver now asserts effective depth, array prefix, budget and retained-byte bound for every timed LeanJSON sample.

Historical records above measured 1f21ab5 with LeanJSON imported in both methods. They do not establish the requested pure-cjson RSS inequality. Corrected strict paired measurements remain supervisor-owned and pending. None of the small focused checks below applies an RSS gate or makes a tiny-input performance/memory guarantee; incidental metrics in their logs are not acceptance evidence.

Red/green checks used lua-qjson-dev:task3-repro, worktree mounted /workspace, target volume leanjson-bounded-target:/workspace/target, /workspace cwd. Ignored scratch helpers preserve exact real-process probes: task-2-fix-phase.lua, task-2-fix-http.sh, task-2-fix-http.lua. The HTTP shell helper starts fresh Nginx/sink processes from the existing templates, adds a module-state endpoint, then closes the processes and temporary prefix. The working helper uses LuaJIT because this pinned image has no Python.

Expected red results before tracked harness edits:

- Phase cjson probe exit 1: ERROR: cjson phase imported LeanJSON, from an armed preload trap (task-2-phase-red.log).
- Fresh HTTP cjson probe exit 1: post-request state was {"adapter":true,"lean":true,"lib":true} (task-2-http-cjson-red.log).
- Fresh HTTP normal zero-options probe exit 1: effective depth 3, array limit 3, budget 1048576 instead of 0/0/0 (task-2-http-options-red.log).

Focused green commands inside the disposable mounted image:

~~~sh
luacheck tests/openresty/memory-phases.lua tests/openresty/benchmark-handler.lua tests/openresty/benchmark.lua
printf %s '{"model":"original","items":[{"id":1}]}' >/tmp/phase-input.json
for method in cjson leanjson; do
  LD_LIBRARY_PATH=/workspace/target/release /usr/local/openresty/bin/resty -I lua -I tests/openresty .superpowers/sdd/2026-11-02-bounded-metadata/task-2-fix-phase.lua "$method" file /tmp/phase-input.json /tmp/phase-output.json model 0 0 0 0
done
LD_LIBRARY_PATH=/workspace/target/release /usr/local/openresty/bin/resty -I lua -I tests/openresty .superpowers/sdd/2026-11-02-bounded-metadata/task-2-fix-phase.lua leanjson file /tmp/phase-input.json /tmp/phase-output.json model 64 0 1 1
bash .superpowers/sdd/2026-11-02-bounded-metadata/task-2-fix-http.sh cjson
bash .superpowers/sdd/2026-11-02-bounded-metadata/task-2-fix-http.sh leanjson
~~~

All exit 0. Lint: 0 warnings /0 errors in three files (task-2-lint.log). Phase module/options/output assertions pass for cjson and both Lean settings (task-2-phase-green.log); the cjson preload trap remains armed, all Lean modules stay absent, and output decodes to model="rewritten-1" with unchanged items[1].id=1. HTTP uses a 128 KiB prompt to force completed-file input. Cjson normal/cold requests keep all three module flags false (task-2-http-cjson-green.log). Four Lean requests, normal/cold at 0/0/0 and 1/1/64, return exactly matching index_stats within their budgets (task-2-http-options-green.log); Lean/lib/adapter flags are true afterward.

The actual driver also exercised small completed-memory input, its effective-setting assertions and complete external output oracle:

~~~sh
export LEANJSON_RUN_MODE=benchmark LEANJSON_BENCH_CASE=prompt LEANJSON_BENCH_BYTES=4096
export LEANJSON_BENCH_CONCURRENCY=1 LEANJSON_BENCH_REQUESTS=1 LEANJSON_BENCH_BRANCHES=0
LEANJSON_BENCH_METHOD=cjson scripts/verify-openresty.sh
LEANJSON_BENCH_METHOD=leanjson LEANJSON_BENCH_INDEX_DEPTH=0 LEANJSON_BENCH_INDEX_ARRAY_LIMIT=0 LEANJSON_BENCH_INDEX_BUDGET_BYTES=0 scripts/verify-openresty.sh
LEANJSON_BENCH_METHOD=leanjson LEANJSON_BENCH_INDEX_DEPTH=1 LEANJSON_BENCH_INDEX_ARRAY_LIMIT=1 LEANJSON_BENCH_INDEX_BUDGET_BYTES=64 scripts/verify-openresty.sh
~~~

Combined exit 0, all three output oracle flags pass (task-2-driver-green.log). These validate imports/settings/output, not RSS ordering. No full suite/build was repeated for harness-only edits. Runtime remains frozen at d4ea91c; corrected final 32768-case native/HTTP acceptance and exact-image checks belong to the supervisor. Optional mutable-image-tag provenance hardening remains deferred per dispatch.
