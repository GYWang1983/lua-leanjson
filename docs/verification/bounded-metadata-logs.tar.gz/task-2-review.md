### Spec Compliance

- ✅ Spec compliant for the Task 2 harness/documentation scope reviewed at `58b0094..56d38e3`. Fixtures, fresh native paired processes, matched edits/forks, external semantics, strict RSS acceptance, baseline failure capture and measured documentation are present (`tests/openresty/benchmark-fixtures.lua:14-35`, `tests/openresty/memory-phases.lua:33-117`, `scripts/verify-memory.py:115-159`, `docs/verification/bounded-metadata.md:27-119`).
- ⚠️ Cannot verify final integration: the evidence explicitly measures runtime `1f21ab56f87327afa968f35536238b19f06182d3`, before the separately reviewed iteration fix (`docs/verification/bounded-metadata.md:49-60`). Refresh functional/memory/HTTP evidence after that fix, then finish the independent whole-branch review, exact committed runtime-image smoke and final diff review. Existing results do not establish those pending gates (`docs/verification/bounded-metadata.md:139-141`, task-2-report.md).
- ⚠️ Cannot verify Task 1 runtime internals from this Task 2 diff: eager validation, exact budget capacity accounting, no hidden DOM/unbounded Lua caches, ABI compatibility, fork/live-child/snapshot/cancellation behavior and resource cleanup remain the runtime review's responsibility. The Task 2 evidence exercises relevant paths but does not prove every global runtime invariant.

### Strengths

- Fixture generation and full semantic comparison are outside each measured native process. Both methods consume the same persisted bytes, perform the same access/edit/fork operations, and preserve the original two-fork baseline separately from default direct mutation (`scripts/verify-memory.py:115-142`, `tests/openresty/memory-phases.lua:54-88`, `docs/verification/bounded-metadata.md:88-92`).
- The Python oracle preserves JSON arrays/objects, nulls, booleans and numeric semantics, rejects extra/missing values, and rejects duplicate output names after JSON escape decoding. Input parsing independently implements last-key-wins expectations (`scripts/verify-memory.py:19-36`, `scripts/verify-memory.py:123-140`). Late/escaped duplicate fixtures exercise lazy frontiers and wide objects (`tests/openresty/benchmark-fixtures.lua:14-35`).
- The measured phases include parse/read/mutation/length/output/close, with no forced GC after baseline; source index capacity is asserted against its budget and LeanJSON output length/chunks are checked (`tests/openresty/memory-phases.lua:16-24`, `tests/openresty/memory-phases.lua:33-53`, `tests/openresty/memory-phases.lua:91-126`). The gate uses exact per-pair RSS ordering without tolerance; report-only mode preserves failure status in receipts (`scripts/verify-memory.py:143-163`).
- Current mounted-runtime measurement records both native and Lua fingerprints and rejects changes across a matrix (`scripts/verify-memory.py:83-89`, `scripts/verify-memory.py:156-157`). The docs identify the measured revision and distinguish the development image revision from the mounted runtime (`docs/verification/bounded-metadata.md:49-58`).
- Memory claims are bounded and CPU/I/O costs are prominent: caller-held/active storage and page-cache/tmpfs boundaries are explicit, the old baseline is compared with the matching fork configuration, and the wide-object HTTP slowdown and syscall counts are disclosed (`README.md:160-176`, `README.md:216-247`, `docs/verification/bounded-metadata.md:88-119`, `docs/verification/bounded-metadata.md:178-187`).

### Issues

#### Critical (Must Fix)

- None found in the reviewed Task 2 scope.

#### Important (Should Fix)

- None found in the reviewed Task 2 scope.

#### Minor (Nice to Have)

- `scripts/verify-memory.py:79-89`, `scripts/verify-memory.py:99-104`: `--runtime-image` records an image ID but continues launching the supplied image reference and leaves its Lua fingerprint null. If a mutable local tag were reassigned during a future packaged-runtime measurement while retaining the same native library, the final fingerprint comparison would miss different Lua code. Resolve the image ID before assembling Docker commands and run every measurement/fingerprint container by that ID; recording a packaged Lua-tree digest would further clarify provenance. This does not invalidate the archived baseline or the 63 mounted-runtime pairs: there is no evidence of tag mutation in the baseline, and all current pairs record both native and Lua hashes.

### Checks Performed

- Read the supplied Task 2 diff in one review pass; the initial tool response truncated the README/report/Python sections, so only those omitted sections were retrieved to complete the pass. No changed source file was separately reread, no runtime source was inspected, and no git commands, suites, benchmarks or builds were run.
- Programmatically inspected `docs/verification/bounded-metadata-before.jsonl:1-7`: three matched file/two-fork pairs, six passing semantic receipts, three strict memory failures; documented baseline peaks agree.
- Programmatically inspected `docs/verification/bounded-metadata-after.jsonl:1-130`: four environment records and 126 process rows yield 33 + 9 + 12 + 9 = 63 matched pairs. Every pair matches case/source/input hash/input length, all 126 oracle flags pass, all 63 strict RSS gates pass, every recorded phase index fits its budget, HWM summaries equal the phase maxima, and every LeanJSON maximum chunk is at most 65,536 bytes. Traversal visit counts match between methods. All four environment records identify `1f21ab5` and the same native/Lua fingerprints.
- Programmatically inspected `docs/verification/bounded-metadata-http.jsonl:1-4`: four passing oracle receipts, identical per-shape paired payload hashes/lengths, branches 0, concurrency 2 and six timed requests per row. RSS/p50 figures and the approximately 2.7 million write/5.6 million read syscalls agree with the documentation.
- Read the referenced selected check receipts in `docs/verification/bounded-metadata-checks.txt`: recorded functional/lint/property/stress/HTTP summaries and four Valgrind summaries support the report at `1f21ab5`; no suite was rerun. These receipts are historical evidence, not verification of the pending integration fix.

### Assessment

**Task quality:** Approved, with the minor provenance hardening above.

**Reasoning:** The harness supports fair, strict paired acceptance and the documentation accurately presents the measured memory improvement together with its substantial CPU/I/O cost. Approval is task-scoped; the fixed-runtime refresh and final integration gates remain unverified.


## Supplemental review: cjson process baseline and HTTP option forwarding

### Spec Compliance

- ❌ Issues found. This supplement supersedes the earlier task approval: the native cjson comparison process eagerly imports LeanJSON, and the HTTP benchmark does not apply nondefault decoder index settings through the adapter. Both are Task 2 harness defects.
- ⚠️ Cannot verify corrected acceptance until the controller applies these harness fixes, completes the separately owned runtime iteration fix, refreshes the relevant process/HTTP evidence, and finishes the previously listed whole-branch/exact-image integration gates. No measurement was rerun for this supplement.

### Strengths

- The existing records remain useful historical evidence of the code actually executed: paired fixture bytes, operations, typed external semantic checks and strict numerical RSS ordering remain as previously checked. The two defects below narrow what those measurements establish; they do not demonstrate a semantic failure or prove that any particular corrected RSS row will fail.
- The four recorded HTTP rows use defaults, which equal the adapter defaults, so the option-forwarding defect does not itself change the actual decoder settings in those four rows (`docs/verification/bounded-metadata-http.jsonl:1-4`). Their cjson process baseline still has the import issue below.

### Issues

#### Critical (Must Fix)

- None found in this supplemental scope.

#### Important (Should Fix)

1. `tests/openresty/memory-phases.lua:3-6`; `tests/openresty/benchmark-handler.lua:1-7`: the cjson method unconditionally loads `leanjson` (and, for HTTP, `leanjson.openresty`) before measuring. This is a real process-baseline contamination: `lua/leanjson.lua:1-13` imports `leanjson.lib` and allocates FFI state, and `lua/leanjson/lib.lua:224-229` loads the native library and resolves its symbols. Module state remains retained through `package.loaded`; the native library is loaded in the cjson process even though cjson does not use it. Consequently the gate compares against cjson running with LeanJSON loaded, rather than the requested native cjson process total RSS. Equal shared import overhead does not establish the desired pure-cjson total-RSS inequality. The amount of resident-memory bias is unmeasured, so it would be incorrect either to declare that the tight wide-scalar rows fail or to accept them unchanged. **Fix:** determine the method before imports and require LeanJSON and its adapter only in LeanJSON cells; verify that the fresh cjson HTTP worker has no other eager LeanJSON preload. Refresh the paired process/HTTP measurements after this change and the pending runtime fix, retaining the original records with their actual methodology. If a required corrected row exceeds native cjson, pass the measurements to Task 1 without relaxing the threshold. Revise the native-cjson acceptance claims until that evidence exists (`README.md:216-247`, `docs/verification/bounded-metadata.md:7-24`, `docs/verification/bounded-metadata.md:60-119`).

2. `tests/openresty/benchmark-handler.lua:17-21`, `tests/openresty/benchmark-handler.lua:46`: the handler places `index_depth`, `index_array_limit` and `index_budget_bytes` at the root of `opts` and passes that table to `adapter.read_body`. The adapter's unchanged `options()` only normalizes/copies `opts.decode`, then applies its specific chunk/on_chunk/temp_dir overrides (`lua/leanjson/openresty.lua:11-24`); `read_body` forwards that normalized decoder table (`lua/leanjson/openresty.lua:95-98`). The root index fields therefore disappear on the normal HTTP path. Nondefault values requested through the new benchmark environment/query options silently run the defaults, while reported requested values imply otherwise. **Fix:** create an explicit decoder-options table containing the three index settings, pass it as `opts.decode` to the adapter, and pass the same decoder settings to the direct cold decode/decode_file path. Retain adapter I/O/reader options at their supported level. Add a focused HTTP assertion that a request for zero or tiny/nondefault settings yields matching `sample.index_stats` effective settings/budget; run that check during controller-owned integrated validation. Current defaults-only HTTP records do not cover this defect.

#### Minor (Nice to Have)

- The packaged-image provenance hardening from the original review remains applicable; it does not replace either Important fix.

### Checks Performed

- Named risk: loading LeanJSON changes the purported cjson process baseline. Inspected only the LeanJSON module import/FFI allocation preamble and native `ffi.load`/symbol-resolution chain; the existing process metrics read `/proc/self/status` total RSS/HWM (`tests/openresty/metrics.lua:2-7`). No resident-memory amount was measured, and no runtime implementation behavior was reviewed.
- Named risk: HTTP nondefault options are silently ignored. Inspected only the adapter `options()`, `read_body()` forwarding and the corresponding `start_body()` normalized decoder call chain (`lua/leanjson/openresty.lua:11-24`, `lua/leanjson/openresty.lua:95-98`, `lua/leanjson/openresty.lua:164-183`). No suites, builds, benchmarks, git commands or source changes were performed.

### Assessment

**Task quality:** Needs fixes.

**Reasoning:** The strict gate's numerical logic is sound, but the cjson baseline must exclude LeanJSON modules/native loading to support the requested total-RSS comparison. HTTP option forwarding must also be corrected before the advertised nondefault acceptance configurations can be trusted; fixed-runtime measurement and final integration remain pending.
