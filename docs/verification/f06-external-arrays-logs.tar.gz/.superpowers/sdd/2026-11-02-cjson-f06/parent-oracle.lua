local n=assert(package.loadlib('/workspace/.superpowers/sdd/2026-11-02-cjson-f06/parent-reference/cjson.so','luaopen_cjson'))()
local j=require 'leanjson'
local ffi=require 'ffi'
local cases={}
local function add(name,make) cases[#cases+1]={name=name,make=make} end
for _,v in ipairs({0,-1,1,2,3,1.9,-1.9,'2.8','0x2','invalid','2\0tail',false,true}) do
 local value=v;add('length-'..tostring(v),function(c,trace) return setmetatable({}, {__len=function(t) assert(type(t)=='table');trace[#trace+1]='len';return value end,__index=function(_,k) trace[#trace+1]='i'..k;return ({'foo',false,c.null})[k] end}) end)
end
add('nil-length',function() return setmetatable({}, {__len=function() return nil end}) end)
add('table-length',function() return setmetatable({}, {__len=function() return {} end}) end)
add('cdata-length',function() return setmetatable({}, {__len=function() return ffi.new('int',2) end}) end)
add('false-method',function() return setmetatable({}, {__len=false}) end)
add('number-method',function() return setmetatable({}, {__len=2}) end)
add('len-error',function() return setmetatable({}, {__len=function() error('length-boom',0) end}) end)
add('index-error',function() return setmetatable({}, {__len=function() return 2 end,__index=function() error('index-boom',0) end}) end)
add('holes',function() return setmetatable({}, {__len=function() return 3 end,__index={[2]='x'}}) end)
add('hash-ignored',function() return setmetatable({extra='ignored',[100]='hidden'}, {__len=function() return 2 end,__index={'x','y'}}) end)
add('protected',function() return setmetatable({}, {__metatable='hidden',__len=function() return 1 end,__index={'x'}}) end)
add('callable',function() return setmetatable({}, {__len=setmetatable({}, {__call=function(_,t) assert(type(t)=='table');return 2 end}),__index={'x','y'}}) end)
add('inherited',function() return setmetatable({},setmetatable({}, {__index={__len=function() error('not raw',0) end}})) end)
add('index-only',function() return setmetatable({[1]='a',[3]='c'}, {__index={[2]='b'}}) end)
add('nested',function(c,trace) local child=cases[5].make(c,trace);return {child} end)
add('unsupported-element',function() return setmetatable({}, {__len=function() return 3 end,__index={1,function() end,3}}) end)
local count,bad=0,0
for _,indent in ipairs({'','  ','abc'}) do for _,skip in ipairs({false,true}) do for _,case in ipairs(cases) do
 local a,b=n.new(),j.new();a.encode_indent(indent);b.encode_indent(indent);a.encode_skip_unsupported_value_types(skip);b.encode_skip_unsupported_value_types(skip)
 local ta,tb={},{};local va,vb=case.make(a,ta),case.make(b,tb)
 local ao,av=pcall(a.encode,va);local bo,bv=pcall(b.encode,vb)
 count=count+1
 if ao~=bo or av~=bv or table.concat(ta,',')~=table.concat(tb,',') then
  bad=bad+1;print('MISMATCH',case.name,string.format('%q',indent),skip,ao,string.format('%q',tostring(av)),bo,string.format('%q',tostring(bv)),'trace',table.concat(ta,','),table.concat(tb,','))
 end
end end end
print('PARENT_ORACLE',count,'MISMATCHES',bad);assert(bad==0)
