local function gen_raw_octets()
    local chars = {}
    for i = 0, 255 do chars[i + 1] = string.char(i) end
    return table.concat(chars)
end

-- Generate every UTF-16 codepoint, including supplementary codes
local function gen_utf16_escaped()
    -- Create raw table escapes
    local utf16_escaped = {}
    local count = 0

    local function append_escape(code)
        local esc = ('\\u%04X'):format(code)
        table.insert(utf16_escaped, esc)
    end

    table.insert(utf16_escaped, '"')
    for i = 0, 0xD7FF do
        append_escape(i)
    end
    -- Skip 0xD800 - 0xDFFF since they are used to encode supplementary
    -- codepoints
    for i = 0xE000, 0xFFFF do
        append_escape(i)
    end
    -- Append surrogate pair for each supplementary codepoint
    for high = 0xD800, 0xDBFF do
        for low = 0xDC00, 0xDFFF do
            append_escape(high)
            append_escape(low)
        end
    end
    table.insert(utf16_escaped, '"')

    return table.concat(utf16_escaped)
end

function load_testdata()
    local data = {}

    -- Data for 8bit raw <-> escaped octets tests
    data.octets_raw = gen_raw_octets()
    data.octets_escaped = util.file_load("octets-escaped.dat")

    -- Data for \uXXXX -> UTF-8 test
    data.utf16_escaped = gen_utf16_escaped()

    -- Load matching data for utf16_escaped
    local utf8_loaded
    utf8_loaded, data.utf8_raw = pcall(util.file_load, "utf8.dat")
    if not utf8_loaded then
        data.utf8_raw = "Failed to load utf8.dat - please run genutf8.pl"
    end

    data.table_cycle = {}
    data.table_cycle[1] = data.table_cycle

    local big = {}
    for i = 1, 1100 do
        big = { { 10, false, true, json.null }, "string", a = big }
    end
    data.deeply_nested_data = big

    return data
end

function test_decode_cycle(filename)
    local obj1 = json.decode(util.file_load(filename))
    local obj2 = json.decode(json.encode(obj1))
    return util.compare_values(obj1, obj2)
end

-- Set up data used in tests
local Inf = math.huge;
local NaN = math.huge * 0;

local testdata = load_testdata()


util.run_test_group({
    { "Set decode_invalid_numbers(true)",
      json.decode_invalid_numbers, { true }, true, { true } },

    { "Decode hexadecimal",
      json.decode, { '0x6.ffp1' }, true, { 13.9921875 } },

    { "Decode numbers with leading zero",
      json.decode, { '[ 0123, 00.33 ]' }, true, { { 123, 0.33 } } },

    { "Decode +-Inf",
      json.decode, { '[ +Inf, Inf, -Inf ]' }, true, { { Inf, Inf, -Inf } } },

    { "Decode +-Infinity",
      json.decode, { '[ +Infinity, Infinity, -Infinity ]' },
      true, { { Inf, Inf, -Inf } } },

    { "Decode +-NaN",
      json.decode, { '[ +NaN, NaN, -NaN ]' }, true, { { NaN, NaN, NaN } } },

    { "Decode Infrared (not infinity) [throw error]",
      json.decode, { 'Infrared' },
      false, { "Expected the end but found invalid token at character 4" } },

    { "Decode Noodle (not NaN) [throw error]",
      json.decode, { 'Noodle' },
      false, { "Expected value but found invalid token at character 1" } },

    { "Set decode_invalid_numbers(false)",
      json.decode_invalid_numbers, { false }, true, { false } },

    { "Decode hexadecimal [throw error]",
      json.decode, { '0x6' },
      false, { "Expected value but found invalid number at character 1" } },

    { "Decode numbers with leading zero [throw error]",
      json.decode, { '[ 0123, 00.33 ]' },
      false, { "Expected value but found invalid number at character 3" } },

    { "Decode +-Inf [throw error]",
      json.decode, { '[ +Inf, Inf, -Inf ]' },
      false, { "Expected value but found invalid token at character 3" } },

    { "Decode +-Infinity [throw error]",
      json.decode, { '[ +Infinity, Infinity, -Infinity ]' },
      false, { "Expected value but found invalid token at character 3" } },

    { "Decode +-NaN [throw error]",
      json.decode, { '[ +NaN, NaN, -NaN ]' },
      false, { "Expected value but found invalid token at character 3" } },

    { 'Set decode_invalid_numbers("on")',
      json.decode_invalid_numbers, { "on" }, true, { true } },

    { "Set encode_invalid_numbers(false)",
      json.encode_invalid_numbers, { false }, true, { false } },

    { "Encode NaN [throw error]",
      json.encode, { NaN },
      false, { "Cannot serialise number: must not be NaN or Infinity" } },

    { "Encode Infinity [throw error]",
      json.encode, { Inf },
      false, { "Cannot serialise number: must not be NaN or Infinity" } },

    { "Set encode_invalid_numbers(\"null\")",
      json.encode_invalid_numbers, { "null" }, true, { "null" } },

    { "Encode NaN as null",
      json.encode, { NaN }, true, { "null" } },

    { "Encode Infinity as null",
      json.encode, { Inf }, true, { "null" } },

    { "Set encode_invalid_numbers(true)",
      json.encode_invalid_numbers, { true }, true, { true } },

    { "Encode NaN",
      json.encode, { NaN }, true, { "NaN" } },

    { "Encode +Infinity",
      json.encode, { Inf }, true, { "Infinity" } },

    { "Encode -Infinity",
      json.encode, { -Inf }, true, { "-Infinity" } },

    { 'Set encode_invalid_numbers("off")',
      json.encode_invalid_numbers, { "off" }, true, { false } },

    { "Encode all octets (8-bit clean)",
      json.encode, { testdata.octets_raw }, true, { testdata.octets_escaped } },

    { "Decode all escaped octets",
      json.decode, { testdata.octets_escaped }, true, { testdata.octets_raw } },


})
