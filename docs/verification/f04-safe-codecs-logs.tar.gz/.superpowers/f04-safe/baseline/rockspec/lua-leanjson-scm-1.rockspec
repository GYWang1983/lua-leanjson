package = "lua-leanjson"
version = "scm-1"
supported_platforms = { "linux", "macosx" }

source = {
    url = "git+https://github.com/GYWang1983/lua-leanjson.git",
    branch = "feat/openresty-json-source",
}

description = {
    summary = "Memory-conscious JSON processing for LuaJIT and OpenResty",
    detailed = [[
        LeanJSON is a Rust-implemented JSON decoder exposed to LuaJIT through FFI,
        forked from https://github.com/api7/lua-qjson.
        It provides source-backed mutation, independent forks, file and
        incremental sources, and bounded output for large JSON payloads while
        reading only the fields needed by LuaJIT and OpenResty callers.
    ]],
    homepage = "https://github.com/GYWang1983/lua-leanjson",
    license = "Apache-2.0",
}

dependencies = {
    "lua == 5.1",
}

build = {
    type = "command",
    build_command = "CARGO_TARGET_DIR=target cargo build --locked --release",
    install_command = [[
        set -e
        mkdir -p "$(LUADIR)/leanjson" "$(LIBDIR)"
        cp lua/leanjson.lua "$(LUADIR)/leanjson.lua"
        cp lua/leanjson/lib.lua "$(LUADIR)/leanjson/lib.lua"
        cp lua/leanjson/table.lua "$(LUADIR)/leanjson/table.lua"
        cp lua/leanjson/nodes.lua "$(LUADIR)/leanjson/nodes.lua"
        cp lua/leanjson/proxy.lua "$(LUADIR)/leanjson/proxy.lua"
        cp lua/leanjson/reader.lua "$(LUADIR)/leanjson/reader.lua"
        cp lua/leanjson/source_backend.lua "$(LUADIR)/leanjson/source_backend.lua"
        cp lua/leanjson/source_memory.lua "$(LUADIR)/leanjson/source_memory.lua"
        cp lua/leanjson/source.lua "$(LUADIR)/leanjson/source.lua"
        cp lua/leanjson/source_io.lua "$(LUADIR)/leanjson/source_io.lua"
        cp lua/leanjson/path.lua "$(LUADIR)/leanjson/path.lua"
        cp lua/leanjson/leases.lua "$(LUADIR)/leanjson/leases.lua"
        cp lua/leanjson/options.lua "$(LUADIR)/leanjson/options.lua"
        cp lua/leanjson/loading.lua "$(LUADIR)/leanjson/loading.lua"
        cp lua/leanjson/openresty.lua "$(LUADIR)/leanjson/openresty.lua"
        lib=target/release/libleanjson.so
        if [ ! -f "$lib" ]; then lib=target/release/libleanjson.dylib; fi
        if [ ! -f "$lib" ]; then echo "leanjson native library not found"; exit 1; fi
        cp "$lib" "$(LIBDIR)/leanjson.so"
    ]],
}
