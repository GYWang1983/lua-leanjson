# Final delivery review

Read-only review of the rendered `docs/verification/full-verification.md`,
README verification sections, compatibility-list introduction, and the
runtime-memory/runtime-profile receipts and raw logs. No test, build, Docker,
benchmark, or other gate was run; no report was edited by this review.

## Verified runtime boundaries

- Rolling OpenResty LuaJIT: 802/0/0/0 Busted observation and zero Memcheck
  error summaries/no definite-indirect-possible leaks, but the wrapper then
  executed `--lpath=./lua/?.lua` as a command and both recorded exits were
  127. The report correctly records this as a wrapper failure, not a pass.
- Ubuntu Jammy distro LuaJIT beta3 package: instrumented 785/14/0/3 with
  PID 382 reporting 4,044,609 errors in 28 contexts and no leak categories;
  uninstrumented 792/7/0/3 with exit 1. The no-LeanJSON/cjson control still
  reports one LuaJIT uninitialized-value context and exit 1, so it does not
  exonerate the full suite.
- The seven uninstrumented failures match the raw log exactly:

  | raw identity | observed vs expected |
  | --- | --- |
  | `cjson_external_arrays_spec.lua:77` | `["a","b"]` vs `[]` for embedded-NUL external length |
  | `cjson_settings_spec.lua:27` | `0` vs `-0` |
  | `cjson_source_numeric_bytes_spec.lua:119` | `Inf` vs `-Inf` |
  | `strict_userdata_spec.lua:160` (closed table) | `true` vs `false` native-`ipairs` ownership result |
  | `strict_userdata_spec.lua:149` (empty userdata object) | type rejection / false vs expected empty traversal / true |
  | `strict_userdata_spec.lua:149` (object with string key `"1"`) | same userdata type rejection / false vs true |
  | `strict_userdata_spec.lua:160` (closed userdata) | native type error / false vs expected true |

- Runtime-profile boundaries are correct: 1.21 is a 19-assertion smoke only;
  1.27 has no test execution because the ARM64 image never committed; the
  primary 802 Busted/72 HTTP counts are from dev image
  `sha256:1a287857…`; exact-commit runtime image `sha256:08294519…` only has
  four image smoke checks plus malformed-input rejection. Public 1.29 probes
  establish same-runtime binary/base-layer identity, not a stock-image full
  suite.

## Documentation review

The rendered report now preserves the requested non-green boundaries, the
explicit seven-failure table, the rolling-Valgrind-127 distinction, the
1.27 provisioning block, and the dev-image-versus-runtime-image comparison.
README current-limit and compatibility sections qualify finite RSS results,
retain the 7-fail/3-pending distro result, and point to the fresh report.
The compatibility-list introduction separates current results from historical
F01–F18 measurements and keeps the fixed-commit historical link.

Two packaging-only items remain visible:

1. `full-verification.md:273` still contains the `<!-- EVIDENCE_NAVIGATION -->`
   marker. Before sealing, replace it with links/index entries for the primary,
   runtime-memory-tools, and runtime-profiles evidence.
2. Runtime text currently names bare paths such as
   `runtime-memory-tools/receipts.json`, `runtime-profiles/receipts.json`, and
   `evidence/dev-vs-public-1.29-comparison.md` (lines 234 and 245). These do
   not resolve from the current `docs/verification/` directory until the final
   archive layout supplies the corresponding paths; the navigation section
   should make that mapping explicit.

Minor wording caution: raw rolling Valgrind summaries include some
“still reachable” bytes even though definite/indirect/possible leak categories
are zero. “No definite/indirect/possible leaks” is safer than an unqualified
“no leaks” in any final prose. This is a precision issue, not a count or result
contradiction.


## Parent closure after final spot-check

The observations above describe the pre-packaging report. The final report now
contains the evidence navigation and explicit archive path mapping; the two
packaging items are closed. A subsequent independent spot-check verified the
6,254 internal file hashes in the first extended archive and the external
checksums. It also confirmed the final report scopes zero leaks to the
definite/indirect/possible lost categories and separately records still-reachable
memory.

That spot-check identified imprecise wording in the archived tooling summary.
The parent has now qualified those phrases in `runtime-memory-tools/tooling-report.md`
and resealed the archive. Raw test logs, counts, exits and assertions remain
unchanged. The final archive identity is in the delivered report and external
`SHA256SUMS`; the earlier archive hash is not its final identity.
