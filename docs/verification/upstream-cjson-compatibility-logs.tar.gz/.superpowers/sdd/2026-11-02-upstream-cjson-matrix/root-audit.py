"""Independent supervisor reconciliation; run after the complete matrix."""
import collections
import hashlib
import json
from pathlib import Path

scratch = Path(__file__).resolve().parent
artifacts = scratch / "task-1-artifacts" / "final"
expected = json.loads((scratch / "root-inventory.json").read_text())
inventory = json.loads((artifacts / "inventory.json").read_text())
cases = inventory["cases"]
assert len(cases) == 164
assert [c["line"] for c in cases if c["suite"] == "test.lua"] == [c["line"] for c in expected["test_lua_rows"]]
assert [c["line"] for c in cases if c["suite"] == "agentzh.t"] == [c["line"] for c in expected["agentzh_blocks"]]
assert sorted(c["line"] for c in cases if c["category"] == "helper") == expected["expected_helper_lines"]
assert {c["source"].removeprefix("vendor/lua-cjson/"): c["definition_sha256"] for c in cases if c["suite"] == "decode-cycle"} == expected["json_cycle_fixtures"]
for path, digest in expected["suite_sha256"].items():
    assert inventory["source_sha256"][path] == digest, path

provenance = json.loads((artifacts / "provenance.json").read_text())
utf8 = json.loads((scratch / "root-utf8-oracle.json").read_text())
for key in ("bytes", "md5", "sha256"):
    assert provenance["utf8"][key] == utf8[key], key
assert provenance["upstream_commit"] == expected["upstream_commit"]
assert hashlib.sha256((artifacts / "native-reference.so").read_bytes()).hexdigest() == provenance["native_library_sha256"]
assert provenance["locale"]["setlocale_probe"] == "cs_CZ"
for name, digest in json.loads((scratch / "locale/provenance.json").read_text())["locale_files_sha256"].items():
    assert provenance["locale"]["source_files_sha256"][name] == digest, name

summary = json.loads((artifacts / "summary.json").read_text())
wanted_ids = {c["id"] for c in cases}
assert len(wanted_ids) == 164
audited = {}
paths = {"memory": "leanjson.decode", "file": "leanjson.decode_file", "feed": "leanjson.new_decoder:feed:finish"}
for mode in ("lazy", "eager", "preload"):
    for source in ("memory", "file", "feed"):
        cell = mode + "-" + source
        records = [json.loads(line) for line in (artifacts / "matrix" / cell / "records.jsonl").read_text().splitlines()]
        assert len(records) == 164 and {r["id"] for r in records} == wanted_ids, cell
        assert all(r["cell"] == cell for r in records), cell
        counts = dict(collections.Counter(r["classification"] for r in records))
        assert counts == summary["matrix"][cell]["classifications"], cell
        for record in records:
            assert record["cleanup"]["errors"] == [], (cell, record["id"])
            for call in record.get("dispatch", []):
                assert call["actual_path"] == paths[source], (cell, record["id"])
                if mode == "eager":
                    assert call["options"]["lazyload"] is False
                if mode == "preload":
                    assert call["options"]["preload_paths"] == ["$"]
                    for key in ("index_depth", "index_array_limit", "index_budget_bytes"):
                        assert call["options"][key] == 0
                if source == "feed":
                    assert call["decoder_closed"] is True
        audited[cell] = counts

result = {"independent_inventory": True, "independent_utf8_fixture": True,
          "baseline_binary_hash": True, "complete_matrix_records": 9 * 164,
          "source_dispatch_and_cleanup": True, "classification_totals": audited}
(scratch / "root-audit-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
