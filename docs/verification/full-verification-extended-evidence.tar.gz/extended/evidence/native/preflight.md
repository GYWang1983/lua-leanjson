# Extended verification preflight

Recorded: 2026-11-03T09:58:46Z (2026-11-03 01:58:46 PST)

## Scope and safety boundary

- Repository: `/Users/wanggy/Projects/lua-qjson`
- Branch: `verify/full-suite-2026-11-03`
- HEAD: `33d00b522d87cc760f757404186488453ffcb498`
- No build, install, test, benchmark, fuzz, Miri, ASan, Valgrind, or Docker
  run/build was started during this preflight.
- No tracked files were changed by this subtask. The only intended artifact is
  this file under the task-owned `.superpowers/sdd/2026-11-03-full-verification/extended/`
  scratch directory.
- Parent primary work is concurrent. Extended runs must use isolated target,
  fuzz, and report paths and must not overwrite the primary target.

## Repository and canonical entry points

Present: `Makefile`, `Cargo.toml`, `Cargo.lock`, `fuzz/`,
`scripts/verify-bounded-fuzz.sh`, `.github/scripts/run-openresty-runtime.sh`,
`.github/scripts/installed-package-smoke.lua`, and the CI workflows for CI,
fuzzing, full LuaJIT Valgrind, and supply-chain audit.

The bounded helper is at `scripts/verify-bounded-fuzz.sh` (the audit's
`.github/scripts/verify-bounded-fuzz.sh` spelling is not present). It runs all
six targets: `fuzz_parse_eager`, `fuzz_parse_lazy`, `fuzz_ffi_ops`,
`fuzz_depth`, `fuzz_numbers`, and `fuzz_source_windows`. The source-window
target uses the parse-eager seed corpus and `-max_len=16384`.

Canonical CI definitions were read without execution:

- `.github/workflows/ci.yml`: nightly fuzz replay, Miri four FFI tests on
  x86_64/i686/powerpc64, three ASan FFI tests, and OpenResty matrix.
- `.github/workflows/fuzz.yml`: cargo-fuzz 0.13.2 and timed target wrapper.
- `.github/workflows/lua-valgrind-full.yml`: upstream LuaJIT 2.1.0-beta3,
  JIT disabled, full `tests/lua` Busted suite, and exact `valgrind.supp`
  invocation.
- `.github/workflows/supply-chain-audit.yml`: `cargo audit`.
- `.github/scripts/run-openresty-runtime.sh`: pinned runtime harness; it
  prints `resty -V` and LuaJIT version and runs smoke or full Busted according
  to `OPENRESTY_FULL_BUSTED`.

## Host inventory (read-only)

| Capability | Result |
| --- | --- |
| Host | Darwin 27.0, arm64 (`hw.optional.arm64=1`) |
| Apple clang | Present per audit; not re-run in this lightweight pass |
| GNU make | Present per audit |
| Docker CLI/server | 29.8.2 / 29.8.2; context `orbstack` |
| `cargo`, `rustc`, `rustup` on PATH | Absent |
| `$HOME/.cargo/bin/{cargo,rustc,rustup,cargo-fuzz,cargo-audit}` | Absent |
| `$HOME/.rustup/toolchains` | Absent |
| LuaJIT, Busted, Luacheck, OpenResty/resty, nginx | Absent on PATH and checked absolute candidates |
| LuaRocks | `/opt/homebrew/bin/luarocks`, 3.13.0 (PUC Lua 5.5 host remains invalid for this FFI gate) |
| `cargo-fuzz`, `cargo-audit`, Valgrind, QEMU, CMake | Absent on PATH and checked candidates |
| Docker image `openresty/openresty:1.29.2.4-0-jammy` | Present locally; image ID `sha256:6e7cc7910d6bd4c7e2cdd3e23e9f17c8217062d50794e6be54791ba7d5620862`; repo digest `openresty/openresty@sha256:0a887716d1bc7a3d38e6a765e4c9df31a4b4e27473fc30def6601511330c7f2f` |
| Docker images `1.21.4.4-0-jammy`, `1.27.1.2-0-jammy` | Not present locally; pull only after GO if needed |

The Docker daemon is reachable, but no image pull/build/run was attempted.

## Prepared run plan after explicit GO

1. Provision a task-local Rust 1.90.0 toolchain (aligning the primary's
   pinned toolchain) without changing global defaults, then serialize macOS
   release/default, scalar, test-panic, Clippy, release artifact, and an
   isolated LuaRocks installed-package smoke using actual LuaJIT. If LuaJIT or
   the required task-local toolchain cannot be provisioned, record the exact
   blocker rather than substitute PUC Lua 5.5.
2. Provision/use a task-local pinned nightly for cargo-fuzz, Miri, and ASan;
   run six bounded fuzz targets for 30 seconds each and all six seed replays
   (including `fuzz_numbers` and source-window `-max_len=16384`) with first
   failures retained. Use a separate fuzz target directory.
3. Run Miri's four FFI tests across x86_64, i686, and powerpc64 scalar targets
   and strict ASan's three FFI tests, using separate Cargo target storage.
   Report exact unsupported profiles or runtime failures; do not call them
   passes based on another architecture.
4. Run the complete LuaJIT Valgrind command from the workflow with upstream
   LuaJIT 2.1.0-beta3, `LUA_INIT='if jit then jit.off() end'`,
   `valgrind.supp`, and the full `tests/lua` tree. Record tool versions and
   whether execution finishes or times out.
5. Run fresh `cargo audit` and record tool/advisory DB/network provenance
   without changing `Cargo.lock`.
6. Run OpenResty 1.21.4.4-0-jammy (smoke), 1.27.1.2-0-jammy (smoke), and
   1.29.2.4-0-jammy (full only if the primary's pinned-runtime harness is not
   equivalent; otherwise preserve the local immutable ID and report the
   primary result rather than duplicate it). Never silently substitute a
   mutable/current tag for a pinned profile.

Every post-GO command must emit a raw receipt into task-owned
`receipts.json`/`extended-report.md` with command, exit status, count,
duration, tool versions, and source/artifact hashes. No external messages,
GitHub workflow trigger, issue creation, commit, or push is in scope.

## Current blocker summary before GO

The host lacks every native prerequisite for the extended Linux/macOS gates
except Docker, LuaRocks, and the local 1.29 OpenResty image. No extended gate
can be marked pass from this preflight. Provisioning decisions and all heavy
commands are deferred until the parent sends an explicit GO.
