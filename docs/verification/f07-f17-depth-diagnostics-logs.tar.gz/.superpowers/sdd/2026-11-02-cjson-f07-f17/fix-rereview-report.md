# F07/F17 scoped fix re-review

Verdict: **approved for the R1–R4 fix scope; no remaining confirmed findings in those four routes**. The parent still owns completion of the affected integration gates. This pass did not reopen the broader branch review.

Reviewed `fix-review-package.diff`, including its appended `tests/lua/fixtures/sentinel_key_errors.lua`, the original `review-report.md`, `fix-wave-report.md`, the three current Lua runtime changes, and the focused regression files. Read the unchanged array-edit constructor only to verify that actual mutation drops the new sentinel flag. No source edits, builds, full-suite executions, subagents or commits were performed by this reviewer.

## Resolution assessment

| Finding | Status | Evidence and quality assessment |
| --- | --- | --- |
| R1 — fork depth | Resolved | `proxy.fork` forwards the calling codec's `encode_max_depth()` into `M.snapshot`, with the existing1000 fallback for internal codec objects. The regression covers actual depth5000 through ordinary and safe codecs, an exact low boundary and its rejection, plus later encoding of a proxy fork through a different low-limit codec. Existing proxy nodes remain immutable snapshots and are checked at their output depth. |
| R2 — empty-array sentinel | Resolved | Only the `config.empty_array` identity gains `empty_array_sentinel` during snapshot creation. `reader.check_depth` exempts that token; actual Lua tables and source arrays have no such flag and still count. The flag survives immutable fork/overlay/held-child paths. `nodes.array_edit` constructs a fresh ordinary array node without copying the flag, so a real insertion/assignment, and subsequent removal back to empty, cannot retain the exception. The regression checks reader length/output, fork, proxy assignment, held child and mutation, with explicit negative controls for source `[]`, ordinary `{}` and an empty marked array. |
| R3 — scan cancellation | Resolved | The raw-depth loop checks its scope immediately before and after each backend read. A reader closed while the read is suspended now fails the post-read check before scanning returned bytes or requesting another window. The regression deliberately forces the scan and verifies both `next()` and `length()`: one read, no returned bytes, closed error, and a dead coroutine after resumption. |
| R4 — sentinel-key type | Resolved | The common key formatter recognizes only the library's own null/empty-array identities and renders their native `userdata` diagnostic type. It does not change the actual sentinel type or introduce a runtime dependency. The fresh-process fixture denies `cjson`, asserts the fallback identities really are tables, and compares exact messages through ordinary/safe encode, reader and proxy assignment. |

The changes are narrowly scoped to the causes identified in the first review. They reuse existing snapshot, mutation, lease and key-formatting paths. No new input materialization, recursive traversal, native parser behavior, or adapter normalization was introduced by this fix wave.

## Verification evidence and boundary

The reviewer inspected the recorded evidence rather than duplicating the implementer's focused run or the parent's integration work:

- `fix-red.log`:1success,4failures,1error, reproducing the high/low fork mismatch, sentinel-depth mismatch, read-after-close, and standalone sentinel-key text.
- `fix-focused-green.log`:6successes,0failures,0errors,0pending.
- `fix-green.log`: inspected lint completion with0warnings/0errors in82files. Parent reports the full Lua run at567successes; full integration gates remain the parent's responsibility.

No additional targeted execution was needed: the fix paths are direct, the previously failing cases are represented in the focused suite, and the mutation/cancellation conditions are explicit in both code and assertions. This approval is a scoped code/spec review of R1–R4, not an independent claim that every branch-wide matrix, resource or HTTP gate has completed.
