local s = string.gsub("abc", "a", "b")
assert(s == "bbc")
local t = {}
for i = 1, 100 do t[i] = tostring(i) end
assert(#t == 100)
print("control_no_leanjson_ok")
