local json = require('leanjson')
for _, selection in ipairs({ '$.a', '$' }) do
    local callbacks = 0
    local input = json.new_decoder({ preload_paths = { selection }, index_depth = 0,
        index_array_limit = 0, index_budget_bytes = 0, chunk_size = 3,
        on_chunk = function() callbacks = callbacks + 1 end })
    local raw = '{"a":[{"v":1},{"v":2},{"v":3}],"unselected":{"x":"lazy"}}'
    assert(input:feed(raw))
    local value = assert(input:finish())
    input:close()
    local a, branch = value.a, json.fork(value)
    local held = a[2]
    local reader = json.reader(value, { chunk_size = 7 })
    local before = callbacks
    json.array_insert(a, 1, { v = 0 })
    local insertion_reads = callbacks - before
    before = callbacks
    assert(rawequal(held, a[3]))
    assert(callbacks == before)
    held.v = 22
    before = callbacks
    assert(value.a[3].v == 22 and branch.a[2].v == 2)
    assert(callbacks == before)
    local removed = json.array_remove(a, 2)
    before = callbacks
    assert(removed.v == 1 and rawequal(held, a[2]))
    assert(json.len(a) == 3 and a[1].v == 0 and a[3].v == 3)
    assert(callbacks == before, 'selected reads performed source I/O')
    if selection == '$' then assert(insertion_reads == 0) end
    local encoded = json.encode(value)
    assert(encoded == '{"a":[{"v":0},{"v":22},{"v":3}],"unselected":{"x":"lazy"}}', encoded)
    local parts = {}
    while true do
        local bytes, err = reader:next()
        assert(not err, err)
        if not bytes then break end
        parts[#parts + 1] = bytes
    end
    assert(table.concat(parts) == raw)
    json.close(value)
    json.close(a)
    json.close(branch)
    assert(held.v == 22 and removed.v == 1)
    json.close(held)
    json.close(removed)
    reader:close()
    print('PASS', selection, 'array edits, shifted held child, fork/snapshot isolation, child leases; insertion callbacks', insertion_reads, 'selected-read callbacks 0')
end
