package.path='./lua/?.lua;'..package.path
local c=require('leanjson').new()
c.decode_array_with_array_mt(true)
local m=c.array_mt
local function check(tag)
 local r=c.decode('[]',{lazyload=false});print(tag,'getmeta',getmetatable(r),'raw',debug.getmetatable(r),'wanted',m,'cfg',c.decode_array_with_array_mt())
 for i=1,12 do local name,value=debug.getupvalue(require('leanjson.loading').configure,i);if not name then break end;if name=='config' then print('loading marker',value.array_mt)end end
end
check('before')
local a,b,d=m.__len,m.__index,m.__metatable
print('saved',a,b,d)
m.__len=function()return 7 end;m.__index=function()return 'synthetic'end;m.__metatable='protected marker'
local v=setmetatable({1,2,hash='ignored'},m); print(c.encode(v))
local r=c.reader(v);while r:next() do end
m.__len,m.__index,m.__metatable=a,b,d
print('restored',m.__len,m.__index,m.__metatable)
check('after')
