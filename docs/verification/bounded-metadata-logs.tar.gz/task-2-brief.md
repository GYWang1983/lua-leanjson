## Global Constraints

- `index_depth = 3`, root depth 0; `index_array_limit = 3` per array; both accept nonnegative integers, zero disables optional pre-indexing.
- `index_budget_bytes = 1048576` default per source, lazy allocation, covers rebuildable initial and later metadata; zero means uncached correctness, never missing data.
- Full eager syntax/value/depth validation remains mandatory before final values/output; metadata depth is independent of `max_depth`.
- Last decoded key wins; normalized output removes earlier duplicates including escaped-equivalent keys; unknown is not duplicate-free.
- Apply the sparse runtime to memory/file/feed/OpenResty paths. Preserve old contiguous parse and v1 ABI layouts with additive APIs if needed.
- Preserve fork isolation, linked live-child semantics, stable snapshot readers, deterministic cleanup, cancellation across yields, exact lengths and bounded output.
- No algorithm fallback to a hidden full DOM for the required small/wide cases; no unbounded Lua per-member caches during lookup/count/output.
- No dependency changes, Kong integration, public release or GitHub operations. Explicit stage manifests; preserve unrelated worktrees and historical benchmark data.

## Review Focus

- Late duplicate keys after a lazy frontier or array prefix, escaped-equivalent keys and overwritten malformed subtrees still validate and resolve correctly.
- Budget churn with live child handles, forks and suspended readers cannot stale-reference reclaimed cache slots or discard patches.
- Very wide shallow objects must avoid both Lua-table amplification and quadratic per-member duplicate search.
- Count/normalization/output must not reconstruct the entire tree, and cache accounting must include capacity/auxiliary state rather than just nominal nodes.
- Adversarial long keys, deep arrays, I/O failure and close/abort during lazy source reads retain complete cleanup and bounded temporary buffers.

### Task 2: Independent memory acceptance and documentation (supervisor)

**Files:** `tests/openresty/benchmark.lua`, `tests/openresty/benchmark-handler.lua`, new bounded-memory probe/helpers under tests/openresty, `scripts/benchmark-openresty.sh` or new memory-gate script, Makefile gate target, README, docs/api.md if present (coordinate ownership), new verification report/raw JSONL, this plan/spec.
**Interfaces:** Task 1 public options and unchanged proxy APIs. Same fixtures and operations for leanjson/cjson. Use real native processes, no mock allocator; use corpus/semantic oracle separate from timed output.

- [ ] Add shallow 32768-key small-object and wide-scalar fixtures plus phase and cache-stress cases; preserve existing historical raw records. Capture baseline failure in the existing runtime.
- [ ] Run paired native process memory checks on the integrated implementation, recording peak RSS, sampled Lua heap, elapsed/CPU and input/output semantics. Repeat only for code changes/noise affecting conclusions; no concurrent cargo builds during measurements.
- [ ] If any required memory row exceeds native cjson, pass concrete measurements to Task 1 for correction; do not silently relax criteria.
- [ ] Document defaults, semantics, budgets/caller-held-memory boundaries, CPU/I/O tradeoffs and fresh measured results; update README historical caveat with links to new results.
- [ ] Independent whole-change review after functional/memory gates; resolve findings, verify exact committed runtime image and final diff. Leave local feature branch/worktree for user; no new push/publication requested.
