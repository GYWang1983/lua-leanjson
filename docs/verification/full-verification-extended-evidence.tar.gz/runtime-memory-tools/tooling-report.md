# Linux LuaJIT Valgrind/tooling report

## Scope and source boundary

This report covers the Linux ARM64 LuaJIT/Valgrind gate and the same-runtime controls. It does not include the pinned OpenResty profile runs; those were delegated to the runtime-profile worker. No tracked runtime, test, workflow, or script file was modified.

- Repository HEAD: `33d00b522d87cc760f757404186488453ffcb498`
- Branch: `verify/full-suite-2026-11-03`
- Isolated source: `runtime-memory-tools/isolated-source/` (read-only container mount)
- Runtime library: `isolated-source/target/release/libleanjson.so`
- Library SHA256: `8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b`
- `valgrind.supp` SHA256: `bf8b64340b88ff078edc1b8a7af945350a6b64b12e6e6dd9d5ea78130eb852ca`
- Source workflow SHA256: `0943b4ebcab3e99305641f33b5cbd500d04d65c0b186791d118f792f43af70d6`
- Source runtime script SHA256: `75a8c6cc1e4d058a749ed628464286d5c16dd4b9c858fbf6a84aa6ffd8ed3fda`
- Submodules: JSONTestSuite `1ef36fa01286573e846ac449e8683f8833c5b26a`; cJSON `fb16e5cf358798aabb049655975cde8427101056`; simdjson `43766fc7efdedc87111c48bda55f758ca212335b`; lua-cjson `617164a0fe3bb647128178f9caefb304b8573bb6`.

The pinned tooling image was `lua-qjson-dev:task3-repro`, ID `sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`, Linux ARM64. Its OpenResty label identifies the image as `1.29.2.4-jammy-arm64`; that rolling LuaJIT is distinct from the distro profile below.

## Profile results

### Rolling LuaJIT diagnostic (complete suite)

The first task3-based run resolved `$(command -v luajit)` to `/usr/local/openresty/luajit/bin/luajit` (`LuaJIT 2.1.ROLLING`). It is retained as an additional diagnostic, not as the exact beta3 profile.

The Busted suite reported `802 successes / 0 failures / 0 errors / 0 pending : 575.790183 seconds`. Every recorded Memcheck summary in this run reported zero errors and zero definite/indirect/possible lost bytes (some processes retained still-reachable bytes). The outer shell then attempted the multiline `--lpath` line as a command and returned 127; the raw distinction is preserved:

- test observation: 802/0/0/0, suite duration 575.790183s;
- wrapper result: `valgrind_busted_exit_code=127`, `valgrind_outer_exit_code=127`;
- first wrapper error: `/task/run-valgrind-task3.sh: line 45: --lpath=./lua/?.lua: No such file or directory`;
- raw log: `valgrind-task3-rolling-profile.log`, SHA256 `e327dc10550dded77e55c43d534169c54f1963e526e994ead3c03be4cea582ff`.

The `source_deep_spill` child also reported `ulimit: error setting limit (Operation not permitted)` in the default container. That is retained as an instrumentation/environment limitation.

### Ubuntu Jammy distro LuaJIT beta3 (exact tested fallback)

The upstream `v2.1.0-beta3` tag/archive was unavailable (no remote ref and codeload/download attempts returned 404), so the tested fallback is explicitly the Ubuntu Jammy package, not an upstream-build equivalence:

- LuaJIT: `/usr/bin/luajit`, `LuaJIT 2.1.0-beta3`;
- package: `luajit 2.1.0~beta3+dfsg-6ubuntu0.1`, `libluajit-5.1-2` same version;
- Valgrind: `3.18.1`, package `1:3.18.1-1ubuntu2`;
- debug symbols: `libc6-dbg 2.35-0ubuntu3.15`;
- `LUA_INIT='if jit then jit.off() end'`;
- exact CI Memcheck flags and `valgrind.supp` were used; no suppression was added.

The complete Busted suite reported `785 successes / 14 failures / 0 errors / 3 pending : 588.665761 seconds`, process and wrapper exit 1. The 3 pending cases are LuaJIT-52 checks skipped because the distro binary lacks `LUAJIT_ENABLE_LUA52COMPAT`.

The 14 functional failures were:

- three `cjson_arrays_spec.lua` marker/metamethod cases;
- `cjson_external_arrays_spec.lua` embedded-NUL external-array conversion;
- `cjson_settings_spec.lua` negative-zero formatting;
- `cjson_source_numeric_bytes_spec.lua` native Inf sign conversion;
- `decode_loading_spec.lua` loading-mode behavior;
- two `source_shutdown_spec.lua` finalizer/deep-normalization cases;
- five `strict_userdata_spec.lua` native-ipairs/missing-factory cases.

Valgrind recorded the first main test child (PID 382) as `4,044,609 errors from 28 contexts`, with no definite/indirect/possible lost bytes recorded. Representative child summaries include 17 baseline errors in `loading_without_cjson`, 294 in `source_shutdown`, 2,776 in the deep-spill child, and 14 in `strict_without_factory`. The child errors are retained as real instrumentation findings; they are not normalized into pass. The `ulimit -n 64` fixture again hit `Operation not permitted`.

- raw log: `valgrind-task3-distro-full.log`, SHA256 `476f764df0525a45e8e0193d0484abc240ac08bf063c8a6b2cacae316293455e`.

### Same-runtime no-LeanJSON Valgrind control

In a retained container from the same task3 image and the same distro package versions, a direct `/usr/bin/luajit` control performed only string replacement and table/string operations; it did not `require` LeanJSON or cjson. It printed `control_no_leanjson_ok`, freed all heap blocks, and recorded one uninitialised-value context in LuaJIT, exiting 1 under `--error-exitcode=1`. This confirms a baseline distro-LuaJIT Memcheck finding exists even without the project module; the full-run cjson/LuaJIT findings remain separately recorded.

- raw log: `valgrind-distro-control.log`, SHA256 `ffd27d3bb3d87bd5ecaad6b04fa8b0eff0805df7bb7a58c3eba73008657d0828`;
- retained container: `lq-valgrind-distro-control`, exited 1;
- committed local task image: `lua-qjson-valgrind:task3-distro-20261103`, ID `sha256:a649383496c8a70d66cb6d4b32688bb77dd8c01b49362d4dfac517e634c4853f`.

### Same-runtime uninstrumented full control

Using the committed distro image above, with JIT disabled and the same library/source mount but no Valgrind, the full Busted suite reported `792 successes / 7 failures / 0 errors / 3 pending : 22.462918 seconds`, exit 1. The 7 failures were the embedded-NUL external-array case, negative-zero settings, numeric-byte Inf sign, and four strict-userdata cases. The additional arrays/loading/shutdown failures seen only in the instrumented run are therefore retained as child/instrumentation-sensitive differences, not silently merged with the uninstrumented functional result.

- raw log: `uninstrumented-distro-full.log`, SHA256 `1fb32323f13bef63c0f3a58c850579241c1e97126d9bec067f9f20b0c189b2a8`.

## Setup/provisioning receipts

The first broad Ubuntu package attempt was stopped after the full ARM64 index set had downloaded but `apt-get update` remained blocked in the apt/gpgv phase; its recorded exit was 143 in `ubuntu-beta3-probe-retry.log`. A second apt configuration (`PDiffs=false`, no language indexes, gzip-only) completed. The optimized task3 install used `--no-install-recommends` plus `luajit valgrind libc6-dbg`, avoiding GDB/Python/valgrind-dbg. The first oversized full-run setup terminal output was unfortunately overwritten when the corrected task3 log was opened; the setup command, stall, and exit are recorded honestly in `receipts.json`, but no standalone raw file for that superseded setup remains. The completed distro run is `valgrind-task3-distro-full.log`.

All command strings, image IDs, versions, exit codes, counts, and evidence paths are machine-readable in `receipts.json`. Wall-clock start/end timestamps were not emitted by the original CI shell; suite durations above are the exact Busted-reported durations, and setup apt timings remain in their raw logs.

## Deferred/not run in this scope

- Upstream-source LuaJIT beta3 build: blocked by absent remote tag/archive; distro fallback executed and labeled.
- Pinned OpenResty 1.21/1.27/1.29 profile runs: delegated to the separate runtime-profile worker; no duplicate containers were started here.
- No source fix, expectation change, suppression change, commit, or push was performed.
