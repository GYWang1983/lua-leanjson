local c=assert(package.loadlib('/workspace/.superpowers/sdd/2026-11-02-cjson-f06/parent-reference/cjson.so','luaopen_cjson'))()
local ffi=require 'ffi'
local function show(label,value)
 local ok,r=pcall(c.encode,value); print(label,ok,type(r)=='string' and string.format('%q',r) or tostring(r))
end
local function virtual(n) return setmetatable({}, {__len=function() return n end,__index=function(_,k) return ({'foo','bar','baz'})[k] end}) end
show('original',virtual(3))
for _,case in ipairs({{0,'zero'},{-2,'negative'},{1.9,'fractional'},{'2.8','numeric-string'},{'0x2','hex-string'},{'invalid','nonnumeric'},{false,'false'},{true,'true'},{{},'table'},{ffi.new('int',2),'cdata-int'}}) do show(case[2],virtual(case[1])) end
show('nil',virtual(nil))
show('callable',setmetatable({}, {__len=setmetatable({}, {__call=function(_,t) assert(type(t)=='table');return 2 end}),__index={'one','two'}}))
show('false-method',setmetatable({}, {__len=false}))
show('number-method',setmetatable({}, {__len=3}))
show('inherited-method',setmetatable({},setmetatable({},{__index={__len=function() return 1 end,__index={'v'}}})))
show('locked',setmetatable({}, {__metatable='locked',__len=function() return 1 end,__index={'v'}}))
show('hash-ignored',setmetatable({extra='ignored',[1000]='ignored'}, {__len=function() return 2 end,__index={'x','y'}}))
for _,case in ipairs({{0/0,'nan'},{math.huge,'inf'},{-math.huge,'minus-inf'},{2147483648,'overflow'},{-2147483649,'underflow'}}) do
 local calls=0;local t=setmetatable({}, {__len=function() return case[1] end,__index=function() calls=calls+1;error('index-stop',0) end})
 show(case[2],t);print(case[2]..'-index-calls',calls)
end
local mt=c.array_mt;local prev=rawget(mt,'__len');rawset(mt,'__len',function() error('array-marker must win',0) end)
show('marker',setmetatable({1,2},mt));rawset(mt,'__len',prev)
