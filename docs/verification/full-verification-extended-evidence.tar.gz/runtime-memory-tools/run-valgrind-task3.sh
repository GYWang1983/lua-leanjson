#!/usr/bin/env bash
set -u

export DEBIAN_FRONTEND=noninteractive
apt_opts=(
  -o Acquire::ForceIPv4=true
  -o Acquire::http::Timeout=20
  -o Acquire::Retries=1
  -o Acquire::Languages=none
  -o Acquire::PDiffs=false
  -o Acquire::CompressionTypes::Order::=gz
)

apt-get "${apt_opts[@]}" update
apt-get install -y --no-install-recommends "${apt_opts[@]}" \
  luajit valgrind libc6-dbg

DISTRO_LUAJIT=/usr/bin/luajit
echo "luajit_path=$DISTRO_LUAJIT"
"$DISTRO_LUAJIT" -v 2>&1
echo "valgrind_path=$(command -v valgrind)"
valgrind --version
echo "busted_path=$(command -v busted)"
busted --version
echo "existing_luarocks=$(command -v luarocks || true)"
dpkg-query -W -f='${Package} ${Version}\n' luajit valgrind libc6-dbg libluajit-5.1-2 2>&1 || true

export LUA_INIT='if jit then jit.off() end'
echo "LUA_INIT=$LUA_INIT"
echo "LUAJIT_BIN=$DISTRO_LUAJIT"
echo "LD_LIBRARY_PATH=/workspace/target/release"
echo "VALGRIND_SUPPRESSIONS=/workspace/valgrind.supp"

set +e
LD_LIBRARY_PATH="/workspace/target/release" \
  valgrind \
    --trace-children=yes \
    --error-exitcode=1 \
    --leak-check=full \
    --show-leak-kinds=definite,indirect,possible \
    --errors-for-leak-kinds=definite,indirect,possible \
    --num-callers=24 \
    --suppressions=/workspace/valgrind.supp \
    busted --lua="$DISTRO_LUAJIT" tests/lua --lpath='./lua/?.lua'
test_rc=$?
echo "valgrind_busted_exit_code=$test_rc"
exit "$test_rc"
