# SDD ledger — plan: docs/design/plans/2026-11-02-cjson-f13-f14.md

Base: 15bada3824edf4141c16effe0246fda6293f24f4. Existing linked worktree, clean main baseline; temporary fix/cjson-indent-skip branch. origin/main fetched before work. No .codegraph, no relevant registry memory hits. User authorizes F13/F14 and local-main commit; no push.

Ruling: implement existing accepted F13/F14 spec directly — user explicitly requested these fixes; planning records implementation choices, no new product approval required.
Ruling: both features are one coupled task — same encoder punctuation/reader snapshot interfaces; splitting agents would cause shared-file conflicts.
Ruling: retain existing worktree and previous unpushed main commits — do not merge unrelated branches or touch their worktrees.

Preflight:
| Tasks | Interface/check | Finding |
| --- | --- | --- |
| 1 self | settings / plain encoder / bounded reader / tests | native oracle determines edge behavior; full materialization forbidden |
| 2 self | gates / review / docs / local commit | no push, independent review consumes same source evidence |
| 1,2 | runtime files and reports | sequential handoff; parent does not edit implementation during agent work |

Task 1: pending dispatch. Task 2: pending verification/review.

Task 1: dispatched indent_skip_impl (gpt-6.1-sol/max). Parent Rust gates444/444/445 and Clippy clean, controls11 pass. Parent pinned228case oracle and explicit getter probes fresh/reset exit139 ready. Image-oracle initial experiments were setup-only, superseded by explicit pinned library.

Task 1 implementation complete pending independent review. Stable report and source hashes recorded. Parent gates complete: HTTP60, matrix13 new passes/cell0regressions, loading18, installed-only pass. Remaining matrix differences and RSS32/33 preserved. Review package includes full task diff plus docs, base15bada3.

Task review: dispatched indent_skip_review (gpt-6-astra/max), read-only full diff/spec/quality; no duplicate suites. Matrix runtime51 file hashes and installed/built/matrix native hashes match.
Parent focused integration check: nodes.iter patch branch always normalizes its base, so skipping a patched duplicate does not expose an earlier shadowed source occurrence; no code change required.

Task 1: complete (base15bada3, independent spec/quality review approved).
Review P3-1: evidence wording corrected; no separate historical skip RED claimed. Reviewer verified and closed. No runtime/test changes or retests required.
Final whole-branch integration review: approved by indent_skip_review; archive sealing and explicit staging are parent final checks. No parked runtime findings.
Task 2 verification/review: complete. All requested functional gates pass; strict whole-cjson and RSS failures remain documented existing boundaries, not universal pass claims. No push authorized/requested.
Task 2 integration: ready; parent seals evidence, stages explicit10-file manifest, commits and fast-forwards local main. Existing worktree retained for continuing user work; only this plan scratch cleaned after committed archive verification.
