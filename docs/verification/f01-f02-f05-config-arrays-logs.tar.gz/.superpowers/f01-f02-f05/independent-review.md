# F01/F02/F05 independent review and resolution

Reviewer: `/root/config_arrays_review`, gpt-6.1-sol / max, read-only.
Scope: runtime changes, public API/settings, tests, source ownership and report.
Verdict: With fixes; five Important/P2 findings, no further unresolved findings.
An earlier Astra review attempt failed capacity before reviewing any code.

The findings below summarize the review (not a verbatim transcript).

1. Nested marker changes could be skipped when the full parent origin was
   reused. Reproduced by materializing nested objects with `keep_origin`, marking
   an inner object as an array, and comparing encoder/reader. Fixed by checking
   current classification recursively in `origin_record_matches`.
2. Origin array equality used `#t` and invoked explicit marker `__len`.
   Reproduced by a complete long-string origin array and throwing `__len`.
   Fixed by using classifier length, which is raw for explicit `array_mt`.
3. Marker comparisons used `==`, permitting shared `__eq` spoofing. Reproduced
   by a fake metatable and the same always-true equality handler on `array_mt`.
   Fixed using `rawequal` for marker identity in classification and snapshots.
4. Source array marking was lost after array edits stopped retaining the base.
   Reproduced by replacing/removing all source slots, fork/materialize and
   closing/reopening child views. Fixed by snapshotting a boolean on array edits,
   independent of source lifetime. Sentinel-derived marked forks are covered.
5. `empty_array_mt` always used raw reads, changing the ordinary array path's
   hole/`__index` behavior. Reproduced in a separate VM with a synthetic hole
   value. Fixed by carrying the classifier's raw-read mode through both direct
   encoding and reader/proxy snapshots. This is existing marker behavior; F06
   arbitrary foreign array proxy recognition remains separate.

All five regression cases failed independently before implementation:
`review-all-red.log`: 23 successes / 5 failures / 0 errors.
After all repairs, `review-green.log`: 34 successes / 0 failures / 0 errors
(28 array tests plus 6 settings tests). Full gates and matrix were rerun after
the repair; see `post-review-gates.log`, `post-review-matrix/` and verification
report. No second review was requested; reproducing regressions and full gates
close this review's findings.
