# OpenResty runtime profile evidence

Recorded 2026-11-03 for HEAD `33d00b522d87cc760f757404186488453ffcb498` on
`verify/full-suite-2026-11-03`. This task used the isolated directory
`.superpowers/sdd/2026-11-03-full-verification/runtime-profiles` and did not
write the checkout, the primary target, or `runtime-memory-tools/`.

## Result summary

| Profile | Evidence | Result |
| --- | --- | --- |
| `openresty/openresty:1.21.4.4-0-jammy` | Literal canonical `run-openresty-runtime.sh`, smoke mode | PASS: exit 0; 19 smoke assertion calls |
| `openresty/openresty:1.27.1.2-0-jammy` | Exact arm64 manifest available; two pulls bounded at 120 s and 300 s | BLOCKED before image commit; no runtime/test result claimed |
| `openresty/openresty:1.29.2.4-0-jammy` | Public stock image identity plus primary dev-image runtime/binary probes | SAME-RUNTIME EVIDENCE; no literal stock-image full profile |
| Primary `lua-qjson-dev:task3-repro` (1.29.2.4 base) | Reused primary full-suite receipts | 802 Busted successes and 72/72 HTTP; not rerun in this task |
| Separate `lua-leanjson-openresty:full-20261103` | Primary exact-commit image build/verify smoke | 4 checks pass; it is not the source of the 802/72 counts |

The machine-readable record is [`receipts.json`](receipts.json). Small raw
evidence is under [`evidence/`](evidence/), and the complete command output is
under [`logs/`](logs/).

## Frozen source and library

- Source: exact Git HEAD `33d00b522d87cc760f757404186488453ffcb498`, copied with
  `git archive --format=tar HEAD` into the task-owned `source/` directory.
- Release library copied read-only from Docker volume
  `leanjson-bounded-target:/release/libleanjson.so`.
- Library SHA-256: `8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b`
  (volume hash, container destination hash, and host hash all agree).
- Primary source manifest SHA-256:
  `11f1aab63df8a8a868163d5ffdea9212938e37f57bb829c976b4f77eaafc1ee9`.

The source archive and library were mounted only into this task's runtime
workspace for the 1.21 smoke. No release build, target overwrite, benchmark,
RSS measurement, or full-suite rerun was performed here.

## 1.21.4.4 smoke

The exact command was:

```sh
cd /Users/wanggy/Projects/lua-qjson/.superpowers/sdd/2026-11-03-full-verification/runtime-profiles/source
env -u GITHUB_WORKSPACE OPENRESTY_IMAGE=openresty/openresty:1.21.4.4-0-jammy OPENRESTY_FULL_BUSTED=false .github/scripts/run-openresty-runtime.sh
```

The script printed LuaJIT `2.1.0-beta3`, resty `0.29`, and
`nginx version: openresty/1.21.4.4`; it exited 0. The arm64 local image is
`sha256:4f61f8c3ce2d28544e708e472826b519be9699415d2c2bacce21e6aa300b53e9`
with repo digest
`openresty/openresty@sha256:3e6800f5960251d93c54abffae90a32e2788c8c283ba4c87e3c74ed23affec71`.
The arm64 manifest digest is
`sha256:57bb775e59b86d8b87c0ad3e862a949c968c7207d929cdc1a2256f4d073b6e1d`.
The combined output is [`profile-1.21.smoke.log`](logs/profile-1.21.smoke.log).

## 1.27.1.2 provisioning blocker

The registry manifest was readable and advertises arm64 digest
`sha256:ef654522466448a3bbfcd89e9c1e3f891168967d712a12fc1b00c0173bb96e0e`
with config digest
`sha256:59095000111495453846cb82fc1cbc281e5ef8d2c96179565e6b134410258b86`.
The unqualified pull was bounded at 120 seconds; the explicit
`--platform linux/arm64` retry was bounded at 300 seconds. Both ended without
an image, and `docker image inspect` returned `No such image`. The exact
timeout traceback and no runtime version are retained in
[`pull-1.27.1.2-0-jammy-platform.log`](logs/pull-1.27.1.2-0-jammy-platform.log).
This is a Docker provisioning blocker, not a failed LeanJSON smoke test, and
the 1.27 tag was not replaced with another OpenResty image.

## 1.29.2.4 reused primary evidence and runtime boundary

The primary 802-Busted/72-HTTP counts came from the development image
`lua-qjson-dev:task3-repro`, not from the separate exact-commit runtime image:

- dev image ID: `sha256:1a287857f8122e23a0ae0e5cf74227b747ea0dd40fa71b4b2be2f5ce58036a47`;
- runtime: OpenResty 1.29.2.4, resty 0.29, LuaJIT 2.1.ROLLING;
- library: `8bf0d9f2eedf09c39e8f1aa023c58851ae486ef0172dbdfd442096c01ec38c0b`;
- source manifest: `11f1aab63df8a8a868163d5ffdea9212938e37f57bb829c976b4f77eaafc1ee9`;
- Lua Busted: 802 successes, 0 failures, 0 errors, 0 pending;
- independent real OpenResty HTTP: 72 TAP pass, 0 fail, 0 errors.

The public pinned base tag is present locally as
`sha256:6e7cc7910d6bd4c7e2cdd3e23e9f17c8217062d50794e6be54791ba7d5620862`
(`openresty/openresty@sha256:0a887716d1bc7a3d38e6a765e4c9df31a4b4e27473fc30def6601511330c7f2f`).
Its arm64 manifest is `sha256:d8192f1aa538072eec98d5c737c5f69906b7a48117b7202faa189b463625ddf8`.
The first four rootfs layers of that public base exactly match the first four
layers of the primary development image; the dev image's five later layers
contain tools/source/harness. Read-only probes also produced identical hashes
for `resty`, the LuaJIT executable/library, and nginx in both images. This is
same-runtime development-image evidence, not exact whole-image identity and
not a literal stock-image full-profile run; the binary comparison is recorded
in [`dev-vs-public-1.29-comparison.md`](evidence/dev-vs-public-1.29-comparison.md).

Separately, primary built and verified the exact-commit image
`lua-leanjson-openresty:full-20261103` (ID
`sha256:08294519e73845acd28009b157a30e8e32dc2706c2037abf6b8449cb6244e7dc`).
Its `verify-openresty-image.sh` smoke passed four memory/file/incremental
length+SHA checks and malformed-input rejection. That image's smoke is kept as
a separate receipt; it did not produce the 802 Busted or 72 HTTP counts.

No literal `run-openresty-runtime.sh` full Busted invocation against the public
1.29 stock tag was separately executed here. The primary dev-image counts are
reused with the boundary above, not relabeled as a stock-image full pass.

The primary canonical umbrella still has its documented source-corpus first
failure (exit 2); the 802 Busted and 72 HTTP counts are not an all-gates-green
claim. See [`primary-equivalence-inputs.txt`](evidence/primary-equivalence-inputs.txt)
for the selected primary receipts and provenance lines.

## Evidence inventory

- [`receipts.json`](receipts.json): machine-readable commands, exits, counts,
  durations, tool/image identities, source and library hashes.
- [`evidence/library-copy.log`](evidence/library-copy.log),
  [`evidence/library-final.sha256`](evidence/library-final.sha256): frozen
  release library provenance.
- [`evidence/image-1.21.inspect.json`](evidence/image-1.21.inspect.json),
  [`evidence/image-1.29-public.summary`](evidence/image-1.29-public.summary),
  [`evidence/dev-image.summary`](evidence/dev-image.summary),
  [`evidence/primary-runtime-image.summary`](evidence/primary-runtime-image.summary),
  [`evidence/primary-runtime-rootfs.summary`](evidence/primary-runtime-rootfs.summary),
  [`evidence/public-1.29-rootfs.summary`](evidence/public-1.29-rootfs.summary):
  immutable image/base identity and versions.
- [`evidence/manifest-1.21.verbose.json`](evidence/manifest-1.21.verbose.json),
  [`evidence/manifest-1.27.verbose.json`](evidence/manifest-1.27.verbose.json),
  [`evidence/manifest-1.29.verbose.json`](evidence/manifest-1.29.verbose.json):
  registry manifest identities.
- [`evidence/primary-equivalence-inputs.txt`](evidence/primary-equivalence-inputs.txt):
  selected primary counts, image, source, library, and runtime provenance.
- [`evidence/binary-hashes-lua-qjson-dev_task3-repro.txt`](evidence/binary-hashes-lua-qjson-dev_task3-repro.txt),
  [`evidence/binary-hashes-openresty_openresty_1.29.2.4-0-jammy.txt`](evidence/binary-hashes-openresty_openresty_1.29.2.4-0-jammy.txt),
  [`evidence/dev-vs-public-1.29-comparison.md`](evidence/dev-vs-public-1.29-comparison.md):
  same-runtime development-image and stock-image binary comparison.
- [`evidence/harness-script-hashes.sha256`](evidence/harness-script-hashes.sha256):
  confirms the archived runtime wrapper and smoke script are byte-identical to
  the checkout copies used by the canonical invocation.
