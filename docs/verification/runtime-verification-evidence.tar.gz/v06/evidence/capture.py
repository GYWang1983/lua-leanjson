#!/usr/bin/env python3
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
label = sys.argv[1]
command = sys.argv[2:]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / (label + '.log')).open('wb') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
receipt = {'command': command, 'cwd': os.getcwd(), 'started_at_utc': started,
           'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'exit_code': result.returncode, 'log': label + '.log'}
(root / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print((root / (label + '.log')).read_text(errors='replace')[-4000:])
sys.exit(result.returncode)
