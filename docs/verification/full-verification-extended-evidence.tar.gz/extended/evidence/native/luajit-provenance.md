# Auxiliary macOS LuaJIT provenance

The installed-package smoke used the observed LuaJIT 2.1.0-beta3 binary below.
This is an Ubuntu/Debian `+dfsg` source archive, not a verified upstream Git
tag checkout. The upstream repository currently exposes a rolling `v2.1`
branch and no discoverable `v2.1.0-beta3` tag in this environment, so this
evidence does not claim exact upstream CI identity.

- Source URL:
  `https://archive.ubuntu.com/ubuntu/pool/universe/l/luajit/luajit_2.1.0~beta3+dfsg.orig.tar.gz`
- Source archive SHA-256:
  `46589f8a1742d04fc33f309343d9521b32d6d29515a34c6609e2f76932b1b7df`
- Extracted source marker: `LUAJIT_VERSION "LuaJIT 2.1.0-beta3"`,
  `LUAJIT_VERSION_NUM 20100`, `LUAJIT_VERSION_SYM luaJIT_version_2_1_0_beta3`.
- Build command: `MACOSX_DEPLOYMENT_TARGET=15.0 make -j2`, followed by
  `MACOSX_DEPLOYMENT_TARGET=15.0 make install PREFIX=<task-local-prefix>`.
- Observed runtime: `LuaJIT 2.1.0-beta3`, `OSX arm64`.
- Installed executable SHA-256:
  `e3321c6c6e9a6bbbc4d67567b9abe84e2c911088c5925cafcc2a0147662f2474`
- Installed dylib SHA-256:
  `4b31dc3c853877c9cfc2fe5a6b452b7f2c993b5460a0145b8e85dc2dc90d2b9d`
- Binary dependency: `/usr/lib/libSystem.B.dylib` only.
- Task-local paths:
  - archive: `/tmp/lua-leanjson-extended-20261103/src/luajit_2.1.0~beta3+dfsg.orig.tar.gz`
  - prefix: `/tmp/lua-leanjson-extended-20261103/lua/luajit-beta3`

The smoke receipt is `native-macos-installed-rock-smoke` in the parent
`receipts.json`; it passed from outside the checkout with inherited dynamic
library paths unset and Lua paths restricted to the isolated rock tree.
