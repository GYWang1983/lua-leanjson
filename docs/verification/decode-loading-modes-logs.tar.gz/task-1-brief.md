### Task 1: Coupled runtime, API and regression implementation (Sol 6.1 max)

**Files:** `src/source.rs`, focused modules under `src/source/`, `src/source_ffi.rs`
and `src/source_ffi/`, `include/leanjson.h`, `lua/leanjson/` shared options/backend/
source/proxy/node/table modules and focused selector/builder modules as needed,
`lua/leanjson.lua`, rockspec module install manifest, Rust source/ABI tests,
`tests/lua/decode_loading_spec.lua`, relevant source lifecycle/options tests,
`tests/openresty/acceptance.lua` and its fixtures, `docs/source-proxy-api.md`,
`docs/file-source-api.md`. Exclude supervisor README, spec/plan and final report.

**Interfaces:** Implement the two source options from the spec for all high-level
entrypoints. Expose truthful `source_stats` selected payload/metadata counts with
documented units; these remain separate from automatic `index_bytes`. Any new
native interfaces must have panic boundaries, header/cdef/export parity, loader
checks and existing-layout assertions. Shared cached nodes must preserve source
identity and remain immutable beneath branch overlays.

- [ ] Write focused red tests for ordinary eager values and selective cache loads
  at `a.b.c.d.e`/far array positions with depth/prefix/budget all zero; record exact
  commands and expected missing behavior before implementation.
- [ ] Add validated immutable selector compilation, native scan integration and
  eager/selected builders. Tests exercise `$`, escaped quoted keys, indexes,
  wildcards, empty/missing/overlapping paths, invalid syntax, and optional cjson
  absence. Default mode retains its original behavior.
- [ ] Integrate immutable preloaded state into lookup/scalar/iteration/reader and
  sparse mutation paths. Test later duplicate ancestor replacement/no-match,
  numbers above Lua exact range, byte-preserved untouched output, fork isolation,
  linked children and normalized/lexical duplicate behavior.
- [ ] Integrate all adapters and deterministic lifetime/error handling. Test one-
  byte feeds, file I/O failure, callback close/abort during builds, repeated finish/
  get after caller edits, malformed ignored subtrees, no leaked eager descriptors,
  and no retained unselected giant scalar/metadata tree.
- [ ] Record focused read-count/storage/work regressions, then run one canonical
  `make openresty-verify` in the pinned dev image with the shared target/registry
  volumes. Run locked offline fuzz-target compilation and isolated installed-tree
  smoke if ABI/module changes require them. Coordinate heavy tests with supervisor.
- [ ] Self-review, explicit-path commit, and report commands/output/remaining
  limitations to the task report. No subagents or remote Git actions.

